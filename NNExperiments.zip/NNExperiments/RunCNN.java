package NNExperiments;

import NNExperiments.CNN.LayerBuilder;
import NNExperiments.Layer;
import NNExperiments.Layer.Size;
import NNExperiments.TimedTest.TestTask;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;

public class RunCNN {

    public static void runCnn() throws IOException {
        
        String fileName = "check.txt";
        Dataset dataset = Dataset.load(fileName, ",", 0);
        dataset = Dataset.load(fileName, ",", 0);
        Vector<Double> tE = new Vector<>();
        Vector<Double> gE = new Vector<>();
        Vector<Double> vE = new Vector<>();
        Vector<LayerBuilder> builderVec = new Vector<>();
        Vector<CNN> CNNVector = new Vector<>();
        int j = 1;
        int k = j;

        //LayerBuilder builder=new LayerBuilder();
        for (int i = 0; i < k; i++) {
            builderVec.add(new LayerBuilder());
            
            builderVec.get(i).addLayer(Layer.buildInputLayer(new Size(18, 18)));
        builderVec.get(i).addLayer(Layer.buildConvLayer(12, new Size(5, 5)));
        builderVec.get(i).addLayer(Layer.buildSampLayer(new Size(2,2)));
        builderVec.get(i).addLayer(Layer.buildConvLayer(24, new Size(4, 4)));
        builderVec.get(i).addLayer(Layer.buildSampLayer(new Size(2,2)));
        builderVec.get(i).addLayer(Layer.buildOutputLayer(63));
            CNNVector.add(new CNN(builderVec.get(i), 50));

        }
        for (int i = 0; i < j; i++) {
            dataset.reshuffleAndGenerateSets();

            System.out.println("++++++++++++++++++++++++++++++++++++++++++++++++");
            System.out.println("++++++++++++++++++++++++++++++++++++++++++++++++");

            CNNVector.get(i).trainingSetError = 0;
            CNNVector.get(i).generalisationSetError = 0;
            ///needs more than 450 iterations to work -> trying 800
            CNNVector.get(i).train(dataset.getTrainingSet(), 550, dataset.getGenSet());
            tE.add(CNNVector.get(i).trainingErrorVector.lastElement());
            gE.add(CNNVector.get(i).generalisationErrorVector.lastElement());
            CNNVector.get(i).validationSetError = 0;
            CNNVector.get(i).predict(dataset.getValidationSet());
            System.out.println("++++++++++++++++++++++++++++++++++++++++++++++++");
            System.out.println("++++++++++++++++++++++++++++++++++++++++++++++++");
            vE.add(CNNVector.get(i).validationSetErrorVector.lastElement());
        }
        File dataFile = new File("CVNN_" + "DataFile-Experiment_Errors" + ".txt");

        FileWriter fdw = new FileWriter(dataFile.getCanonicalFile());
        BufferedWriter brd = new BufferedWriter(fdw);
        dataFile.createNewFile();

        for (int i = 0; i < k; i++) {
            brd.write(String.valueOf(tE.get(i)) + ","
                    + String.valueOf(gE.get(i))
                    + "," + String.valueOf(vE.get(i)));
            brd.newLine();
        }
        brd.close();
        
    }

    public static void main(String[] args) {

        new TimedTest(new TestTask() {

            @Override
            public void process() {
                try {
                    runCnn();
                } catch (IOException ex) {
                    Logger.getLogger(RunCNN.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }, 1).test();
        ConcurenceRunner.stop();

    }

}
/*
        builder.addLayer(Layer.buildInputLayer(new Size(18, 18)));
        builder.addLayer(Layer.buildConvLayer(6, new Size(3, 3)));
        builder.addLayer(Layer.buildSampLayer(new Size(1,1)));
        builder.addLayer(Layer.buildConvLayer(12, new Size(3, 3)));
        builder.addLayer(Layer.buildSampLayer(new Size(1, 1)));
        builder.addLayer(Layer.buildConvLayer(12, new Size(3, 3)));
        builder.addLayer(Layer.buildSampLayer(new Size(1, 1)));
        builder.addLayer(Layer.buildConvLayer(12, new Size(3, 3)));
        builder.addLayer(Layer.buildSampLayer(new Size(1, 1)));
        builder.addLayer(Layer.buildConvLayer(12, new Size(8, 8)));
        builder.addLayer(Layer.buildSampLayer(new Size(1, 1)));
        builder.addLayer(Layer.buildOutputLayer(65));
        
 */

 /*
        builder.addLayer(Layer.buildInputLayer(new Size(18, 18)));
        builder.addLayer(Layer.buildConvLayer(6, new Size(9, 9)));
        builder.addLayer(Layer.buildSampLayer(new Size(5,5)));
        builder.addLayer(Layer.buildConvLayer(12, new Size(2,2)));
        builder.addLayer(Layer.buildSampLayer(new Size(1, 1)));
        

builderVec.get(i).addLayer(Layer.buildInputLayer(new Size(18, 18)));
            builderVec.get(i).addLayer(Layer.buildConvLayer(6, new Size(3, 3)));
            builderVec.get(i).addLayer(Layer.buildSampLayer(new Size(1, 1)));
            builderVec.get(i).addLayer(Layer.buildConvLayer(12, new Size(3, 3)));
            builderVec.get(i).addLayer(Layer.buildSampLayer(new Size(1, 1)));
            builderVec.get(i).addLayer(Layer.buildConvLayer(12, new Size(3, 3)));
            builderVec.get(i).addLayer(Layer.buildSampLayer(new Size(1, 1)));
            builderVec.get(i).addLayer(Layer.buildConvLayer(12, new Size(3, 3)));
            builderVec.get(i).addLayer(Layer.buildSampLayer(new Size(1, 1)));
            builderVec.get(i).addLayer(Layer.buildConvLayer(12, new Size(8, 8)));
            builderVec.get(i).addLayer(Layer.buildSampLayer(new Size(1, 1)));
            builderVec.get(i).addLayer(Layer.buildOutputLayer(11));

builderVec.get(i).addLayer(Layer.buildInputLayer(new Size(18, 18)));
            builderVec.get(i).addLayer(Layer.buildConvLayer(6, new Size(1, 1)));
            builderVec.get(i).addLayer(Layer.buildSampLayer(new Size(1, 1)));
            builderVec.get(i).addLayer(Layer.buildConvLayer(12, new Size(3, 3)));
            builderVec.get(i).addLayer(Layer.buildSampLayer(new Size(4, 4)));
            builderVec.get(i).addLayer(Layer.buildConvLayer(18, new Size(4, 4)));
            builderVec.get(i).addLayer(Layer.buildSampLayer(new Size(1, 1)));
            builderVec.get(i).addLayer(Layer.buildOutputLayer(11));

            builderVec.get(i).addLayer(Layer.buildInputLayer(new Size(18, 18)));
            builderVec.get(i).addLayer(Layer.buildConvLayer(6, new Size(5, 5)));
            builderVec.get(i).addLayer(Layer.buildSampLayer(new Size(2, 2)));
            builderVec.get(i).addLayer(Layer.buildConvLayer(12, new Size(5, 5)));
            builderVec.get(i).addLayer(Layer.buildSampLayer(new Size(3, 3)));
            builderVec.get(i).addLayer(Layer.buildOutputLayer(63));

builderVec.get(i).addLayer(Layer.buildInputLayer(new Size(18, 18)));
            builderVec.get(i).addLayer(Layer.buildConvLayer(6, new Size(5, 5)));
            builderVec.get(i).addLayer(Layer.buildSampLayer(new Size(7, 7)));
            builderVec.get(i).addLayer(Layer.buildConvLayer(12, new Size(2, 2)));
            builderVec.get(i).addLayer(Layer.buildSampLayer(new Size(1, 1)));
            builderVec.get(i).addLayer(Layer.buildOutputLayer(37));



///     works for 0-9 and A-Z together
        builderVec.get(i).addLayer(Layer.buildInputLayer(new Size(18, 18)));
        builderVec.get(i).addLayer(Layer.buildConvLayer(12, new Size(5, 5)));
        builderVec.get(i).addLayer(Layer.buildSampLayer(new Size(2,2)));
        builderVec.get(i).addLayer(Layer.buildConvLayer(24, new Size(4, 4)));
        builderVec.get(i).addLayer(Layer.buildSampLayer(new Size(2,2)));
        builderVec.get(i).addLayer(Layer.buildOutputLayer(37));
            CNNVector.add(new CNN(builderVec.get(i), 50));

*/
