package NNExperiments;


import java.io.FileNotFoundException;
import java.io.UnsupportedEncodingException;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Warmaster
 */
public class DebinRandom1Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException, UnsupportedEncodingException {
        // TODO code application logic here
        int experimentType=3;
        //0:Log+Softmax
        //1:Cross+Sigmoid
        //2:Own+Mean Square
        DEbinRandom1 instance = new DEbinRandom1(experimentType);
        //instance.performDE_FFNN();
        instance.performDE_RMB_3_Layer_OPT();
    }
    
}
