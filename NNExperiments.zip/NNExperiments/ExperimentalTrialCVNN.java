/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package NNExperiments;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author Warmaster
 */
public class ExperimentalTrialCVNN {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here

        System.out.println("=====================================================================================");
        System.out.println("Experiment: Classification of English Letters and Numbers");
        System.out.println("=====================================================================================");

        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        
        NetworkTrainer trainer1 = new NetworkTrainer();
               //trainer1.RunExperiment(16,1,1,"letter-recognition.data", 16, 1, letter, 0,useBatch);
        //trainer1.adaptiveGrowExperiment(16,1,1,"letter-recognition.data", 16, 1, letter, 0,useBatch);
        //Good params 0.2 and 0.3 for learning rate and momentum
        trainer1.doConvolutionalExperiment();
    }

}
