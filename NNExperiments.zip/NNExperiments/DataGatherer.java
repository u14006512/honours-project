package NNExperiments;


import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Warmaster
 */
public class DataGatherer {

    public static void createRunDataFile(int funInd, int dimsInd, int stratInd, BigDecimal[] runsBestValues,double [] ptLr,double []ftLr,int []ptE,int []ftE,int[] l1,int l2[], int[] l3) throws FileNotFoundException, UnsupportedEncodingException {
        String filename = getStrategyName(stratInd) + "_" + getFunctionName(funInd)+"_OPT_RBM_3_LAYER"+ ".txt";

        PrintWriter writer = new PrintWriter(filename, "UTF-8");

        for (int i = 0; i < runsBestValues.length; i++) {
            writer.println(String.valueOf(runsBestValues[i])+","+
                    String.valueOf(ptLr[i])+","+
                    String.valueOf(ftLr[i])+","+
                    String.valueOf(ptE[i])+","+
                    String.valueOf(ftE[i])+","+
                    String.valueOf(l1[i])+","+
                    String.valueOf(l2[i])+","+
                    String.valueOf(l3[i])
                    );
        }
        writer.close();
    }
    public static void createRunDataFile(int funInd, int dimsInd, int stratInd, BigDecimal[] runsBestValues,double [] ptLr,double []ftLr,int []ptE,int []ftE,int[] l1,int l2[], int[] l3,int [] l4, int [] l5) throws FileNotFoundException, UnsupportedEncodingException {
        String filename = getStrategyName(stratInd) + "_" + getFunctionName(funInd)+"_OPT_RBM_5_LAYER"+ ".txt";

        PrintWriter writer = new PrintWriter(filename, "UTF-8");

        for (int i = 0; i < runsBestValues.length; i++) {
            writer.println(String.valueOf(runsBestValues[i])+","+
                    String.valueOf(ptLr[i])+","+
                    String.valueOf(ftLr[i])+","+
                    String.valueOf(ptE[i])+","+
                    String.valueOf(ftE[i])+","+
                    String.valueOf(l1[i])+","+
                    String.valueOf(l2[i])+","+
                    String.valueOf(l3[i])+","+
                    String.valueOf(l4[i])+","+
                    String.valueOf(l5[i])
                    );
        }
        writer.close();
    }
    public static void createRunDataFile(int funInd, int dimsInd, int stratInd, BigDecimal[] runsBestValues,double [] ptLr,double []ftLr,int []ptE,int []ftE,int[] l1,int l2[], int[] l3,int [] l4, int [] l5,int [] l6,int []l7) throws FileNotFoundException, UnsupportedEncodingException {
        String filename = getStrategyName(stratInd) + "_" + getFunctionName(funInd)+"_OPT_RBM_7_LAYER"+ ".txt";

        PrintWriter writer = new PrintWriter(filename, "UTF-8");

        for (int i = 0; i < runsBestValues.length; i++) {
            writer.println(String.valueOf(runsBestValues[i])+","+
                    String.valueOf(ptLr[i])+","+
                    String.valueOf(ftLr[i])+","+
                    String.valueOf(ptE[i])+","+
                    String.valueOf(ftE[i])+","+
                    String.valueOf(l1[i])+","+
                    String.valueOf(l2[i])+","+
                    String.valueOf(l3[i])+","+
                    String.valueOf(l4[i])+","+
                    String.valueOf(l5[i])+","+
                    String.valueOf(l6[i])
                    );
        }
        writer.close();
    }
    
    public static void createRunDataFile(int funInd, int dimsInd, int stratInd, BigDecimal[] runsBestValues,double [] runLearn,double[] runMom,int[] runHU) throws FileNotFoundException, UnsupportedEncodingException {
        String filename = getStrategyName(stratInd) + "_" + getFunctionName(funInd)+ ".txt";

        PrintWriter writer = new PrintWriter(filename, "UTF-8");

        for (int i = 0; i < runsBestValues.length; i++) {
            writer.println(String.valueOf(runsBestValues[i])+","+String.valueOf(runLearn[i])+","+String.valueOf(runMom[i])+","+String.valueOf(runHU[i]));
        }
        writer.close();
    }

    public static String getFunctionName(int f) {
        String s = null;
        switch (f) {
            case 0:
                s = "FFNN-Log-Likelihood-SoftMax";
                break;
            case 1:
                s = "FFNN-Cross-Entropy-Sigmoid";
                break;
            case 2:
                s = "FFNN-MeanSquare-OwnBounded";
                break;
            case 3:
                s = "FFNN-Stacked-Architecture";
                break;    
            case 4:
                s = "ConvolutionalNN";
                break;    
        }
        return s;
    }

    public static String getStrategyName(int f) {

        String s = null;
        switch (f) {
            case 0:
                s = "DE_Rand_bin_1";
                break;
                   }
        return s;
    }

    
}
