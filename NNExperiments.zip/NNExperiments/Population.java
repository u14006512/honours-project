package NNExperiments;


import java.util.Vector;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Warmaster
 */
public class Population {
    int currentBestPopBestIndividualIndex;
    Vector<Individual> individuals;
    int currentObjectiveFunction;
    
    int sizeOfDimensionComponent;
    double B,pr;
    
    
    Vector<Integer> dimensionComponents;

    public Population() {
        currentObjectiveFunction=0;
        currentBestPopBestIndividualIndex=-1;
        sizeOfDimensionComponent=0;
        
        individuals=new Vector<>();
        dimensionComponents=new Vector<>();
        B=0;
        pr=0;
    }
    
    void setObjectiveFunction(int o)
    {
        currentObjectiveFunction=o;
    }
    
    void setPr(double p)
    {
        pr=p;
    }
    
    void setB(double b)
    {
       B=b; 
    }
    
    double getB()
    {
        return B;
    }
    
    double getPr()
    {
        return pr;
    }
    void initialisePopulation(int dimensions,double [] dimensionBounds,double b,double pR,Vector<Integer> dimensionComp)
    {
        for (int i=0;i<10;i++)
        {
            individuals.add(new Individual(dimensions,dimensionBounds));
        }
        sizeOfDimensionComponent=dimensions;
        B=b;
        pr=pR;
        for (int i=0;i<dimensionComp.size();i++)
        {
            dimensionComponents.add(dimensionComp.get(i));
        }
    }
   
    Vector<Double> getPopulationBestVector()
    {
        return individuals.get(currentBestPopBestIndividualIndex).positionVector;
    }
    
    void setDimensionComponents(Vector<Integer> dimComps)
    {
        dimensionComponents.clear();
        
        for (int i=0;i<dimComps.size();i++)
        {
            dimensionComponents.add(dimComps.get(i));
        }
    }
    
}
