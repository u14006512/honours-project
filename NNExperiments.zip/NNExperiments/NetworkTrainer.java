/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package NNExperiments;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Vector;

/**
 *
 * @author Warmaster
 */
public class NetworkTrainer {
    CNN cnn;
    NeuralNetwork pokemon;
    Long epochCount;
    Dataset dataset;
    NetworkTrainer() {
        pokemon = new NeuralNetwork();
    }

    void trainNetwork(ArrayList<DataRecord> trainingSet, ArrayList<DataRecord> generalisationSet, ArrayList<DataRecord> validationSet, int logNum, int experiment) throws IOException {
        String reportData;
        double averageMSE = 0;
        double stdDevMSE = 0;
        String errorTest = "";
        ArrayList<Double> listDoublesMSE = new ArrayList<>();
        ArrayList<Double> trainingSetAverage = new ArrayList<>();
        ArrayList<Double> generalisationSetAverage = new ArrayList<>();
//header = "Epoch" + '\t' + "Training Set Accuracy" + '\t' + "Generalisation Set Accuracy";

        System.out.println("NEURAL NETWORK TRAINING SESSION");
        System.out.println("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
        System.out.println("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
        System.out.println("Network Paramaters");
        System.out.println("Learning Rate: " + pokemon.getLearningRate());
        System.out.println("Momentum: " + pokemon.getMomentum());
        System.out.println("Max Epochs: " + pokemon.getMaxEpochs());
        System.out.println("Input Neuron Count: " + pokemon.getInN());
        System.out.println("Hidden Neuron Count: " + pokemon.getHiddenN());
        System.out.println("Output Neuron Count: " + pokemon.getOutN());
        System.out.println("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
        System.out.println("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");

        pokemon.setEpoch(0);

        switch (pokemon.errChoice) {
            case 0:
                errorTest = "Log-Likelihood";
                break;
            case 1:
                errorTest = "Cross-Entropy";
                break;
            case 2:
                errorTest = "Mean Squared";
                break;
        }

        double priorTAcc = -1, priorGAcc = -1;
        int repetitions = 0;
        while (pokemon.getEpoch() < pokemon.getMaxEpochs()) {

            priorTAcc = pokemon.getTrainingSetAccuracy();
            priorGAcc = pokemon.getGeneralisationSetAccuracy();

            String heading = "Epoch" + '\t' + "Training Set Accuracy" + '\t' + "Generalisation Set Accuracy";

            double priorTrainingAcc = pokemon.getTrainingSetAccuracy();
            double priorGenAcc = pokemon.getGeneralisationSetAccuracy();

            pokemon.runEpoch(trainingSet);

            pokemon.setGeneralisationSetAccuracy(pokemon.getSetAccuracy(generalisationSet));
            pokemon.setGeneralisationSetMeanSqError(pokemon.getSetStatisticalError(generalisationSet));

            trainingSetAverage.add(pokemon.getTrainingSetAccuracy());
            generalisationSetAverage.add(pokemon.getGeneralisationSetAccuracy());

            reportData = Long.toString(pokemon.getEpoch()) + '\t' + Double.toString(pokemon.getTrainingSetAccuracy()) + '\t' + Double.toString(pokemon.getGeneralisationSetAccuracy());
            System.out.println("##########################################################################");
            System.out.println("##########################################################################");
            System.out.println("Epoch: " + pokemon.getEpoch());
            System.out.println("Training Set Accuracy: " + pokemon.getTrainingSetAccuracy());
            System.out.println("Training Set " + errorTest + " Error:" + pokemon.getTrainingsetMeanSqError());
            System.out.println("Generalisation Set Accuracy: " + pokemon.getGeneralisationSetAccuracy());
            System.out.println("Generalisation Set " + errorTest + " Error:" + pokemon.getGeneralisationSetMeanSqError());
            System.out.println("##########################################################################");
            System.out.println("##########################################################################");
            pokemon.setEpoch(pokemon.getEpoch() + 1);
            double tmp = 0;
            for (int u = 0; u < trainingSetAverage.size(); u++) {
                tmp = tmp + trainingSetAverage.get(u);
            }
            pokemon.setAverageTrainingSetAccuracy(tmp / trainingSetAverage.size());
        }

        double tmp = 0;
        for (int u = 0; u < generalisationSetAverage.size(); u++) {
            tmp = tmp + generalisationSetAverage.get(u);
        }
        pokemon.setAverageGeneralisationSetAccuracy(tmp / generalisationSetAverage.size());
        pokemon.setValidationSetAccuracy(pokemon.getSetAccuracy(validationSet));
        pokemon.setValidationSetMeanSqError(pokemon.getSetStatisticalError(validationSet));
        System.out.println("");
        System.out.println("");
        System.out.println("##########################################################################");
        System.out.println("##########################################################################");
        System.out.println("Training Complete");
        System.out.println("Validation Set Accuracy:" + pokemon.getValidationSetAccuracy());
        System.out.println("Validation Set Mean Square Error:" + pokemon.getValidationSetMeanSqError());
        System.out.println("##########################################################################");
        System.out.println("##########################################################################");

    }
    void performNetworkExperimentDEOpt(int inInput, int inHidden, int inOutput, String fn, int inputs, int targets, int experiment, boolean batch, double learning, double mom, int errCh, int outCh) throws IOException {
        DataReader dataInput = new DataReader();

        int hiddenUnits = inHidden;
        int i = 0;
        int logNumber = 0;

        double learningRate = learning;
        double momentum = mom;
        int errC = errCh;
        int outputC = outCh;
        dataInput.loadFileExperiment(fn, inputs, targets, experiment);
        pokemon = null;
        System.out.println("Performing 10 Tests on Finalised Values");

        pokemon = new NeuralNetwork(inInput, (int) hiddenUnits, inOutput, batch, learningRate, momentum, errC, outputC);

        String errorFunction = "";
        String outputFunction = "";
        String nnType = "FFNN";

        switch (errC) {
            case 0:
                errorFunction = "Log-Likelihood";
                break;
            case 1:
                errorFunction = "Cross-Entropy";
                break;
            case 2:
                errorFunction = "Mean-Squared";
                break;
        }
        switch (outCh) {
            case 0:
                outputFunction = "SoftMax";
                break;
            case 1:
                outputFunction = "Sigmoid";
                break;
            case 2:
                outputFunction = "OwnBounded";
                break;
        }
        dataInput.reshuffleAndGenerateSets();
        while (i < 1) {

            File dataFile = new File(nnType + "_" + errorFunction + "_" + outputFunction + "_" + "DataFile-Experiment_Errors_DE_OPT" + i + ".txt");

            String header;
            //FileWriter fdw = new FileWriter(dataFile.getCanonicalFile());
           // BufferedWriter brd = new BufferedWriter(fdw);

           // dataFile.createNewFile();
            trainNetwork(dataInput.trainingSet, dataInput.generalisationSet, dataInput.validationSet, i, experiment);
            //brd.write(String.format(pokemon.getTrainingSetAccuracy() + "," + pokemon.getValidationSetAccuracy() + "," + pokemon.getTrainingSetAverage()
            //        + "," + pokemon.getGenSetAverage() + "," + pokemon.getValidationSetMeanSqError()));
            //brd.newLine();
            //brd.close();
            pokemon.resetNetwork();
            i++;

        }
        System.out.println("Tests Complete");
    }
    void performNetworkExperiment(int inInput, int inHidden, int inOutput, String fn, int inputs, int targets, int experiment, boolean batch, double learning, double mom, int errCh, int outCh) throws IOException {
        DataReader dataInput = new DataReader();

        int hiddenUnits = inHidden;
        int i = 0;
        int logNumber = 0;

        double learningRate = learning;
        double momentum = mom;
        int errC = errCh;
        int outputC = outCh;
        dataInput.loadFileExperiment(fn, inputs, targets, experiment);
        pokemon = null;
        System.out.println("Performing 30 Tests on Finalised Values");

        pokemon = new NeuralNetwork(inInput, (int) hiddenUnits, inOutput, batch, learningRate, momentum, errC, outputC);

        String errorFunction = "";
        String outputFunction = "";
        String nnType = "FFNN";

        switch (errC) {
            case 0:
                errorFunction = "Log-Likelihood";
                break;
            case 1:
                errorFunction = "Cross-Entropy";
                break;
            case 2:
                errorFunction = "Mean-Squared";
                break;
        }
        switch (outCh) {
            case 0:
                outputFunction = "SoftMax";
                break;
            case 1:
                outputFunction = "Sigmoid";
                break;
            case 2:
                outputFunction = "OwnBounded";
                break;
        }
        dataInput.reshuffleAndGenerateSets();
        while (i < 30) {

            File dataFile = new File(nnType + "_" + errorFunction + "_" + outputFunction + "_" + "DataFile-Experiment_Errors" + i + ".txt");

            String header;
            FileWriter fdw = new FileWriter(dataFile.getCanonicalFile());
           BufferedWriter brd = new BufferedWriter(fdw);

           dataFile.createNewFile();
            trainNetwork(dataInput.trainingSet, dataInput.generalisationSet, dataInput.validationSet, i, experiment);
            brd.write(String.format(pokemon.getTrainingSetAccuracy() + "," + pokemon.getValidationSetAccuracy() + "," + pokemon.getTrainingSetAverage()
            + "," + pokemon.getGenSetAverage() + "," + pokemon.getValidationSetMeanSqError()));
            brd.newLine();
            brd.close();
            pokemon.resetNetwork();
            i++;

        }
        System.out.println("Tests Complete");
    }

    double getValidationError() {
        return pokemon.getValidationSetMeanSqError();
    }
    
    
    public void doConvolutionalExperiment() throws IOException
    {
        String fileName = "testCase.txt";
         
        dataset = Dataset.load(fileName, ",", 0);
        int j=1;
            int k=1;
            
        for(int i=0;i<j;i++)
        {
            dataset.reshuffleAndGenerateSets();
            performConvolutional();
            cnn.predict(dataset.getValidationSet());
        }
        File dataFile = new File("CVNN_" + "DataFile-Experiment_Errors"+ ".txt");
        
        FileWriter fdw = new FileWriter(dataFile.getCanonicalFile());
        BufferedWriter brd = new BufferedWriter(fdw);
        dataFile.createNewFile();
        
        for(int i=0;i<k;i++)
        {
            brd.write(String.valueOf(cnn.trainingErrorVector.get(i))+ ","
                    + String.valueOf(cnn.generalisationErrorVector.get(i))
                    + "," + String.valueOf(cnn.validationSetErrorVector.get(i)));
            brd.newLine();
        }
        brd.close();
    }
    public void performConvolutional()
    {
        Vector<Double> stats=new Vector<>();
        CNN.LayerBuilder builder = new CNN.LayerBuilder();
        /*
        builder.addLayer(Layer.buildInputLayer(new Layer.Size(18, 18)));
        builder.addLayer(Layer.buildConvLayer(6, new Layer.Size(9, 9)));
        builder.addLayer(Layer.buildSampLayer(new Layer.Size(5,5)));
        builder.addLayer(Layer.buildConvLayer(12, new Layer.Size(2,2)));
        builder.addLayer(Layer.buildSampLayer(new Layer.Size(1, 1)));
        */
             builder.addLayer(Layer.buildInputLayer(new Layer.Size(18, 18)));
        builder.addLayer(Layer.buildConvLayer(6, new Layer.Size(5, 5)));
        builder.addLayer(Layer.buildConvLayer(6, new Layer.Size(5, 5)));
        builder.addLayer(Layer.buildSampLayer(new Layer.Size(2,2)));
        builder.addLayer(Layer.buildConvLayer(6, new Layer.Size(2, 2)));
        builder.addLayer(Layer.buildSampLayer(new Layer.Size(2,2)));
        builder.addLayer(Layer.buildConvLayer(6, new Layer.Size(2, 2)));
        builder.addLayer(Layer.buildSampLayer(new Layer.Size(1,1)));
        builder.addLayer(Layer.buildOutputLayer(37));
        
        cnn = new CNN(builder, 10);
        
        
        cnn.train(dataset.getTrainingSet(), 10,dataset.getGenSet());//

       
        
        
        
    }
}
