package NNExperiments;


import static java.lang.Math.max;
import java.math.BigDecimal;
import java.util.Random;
import java.util.Vector;
import java.util.concurrent.ThreadLocalRandom;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Warmaster
 */
public class Individual implements Comparable<Individual>{
    int dimensions;
    BigDecimal fitnessEvaluation;
    Vector<Double> positionVector;
    
    @Override
    public int compareTo(Individual a)
    {
        if (this.fitnessEvaluation.compareTo(fitnessEvaluation)<0)
        {
            return -1;
        } else if (this.fitnessEvaluation.compareTo(fitnessEvaluation)>0)
            {
                return 1;
            } else return 0;
    }
    
    void setDimensions(int d)
    {
        dimensions=d;
    }
    public Individual()
    {
        positionVector=new Vector<>();
    }
    
    
    public Individual(int d,double []range) {
        dimensions=d;
        fitnessEvaluation=new BigDecimal(0);
        positionVector=new Vector<>();
        int c=0,c1=1;
        for (int i=0;i<d;i++)
        {
            if (i==0 || i==1)
            {
                positionVector.add((ThreadLocalRandom.current().nextDouble(range[c], range[c1])));
            }else 
            {
                positionVector.add(Math.ceil(ThreadLocalRandom.current().nextDouble(range[c], range[c1])));
            }
            
            c+=2;
            c1+=2;
        }
    }
    
    int getDimensions()
    {
        return dimensions;
    }
    
    void resetPositions()
    {
        positionVector.clear();
    }
    
    void setPositionVector(Vector<Double> in)
    {
        positionVector.clear();
        for (int i=0;i<in.size();i++)
        {
            positionVector.add(in.get(i));
        }
    }
    double getPositionFromVector(int i)
    {
        return positionVector.get(i);
    }
    
    Vector<Double> getVector()
    {
        return positionVector;
    }
    
    void setPos(int in,double val)
    {
        positionVector.set(in, val);
    }
    
    
}


