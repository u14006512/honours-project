package NNExperiments;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.neuroph.nnet.ConvolutionalNetwork;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Warmaster
 */
public class FFNN_Log_Likelihood_SoftMax extends ObjectiveFunction {
    NetworkTrainer trainer1 = new NetworkTrainer();
    ConvolutionalNetwork s=new ConvolutionalNetwork();
    /**
     *
     * @param inputs
     * @return
     */
    @Override
    public BigDecimal functionEvaluation(Vector<Double> inputs) {
        BigDecimal result = new BigDecimal(0);
        try {
            
            BigDecimal t;
            boolean useBatch = false;
            double numH=inputs.get(2);
            
            int numHH=(int)numH;
            int eC=0;
            int outC=0;
            
            if (numHH>65)
            {
                numHH=65;
            }
            if (numHH<0)
            {
                numHH=10;
            }
            
            if (inputs.get(0)<0)
            {
                inputs.set(0, Math.abs(inputs.get(0)));
            }
            if (inputs.get(1)<0)
            {
                inputs.set(1, Math.abs(inputs.get(1)));
            }
            
            //trainer1.RunExperiment(16,1,1,"letter-recognition.data", 16, 1, letter, 0,useBatch);
            //trainer1.adaptiveGrowExperiment(16,1,1,"letter-recognition.data", 16, 1, letter, 0,useBatch);
            //Good params 0.2 and 0.3 for learning rate and momentum
            trainer1.performNetworkExperimentDEOpt(324, numHH, 65, "opt.txt", 324, 65, 0, useBatch, inputs.get(0), inputs.get(1),eC,outC);
            
            t=new BigDecimal(trainer1.getValidationError());
            result=t;
        } catch (IOException ex) {
            Logger.getLogger(FFNN_Log_Likelihood_SoftMax.class.getName()).log(Level.SEVERE, null, ex);
        }
        
       
        return result;
    }

    @Override
    public double[] getRange() {
        double s[] = new double[6];
        s[0] = 0.1;
        s[1] = 1;
        s[2] = 0.1;
        s[3] = 1;
        s[4] = 10.0;
        s[5] = 65.0;

        return s;
    }
}
