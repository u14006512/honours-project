package NNExperiments;

import java.util.Random;
import static NNExperiments.utils.*;
import NNExperiments.DataRecord;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import static java.lang.Math.ceil;
import java.util.ArrayList;
import java.util.Collections;

public class DBN {

    public int N;
    public int n_ins;
    public int[] hidden_layer_sizes;
    public int n_outs;
    public int n_layers;
    public HiddenLayerDiscrete[] sigmoid_layers;
    public RBM[] rbm_layers;
    public LogisticRegressionDiscrete log_layer;
    public Random rng;

    ArrayList<DataRecordRMB> dataVector;
    ArrayList<DataRecordRMB> trainingSet;
    ArrayList<DataRecordRMB> generalisationSet;
    ArrayList<DataRecordRMB> validationSet;

    int sizeTrain;
    int sizeG;
    int sizeV;
    
    int numRecords;
    
    public void doDE_OptimisationExperiment()
    {
        
    }
    
    public void doRMB_Experiment() throws IOException
    {
        String fileName = "testCase.txt";
         
        
        int j=1;
            int k=1;
            
        for(int i=0;i<j;i++)
        {
        
        }
        File dataFile = new File("CVNN_" + "DataFile-Experiment_Errors"+ ".txt");
        
        FileWriter fdw = new FileWriter(dataFile.getCanonicalFile());
        BufferedWriter brd = new BufferedWriter(fdw);
        dataFile.createNewFile();
        
        for(int i=0;i<k;i++)
        {
            brd.write(String.valueOf("")+ ","
                    + String.valueOf("")
                    + "," + String.valueOf(""));
            brd.newLine();
        }
        brd.close();
    }
    
    public DBN(String fn,int number_input, int[] hidden_layer_sizes_in, int number_outs, int num_layers, Random rng) throws IOException {

        int input_size; 
        CountRecords(fn);
        int [] tt=tSize();
        dataVector=new ArrayList<>();
        
        trainingSet=new ArrayList<>();
        generalisationSet=new ArrayList<>();
        validationSet=new ArrayList<>();
        
        
        this.n_ins = number_input;
        this.hidden_layer_sizes = hidden_layer_sizes_in;
        this.n_outs = number_outs;
        this.n_layers = num_layers;

        this.sigmoid_layers = new HiddenLayerDiscrete[n_layers];
        this.rbm_layers = new RBM[n_layers];

        if (rng == null) {
            this.rng = new Random(1234);
        } else {
            this.rng = rng;
        }

        // construct multi-layer
        for (int i = 0; i < this.n_layers; i++) {
            if (i == 0) {
                input_size = this.n_ins;
            } else {
                input_size = this.hidden_layer_sizes[i - 1];
            }

            // construct sigmoid_layer
            this.sigmoid_layers[i] = new HiddenLayerDiscrete(this.N, input_size, this.hidden_layer_sizes[i], null, null, rng);

            // construct rbm_layer
            this.rbm_layers[i] = new RBM(this.N, input_size, this.hidden_layer_sizes[i], this.sigmoid_layers[i].W, this.sigmoid_layers[i].b, null, rng);
        }

        // layer for output using Logistic Regression
        this.log_layer = new LogisticRegressionDiscrete(this.N, this.hidden_layer_sizes[this.n_layers - 1], this.n_outs);
        
        
    }
    
    public DBN(int N, int n_ins, int[] hidden_layer_sizes, int n_outs, int n_layers, Random rng) {
        int input_size;

        this.N = N;
        this.n_ins = n_ins;
        this.hidden_layer_sizes = hidden_layer_sizes;
        this.n_outs = n_outs;
        this.n_layers = n_layers;

        this.sigmoid_layers = new HiddenLayerDiscrete[n_layers];
        this.rbm_layers = new RBM[n_layers];

        if (rng == null) {
            this.rng = new Random(1234);
        } else {
            this.rng = rng;
        }

        // construct multi-layer
        for (int i = 0; i < this.n_layers; i++) {
            if (i == 0) {
                input_size = this.n_ins;
            } else {
                input_size = this.hidden_layer_sizes[i - 1];
            }

            // construct sigmoid_layer
            this.sigmoid_layers[i] = new HiddenLayerDiscrete(this.N, input_size, this.hidden_layer_sizes[i], null, null, rng);

            // construct rbm_layer
            this.rbm_layers[i] = new RBM(this.N, input_size, this.hidden_layer_sizes[i], this.sigmoid_layers[i].W, this.sigmoid_layers[i].b, null, rng);
        }

        // layer for output using Logistic Regression
        this.log_layer = new LogisticRegressionDiscrete(this.N, this.hidden_layer_sizes[this.n_layers - 1], this.n_outs);
    }

    public void pretrain(ArrayList<DataRecordRMB> train_X, double lr, int k, int epochs) {
        int[] layer_input = new int[0];
        int prev_layer_input_size;
        int[] prev_layer_input;

        for (int i = 0; i < n_layers; i++) {  // layer-wise
            for (int epoch = 0; epoch < epochs; epoch++) {  // training epochs
                System.out.println("Current Epoch: "+epoch+" of "+epochs);
                for (int n = 0; n < N; n++) {  // input x1...xN
                    // layer input
                    for (int l = 0; l <= i; l++) {

                        if (l == 0) {
                            layer_input = new int[n_ins];
                            for (int j = 0; j < n_ins; j++) {
                                layer_input[j] = (int)train_X.get(n).pattern[j];
                            }
                        } else {
                            if (l == 1) {
                                prev_layer_input_size = n_ins;
                            } else {
                                prev_layer_input_size = hidden_layer_sizes[l - 2];
                            }

                            prev_layer_input = new int[prev_layer_input_size];
                            for (int j = 0; j < prev_layer_input_size; j++) {
                                prev_layer_input[j] = layer_input[j];
                            }

                            layer_input = new int[hidden_layer_sizes[l - 1]];

                            sigmoid_layers[l - 1].sample_h_given_v(prev_layer_input, layer_input);
                        }
                    }

                    rbm_layers[i].contrastive_divergence(layer_input, lr, k);
                }
            }
        }
    }

    public void finetune(ArrayList<DataRecordRMB> train_X, ArrayList<DataRecordRMB> train_Y, double lr, int epochs) {
        int[] layer_input = new int[0];
        // int prev_layer_input_size;
        int[] prev_layer_input = new int[0];

        for (int epoch = 0; epoch < epochs; epoch++) {
            System.out.println("Current Epoch: "+epoch+" of "+epochs);
            for (int n = 0; n < N; n++) {

                // layer input
                for (int i = 0; i < n_layers; i++) {
                    if (i == 0) {
                        prev_layer_input = new int[n_ins];
                        for (int j = 0; j < n_ins; j++) {
                            prev_layer_input[j] = train_X.get(n).pattern[j];
                        }
                    } else {
                        prev_layer_input = new int[hidden_layer_sizes[i - 1]];
                        for (int j = 0; j < hidden_layer_sizes[i - 1]; j++) {
                            prev_layer_input[j] = layer_input[j];
                        }
                    }

                    layer_input = new int[hidden_layer_sizes[i]];
                    sigmoid_layers[i].sample_h_given_v(prev_layer_input, layer_input);
                }

                log_layer.train(layer_input, train_Y.get(n).target, lr);
            }
            // lr *= 0.95;
        }
    }

    public void predict(int[] x, double[] y) {
        double[] layer_input = new double[0];
        // int prev_layer_input_size;
        double[] prev_layer_input = new double[n_ins];
        for (int j = 0; j < n_ins; j++) {
            prev_layer_input[j] = x[j];
        }

        double linear_output;

        // layer activation
        for (int i = 0; i < n_layers; i++) {
            layer_input = new double[sigmoid_layers[i].n_out];

            for (int k = 0; k < sigmoid_layers[i].n_out; k++) {
                linear_output = 0.0;

                for (int j = 0; j < sigmoid_layers[i].n_in; j++) {
                    linear_output += sigmoid_layers[i].W[k][j] * prev_layer_input[j];
                }
                linear_output += sigmoid_layers[i].b[k];
                layer_input[k] = sigmoid(linear_output);
            }

            if (i < n_layers - 1) {
                prev_layer_input = new double[sigmoid_layers[i].n_out];
                for (int j = 0; j < sigmoid_layers[i].n_out; j++) {
                    prev_layer_input[j] = layer_input[j];
                }
            }
        }

        for (int i = 0; i < log_layer.n_out; i++) {
            y[i] = 0;
            for (int j = 0; j < log_layer.n_in; j++) {
                y[i] += log_layer.W[i][j] * layer_input[j];
            }
            y[i] += log_layer.b[i];
        }

        log_layer.softmax(y);
    }

    private static void test_dbn() {
        Random rng = new Random(System.currentTimeMillis());

        double pretrain_lr = 0.1;
        int pretraining_epochs = 1000;
        int k = 1;
        double finetune_lr = 0.1;
        int finetune_epochs = 500;

        int train_N = 6;
        int test_N = 4;
        int n_ins = 6;
        int n_outs = 2;
        int[] hidden_layer_sizes = {10, 3, 2};
        int n_layers = hidden_layer_sizes.length;

        // training data
        int[][] train_X = {
            {1, 1, 1, 0, 0, 0},
            {1, 0, 1, 0, 0, 0},
            {1, 1, 1, 0, 0, 0},
            {0, 0, 1, 1, 1, 0},
            {0, 0, 1, 1, 0, 0},
            {0, 0, 1, 1, 1, 0}
        };

        int[][] train_Y = {
            {1, 0},
            {1, 0},
            {1, 0},
            {0, 1},
            {0, 1},
            {0, 1},};

        // construct DNN.DBN
        DBN dbn = new DBN(train_N, n_ins, hidden_layer_sizes, n_outs, n_layers, rng);

        // pretrain
        //dbn.pretrain(train_X, pretrain_lr, k, pretraining_epochs);

        // finetune
        //dbn.finetune(train_X, train_Y, finetune_lr, finetune_epochs);

        // test data
        int[][] test_X = {
            {1, 1, 0, 0, 0, 0},
            {1, 1, 1, 1, 0, 0},
            {0, 0, 0, 1, 1, 0},
            {0, 0, 1, 1, 1, 0},};

        double[][] test_Y = new double[test_N][n_outs];

        // test
        for (int i = 0; i < test_N; i++) {
          //  dbn.predict(test_X[i], test_Y[i]);
            //System.out.println("Predicted Class: "+getMaxOfOutput(test_Y[i]));
            for (int j = 0; j < n_outs; j++) {
                System.out.print(test_Y[i][j] + " ");
            }
            
            
            System.out.println();
        }
    }
    public int getMaxOfOutput(double [] output)
    {
        int res=0;
        
        double max=-1.0;
        
        for(int i=0;i<output.length;i++)
        {
            if (output[i]>max)
            {
                max=output[i];
                res=i;
            }
        }
        
        return res+1;
    }
    public int getMaxOfOutput(int [] output)
    {
        int res=0;
        
        int max=-1;
        
        for(int i=0;i<output.length;i++)
        {
            if (output[i]>max)
            {
                max=output[i];
                res=i;
            }
        }
        
        return res+1;
    }
    
    public void CountRecords(String fn) throws FileNotFoundException, IOException
    {
        int count=0;
        BufferedReader br = new BufferedReader(new FileReader(fn));
        if (br.ready() == true) {
                while (((br.readLine()) != null)) {                
                count++;
            }

            br.close();
        } else {
            System.out.println("=========================================");
            System.out.println("Source File: " + fn + " was not found!");
            System.out.println("=========================================");
        }
        numRecords=count;
    }
    public void reshuffuleDataSets()
    {
        trainingSet.clear();
        generalisationSet.clear();
        validationSet.clear();
        
        Random r = new Random(System.currentTimeMillis());
        Collections.shuffle(dataVector, r);
        int trainingSize, genSize, valSize;

        trainingSize = (int) (dataVector.size() * 0.6);
        genSize = (int) ceil(dataVector.size() * 0.2);
        valSize = dataVector.size() - trainingSize - genSize;

        for (int i = 0; i < trainingSize; i++) {
            int[] tmpP = new int[dataVector.get(i).pattern.length];
            int[] tmpT = new int[dataVector.get(i).target.length];
            for (int j = 0; j < tmpP.length; j++) {
                tmpP[j] = dataVector.get(i).pattern[j];
            }
            for (int j = 0; j < tmpT.length; j++) {
                tmpT[j] = dataVector.get(i).target[j];
            }
            trainingSet.add(new DataRecordRMB(this.n_ins,this.n_outs, tmpP, tmpT));
        }

        for (int i = trainingSize; i < (trainingSize + genSize); i++) {
            int[] tmpP = new int[dataVector.get(i).pattern.length];
            int[] tmpT = new int[dataVector.get(i).target.length];
            for (int j = 0; j < tmpP.length; j++) {
                tmpP[j] = dataVector.get(i).pattern[j];
            }
            for (int j = 0; j < tmpT.length; j++) {
                tmpT[j] = dataVector.get(i).target[j];
            }
            generalisationSet.add(new DataRecordRMB(this.n_ins, this.n_outs, tmpP, tmpT));
        }

        for (int i = trainingSize + genSize; i < dataVector.size(); i++) {
            int[] tmpP = new int[dataVector.get(i).pattern.length];
            int[] tmpT = new int[dataVector.get(i).target.length];
            for (int j = 0; j < tmpP.length; j++) {
                tmpP[j] = dataVector.get(i).pattern[j];
            }
            for (int j = 0; j < tmpT.length; j++) {
                tmpT[j] = dataVector.get(i).target[j];
            }
            validationSet.add(new DataRecordRMB(this.n_ins, this.n_outs, tmpP, tmpT));
        }
        
        this.N=trainingSet.size();
        System.out.println("DONE SHUFFLING");
    }
    public void loadDataSet(String fn) throws IOException
    {
        String rawStrs[];
        int [] inputs = new int[this.n_ins];
        int []targets = new int[this.n_outs];
        int c=0;
        double tmp;
        BufferedReader br = new BufferedReader(new FileReader(fn));
        if (br.ready() == true) {
            String sline;
            while (((sline = br.readLine()) != null)) {
                rawStrs=sline.split(",");
                c=0;
                for(int i=1;i<=rawStrs.length-1;i++)
                {
                    tmp=Double.parseDouble(rawStrs[i]);
                    
                    inputs[c]=(int)tmp;
                    c++;
                }
                targets[(int)Double.parseDouble(rawStrs[0])-1]=1;
                
                dataVector.add(new DataRecordRMB(this.n_ins,this.n_outs,inputs,targets));
                   
                for(int i=0;i<targets.length;i++)
                {
                    targets[i]=0;
                }
                
            }

            br.close();
        } else {
            System.out.println("=========================================");
            System.out.println("Source File: " + fn + " was not found!");
            System.out.println("=========================================");
        }
        
    }
    
    public int [] tSize()
    {
        int [] s=new int[3];
       s[0]= (int) (numRecords * 0.6);
        s[1]= (int) ceil(numRecords* 0.2);
        s[2] = numRecords- s[0] - s[1];
        
        return s;
    }
    /*
    public static void main(String[] args) throws IOException {        
        test_dbn();
    }
    */
}
