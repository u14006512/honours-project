package NNExperiments;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import static java.lang.Math.ceil;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;

public class Dataset {

    private List<Record> records;
    private int lableIndex;
    private List<Record> trainingSet;
    private List<Record> genSet;
    private List<Record> validSet;
    private double maxLable = -1;

    public Dataset(int classIndex) {
        trainingSet=new ArrayList<Record>();
        genSet=new ArrayList<Record>();
        validSet=new ArrayList<Record>();
        this.lableIndex = classIndex;
        records = new ArrayList<Record>();
    }
    public Dataset(int classIndex,List<Record> r) {

        this.lableIndex = classIndex;
        records = new ArrayList<Record>();
        
        for(int i=0;i<r.size();i++)
        {
            records.add(r.get(i));
        }
    }
    
    void reshuffleAndGenerateSets() {
        Random r = new Random(System.currentTimeMillis());
        Collections.shuffle(records, r);
        int trainingSize, genSize, valSize;
        trainingSet=new ArrayList<>();
        genSet=new ArrayList<>();
        validSet=new ArrayList<>();
        
        trainingSize = (int) (records.size() * 0.8);
        genSize = (int) ceil(records.size() * 0.1);
        valSize = records.size() - trainingSize - genSize;

        for (int i = 0; i < trainingSize; i++) {

            trainingSet.add(new Record(records.get(i).attrs, records.get(i).lable));
        }

        for (int i = trainingSize; i < (trainingSize + genSize); i++) {
            genSet.add(new Record(records.get(i).attrs, records.get(i).lable));
        }

        for (int i = trainingSize + genSize; i < records.size(); i++) {
            validSet.add(new Record(records.get(i).attrs, records.get(i).lable));
        }
    }
    public Dataset getTrainingSet()
    {
        return new Dataset(lableIndex,trainingSet);
    }
    
    public Dataset getValidationSet()
    {
        return new Dataset(lableIndex,genSet);
    }
    public Dataset getGenSet()
    {
        return new Dataset(lableIndex,validSet);
    }
    public Dataset(List<double[]> datas) {
        this();
        for (double[] data : datas) {
            append(new Record(data));
        }
    }

    private Dataset() {
        this.lableIndex = -1;
        records = new ArrayList<Record>();
    }

    public int size() {
        return records.size();
    }

    public int getLableIndex() {
        return lableIndex;
    }

    public void append(Record record) {
        records.add(record);
    }

    public void clear() {
        records.clear();
    }

    public void append(double[] attrs, Double lable) {
        records.add(new Record(attrs, lable));
    }

    public Iterator<Record> iter() {
        return records.iterator();
    }

    public double[] getAttrs(int index) {
        return records.get(index).getAttrs();
    }

    public Double getLable(int index) {
        return records.get(index).getLable();
    }

    public static Dataset load(String filePath, String tag, int lableIndex) {
        Dataset dataset = new Dataset();
        
        
        dataset.lableIndex = lableIndex;
        File file = new File(filePath);
        try {

            BufferedReader in = new BufferedReader(new FileReader(file));
            String line;
            while ((line = in.readLine()) != null) {
                String[] datas = line.split(tag);
                if (datas.length == 0) {
                    continue;
                }
                double[] data = new double[datas.length];
                for (int i = 0; i < datas.length; i++) {
                    data[i] = Double.parseDouble(datas[i]);
                }
                Record record = dataset.new Record(data);
                dataset.append(record);
            }
            in.close();

        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
        System.out.println("Set Size:" + dataset.size());
        return dataset;
    }

    public class Record {

        private double[] attrs;
        private Double lable;

        private Record(double[] attrs, Double lable) {
            this.attrs = attrs;
            this.lable = lable;
        }

        public Record(double[] data) {
            if (lableIndex == -1) {
                attrs = data;
            } else {
                lable = data[lableIndex];
                if (lable > maxLable) {
                    maxLable = lable;
                }
                if (lableIndex == 0) {
                    attrs = Arrays.copyOfRange(data, 1, data.length);
                } else {
                    attrs = Arrays.copyOfRange(data, 0, data.length - 1);
                }
            }
        }

        public double[] getAttrs() {
            return attrs;
        }

        public String toString() {
            StringBuilder sb = new StringBuilder();
            sb.append("attrs:");
            sb.append(Arrays.toString(attrs));
            sb.append("lable:");
            sb.append(lable);
            return sb.toString();
        }

        public Double getLable() {
            if (lableIndex == -1) {
                return null;
            }
            return lable;
        }

        public int[] getEncodeTarget(int n) {
            String binary = Integer.toBinaryString(lable.intValue());
            byte[] bytes = binary.getBytes();
            int[] encode = new int[n];
            int j = n;
            for (int i = bytes.length - 1; i >= 0; i--) {
                encode[--j] = bytes[i] - '0';
            }

            return encode;
        }

        public double[] getDoubleEncodeTarget(int n) {
            String binary = Integer.toBinaryString(lable.intValue());
            byte[] bytes = binary.getBytes();
            double[] encode = new double[n];
            int j = n;
            for (int i = bytes.length - 1; i >= 0; i--) {
                encode[--j] = bytes[i] - '0';
            }

            return encode;
        }

    }

    public static void main(String[] args) {
        Dataset d = new Dataset();
        d.lableIndex = 0;
        //Record r = d.new Record(new double[] { 13, 2, 2, 5, 4, 5, 3, 11, 3, 12,
        //		17.5});
        //int[] encode = r.getEncodeTarget(65);

        load("opt.txt", ",", 0);
        //System.out.println(r.lable);
        System.out.println("Done");
    }

    public Record getRecord(int index) {
        return records.get(index);
    }

}
