package NNExperiments;


import java.io.FileNotFoundException;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.util.Iterator;
import java.util.Vector;
import java.util.concurrent.ThreadLocalRandom;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Warmaster
 */
public class DEbinRandom1 {
    double B,pr;
    Vector<Population> populations;
    Vector<Double> contextVector;
    ObjectiveFunction obFun; ///initialised as different OBF over time
    
    int functionIndicator,dimensionIndicator,strategyIndicator;
    
    public DEbinRandom1(int ind) {
    contextVector=new Vector<>();
    populations=new Vector<>();
    B=0.5;
    pr=0.5; ///will use adaptive strategy to change B and pr over time
    functionIndicator=ind;
    strategyIndicator=0;
    dimensionIndicator=-1;
    
    switch(functionIndicator)
    {
        case 0: obFun=new FFNN_Log_Likelihood_SoftMax();
            break;
        case 1:obFun=new FFNN_Cross_Entropy_Sigmoid();
            break;
        case 2:obFun=new FFNN_MeanSquare_OwnBounded();
            break;
        case 3:obFun=new Stacked_RMB_3_Layer();
            break;
        case 4:obFun=new Stacked_RMB_5_Layer();
            break;
        case 5:obFun=new Stacked_RMB_7_Layer();
            break;    
    }
    }
    public static double bFunction(int runCount)
    {
        return -Math.log((runCount/0.75)+10)+1.85;
    }
    
    public static double prFunction(int runCount)
    {
        return -Math.log((runCount/0.75)+10)+1.85;
    }
    
    public static double poFunction(int runCount)
    {
        return -Math.log((runCount/0.75)+10)+1.85;
    }
    
    void initialiseStrategyAtStart(int initialPopCount)
    {
        populations.add(new Population());
    }
    void switchFunction(int i) {
        switch (i) {
        }
    }
    
    double[] getDimensions(int of)
    {
        return obFun.getRange();
    }
    
    void performDE_RMB_3_Layer_OPT() throws FileNotFoundException, UnsupportedEncodingException
    {
        BigDecimal [] runData=new BigDecimal[10];
        double [] pre_trained_lr=new double[10];
        double [] fine_tuned_lr=new double[10];
        int [] pre_trained_epochs=new int[10];
        int [] fine_tuned_epochs=new int[10];
        int [] layer_one_hidden_units=new int[10];
        int [] layer_two_hidden_units=new int[10];
        int [] layer_three_hidden_units=new int[10];
        
        double tmpPreTrained_lr = 0;
        double tmpPT_e=0;
        double tmpFT_e=0;
        double tmpFineTuned_lr = 0;
        int tmpPreTrained_epoches=0;
        int tmpFineTuned_epoches=0;
        
        double tmpH_1;
        int tmpHU_1 = 0;
        
        double tmpH_2;
        int tmpHU_2 = 0;
        
        double tmpH_3;
        int tmpHU_3 = 0;
        
        
        strategyIndicator=0;
        //int []dimArry={50,100,150,200,250,300,350,400,450,500,600,700,800,900,1000};
        
        int []dimArry={7};
        switchFunction(3);
        System.out.println("Running DE Experiment: DE OPTIMISATION OF STACKED RMB 3 LAYER");
        for (int i=3;i<4;i++)
        {
            
            BigDecimal s;
            System.out.println("Current Function Indicator:" +DataGatherer.getFunctionName(i));
            System.out.println("======================================================================");
            for (int j=0;j<dimArry.length;j++)
            {
                dimensionIndicator=j;
                ///Initialise Parameters for Experiment

                for (int k=0;k<10;k++)
                {
                    System.out.println("CURRENT RUN INDICATOR: "+k);
                    ///Clear and initialise populations according to strategy
                    populations=null;
                    contextVector.clear();
                    populations=new Vector<>();
                    populations.add(new Population());
                    contextVector.setSize(dimArry[dimensionIndicator]);
                    populations.get(0).B=1;
                    populations.get(0).pr=0.3;
                    ///Logic Regarding changing parameters
                    /*
                    Changing parameters should be done on a per run basis.
                    */
                    
                    ///Do the initial prime for the groupings for the dimension assignments
                    Vector<Integer> dimTmp=new Vector<>();
                    for (int hh=0;hh<contextVector.size();hh++)
                    {
                        contextVector.set(hh,0.0);
                        dimTmp.add(hh);
                    }
                    populations.get(0).initialisePopulation(dimArry[dimensionIndicator],
                            getDimensions(functionIndicator), B, pr,dimTmp);
                    
                    for (int it=0;it<1;it++)
                    {
                        System.out.println("CURRENT ITERATION OF RUN ("+k+"): "+it);
                        ///Strategy logic regarding changing parameters
                        ///Strategy logic regarding new populations
                        doIteration(obFun.getRange());
                        populations.get(0).B=populations.get(0).B-((1.0-0.7)/50);
                        populations.get(0).pr=populations.get(0).pr+((0.5-0.3)/50);
                    }
                    //Get best from that run.
                    ////Add best to list
                    
                    BigDecimal bestFit=populations.get(0).individuals.get(0).fitnessEvaluation;
                    BigDecimal tmpFit;
                    
                    for (int y=0;y<10;y++)
                    {
                        tmpFit=obFun.functionEvaluation(populations.get(0).individuals.get(y).getVector());
                        if (tmpFit.compareTo(bestFit)<0 && tmpFit.compareTo(BigDecimal.ZERO)>0)
                        {
                           
                            bestFit=tmpFit;
                            tmpPreTrained_lr=populations.get(0).individuals.get(y).positionVector.get(0);
                            tmpFineTuned_lr=populations.get(0).individuals.get(y).positionVector.get(1);
                            
                            tmpFT_e=populations.get(0).individuals.get(y).positionVector.get(2);
                            tmpPT_e=populations.get(0).individuals.get(y).positionVector.get(3);
                            
                            tmpFineTuned_epoches=(int) tmpFT_e;
                            tmpPreTrained_epoches=(int)tmpPT_e;
                            
                            tmpH_1=populations.get(0).individuals.get(y).positionVector.get(4);
                            tmpH_2=populations.get(0).individuals.get(y).positionVector.get(5);
                            tmpH_3=populations.get(0).individuals.get(y).positionVector.get(6);
                            tmpHU_1=(int)tmpH_1;
                            tmpHU_2=(int)tmpH_2;
                            tmpHU_3=(int)tmpH_3;
                        }
                    }
                    pre_trained_lr[k]=tmpPreTrained_lr;
                    fine_tuned_lr[k]=tmpFineTuned_lr;
                    fine_tuned_epochs[k]=tmpFineTuned_epoches;
                    pre_trained_epochs[k]=tmpPreTrained_epoches;
                    
                    layer_one_hidden_units[k]=tmpHU_1;
                    layer_two_hidden_units[k]=tmpHU_2;
                    layer_three_hidden_units[k]=tmpHU_3;
                    runData[k]=bestFit;
                    System.out.println("RUN FINISHED");
                }
                ///Data Reader creating a run file
                System.out.println("======================================================================");
                DataGatherer.createRunDataFile(functionIndicator, dimensionIndicator, strategyIndicator, runData,pre_trained_lr,fine_tuned_lr,fine_tuned_epochs);
            }
        }
        
    }
    void performDE_RMB_5_Layer_OPT() throws FileNotFoundException, UnsupportedEncodingException
    {
        switchFunction(4);
        BigDecimal [] runData=new BigDecimal[10];
        double [] pre_trained_lr=new double[10];
        double [] fine_tuned_lr=new double[10];
        int [] pre_trained_epochs=new int[10];
        int [] fine_tuned_epochs=new int[10];
        int [] layer_one_hidden_units=new int[10];
        int [] layer_two_hidden_units=new int[10];
        int [] layer_three_hidden_units=new int[10];
        int [] layer_four_hidden_units=new int[10];
        int [] layer_five_hidden_units=new int[10];
        
        double tmpPreTrained_lr = 0;
        double tmpPT_e=0;
        double tmpFT_e=0;
        double tmpFineTuned_lr = 0;
        int tmpPreTrained_epoches=0;
        int tmpFineTuned_epoches=0;
        
        double tmpH_1;
        int tmpHU_1 = 0;
        
        double tmpH_2;
        int tmpHU_2 = 0;
        
        double tmpH_3;
        int tmpHU_3 = 0;
        
        double tmpH_4;
        int tmpHU_4 = 0;
        
        double tmpH_5;
        int tmpHU_5 = 0;
        
        strategyIndicator=0;
        //int []dimArry={50,100,150,200,250,300,350,400,450,500,600,700,800,900,1000};
        
        int []dimArry={9};
        System.out.println("Running DE Experiment: DE OPTIMISATION OF STACKED RMB 3 LAYER");
        for (int i=3;i<4;i++)
        {
            BigDecimal s;
            System.out.println("Current Function Indicator:" +DataGatherer.getFunctionName(i));
            System.out.println("======================================================================");
            for (int j=0;j<dimArry.length;j++)
            {
                dimensionIndicator=j;
                ///Initialise Parameters for Experiment

                for (int k=0;k<10;k++)
                {
                    System.out.println("CURRENT RUN INDICATOR: "+k);
                    ///Clear and initialise populations according to strategy
                    populations=null;
                    contextVector.clear();
                    populations=new Vector<>();
                    populations.add(new Population());
                    contextVector.setSize(dimArry[dimensionIndicator]);
                    populations.get(0).B=1;
                    populations.get(0).pr=0.3;
                    ///Logic Regarding changing parameters
                    /*
                    Changing parameters should be done on a per run basis.
                    */
                    
                    ///Do the initial prime for the groupings for the dimension assignments
                    Vector<Integer> dimTmp=new Vector<>();
                    for (int hh=0;hh<contextVector.size();hh++)
                    {
                        contextVector.set(hh,0.0);
                        dimTmp.add(hh);
                    }
                    populations.get(0).initialisePopulation(dimArry[dimensionIndicator],
                            getDimensions(functionIndicator), B, pr,dimTmp);
                    
                    for (int it=0;it<10;it++)
                    {
                        System.out.println("CURRENT ITERATION OF RUN ("+k+"): "+it);
                        ///Strategy logic regarding changing parameters
                        ///Strategy logic regarding new populations
                        doIteration(obFun.getRange());
                        populations.get(0).B=populations.get(0).B-((1.0-0.7)/50);
                        populations.get(0).pr=populations.get(0).pr+((0.5-0.3)/50);
                    }
                    //Get best from that run.
                    ////Add best to list
                    
                    BigDecimal bestFit=populations.get(0).individuals.get(0).fitnessEvaluation;
                    BigDecimal tmpFit;
                    
                    for (int y=0;y<10;y++)
                    {
                        tmpFit=obFun.functionEvaluation(populations.get(0).individuals.get(y).getVector());
                        if (tmpFit.compareTo(bestFit)<0 && tmpFit.compareTo(BigDecimal.ZERO)>0)
                        {
                           
                            bestFit=tmpFit;
                            tmpPreTrained_lr=populations.get(0).individuals.get(y).positionVector.get(0);
                            tmpFineTuned_lr=populations.get(0).individuals.get(y).positionVector.get(1);
                            
                            tmpFT_e=populations.get(0).individuals.get(y).positionVector.get(2);
                            tmpPT_e=populations.get(0).individuals.get(y).positionVector.get(3);
                            
                            tmpFineTuned_epoches=(int) tmpFT_e;
                            tmpPreTrained_epoches=(int)tmpPT_e;
                            
                            tmpH_1=populations.get(0).individuals.get(y).positionVector.get(4);
                            tmpH_2=populations.get(0).individuals.get(y).positionVector.get(5);
                            tmpH_3=populations.get(0).individuals.get(y).positionVector.get(6);
                            tmpH_4=populations.get(0).individuals.get(y).positionVector.get(7);
                            tmpH_5=populations.get(0).individuals.get(y).positionVector.get(8);
                            tmpHU_1=(int)tmpH_1;
                            tmpHU_2=(int)tmpH_2;
                            tmpHU_3=(int)tmpH_3;
                            tmpHU_4=(int)tmpH_4;
                            tmpHU_5=(int)tmpH_5;
                        }
                    }
                    pre_trained_lr[k]=tmpPreTrained_lr;
                    fine_tuned_lr[k]=tmpFineTuned_lr;
                    fine_tuned_epochs[k]=tmpFineTuned_epoches;
                    pre_trained_epochs[k]=tmpPreTrained_epoches;
                    
                    layer_one_hidden_units[k]=tmpHU_1;
                    layer_two_hidden_units[k]=tmpHU_2;
                    layer_three_hidden_units[k]=tmpHU_3;
                    layer_four_hidden_units[k]=tmpHU_4;
                    layer_five_hidden_units[k]=tmpHU_5;
                    runData[k]=bestFit;
                    System.out.println("RUN FINISHED");
                }
                ///Data Reader creating a run file
                System.out.println("======================================================================");
                DataGatherer.createRunDataFile(functionIndicator, dimensionIndicator, strategyIndicator, runData,pre_trained_lr,fine_tuned_lr,fine_tuned_epochs);
            }
        }
        
    }
    void performDE_RMB_7_Layer_OPT() throws FileNotFoundException, UnsupportedEncodingException
    {
        switchFunction(5);
        BigDecimal [] runData=new BigDecimal[10];
        double [] pre_trained_lr=new double[10];
        double [] fine_tuned_lr=new double[10];
        int [] pre_trained_epochs=new int[10];
        int [] fine_tuned_epochs=new int[10];
        int [] layer_one_hidden_units=new int[10];
        int [] layer_two_hidden_units=new int[10];
        int [] layer_three_hidden_units=new int[10];
        int [] layer_four_hidden_units=new int[10];
        int [] layer_five_hidden_units=new int[10];
        int [] layer_six_hidden_units=new int[10];
        int [] layer_seven_hidden_units=new int[10];
        
        double tmpPreTrained_lr = 0;
        double tmpPT_e=0;
        double tmpFT_e=0;
        double tmpFineTuned_lr = 0;
        int tmpPreTrained_epoches=0;
        int tmpFineTuned_epoches=0;
        
        double tmpH_1;
        int tmpHU_1 = 0;
        
        double tmpH_2;
        int tmpHU_2 = 0;
        
        double tmpH_3;
        int tmpHU_3 = 0;
        double tmpH_4;
        int tmpHU_4 = 0;
        
        double tmpH_5;
        int tmpHU_5 = 0;
        
        double tmpH_6;
        int tmpHU_6 = 0;
        double tmpH_7;
        int tmpHU_7 = 0;
        
        
        strategyIndicator=0;
        //int []dimArry={50,100,150,200,250,300,350,400,450,500,600,700,800,900,1000};
        
        int []dimArry={11};
        System.out.println("Running DE Experiment: DE OPTIMISATION OF STACKED RMB 3 LAYER");
        for (int i=3;i<4;i++)
        {
            BigDecimal s;
            System.out.println("Current Function Indicator:" +DataGatherer.getFunctionName(i));
            System.out.println("======================================================================");
            for (int j=0;j<dimArry.length;j++)
            {
                dimensionIndicator=j;
                ///Initialise Parameters for Experiment

                for (int k=0;k<10;k++)
                {
                    System.out.println("CURRENT RUN INDICATOR: "+k);
                    ///Clear and initialise populations according to strategy
                    populations=null;
                    contextVector.clear();
                    populations=new Vector<>();
                    populations.add(new Population());
                    contextVector.setSize(dimArry[dimensionIndicator]);
                    populations.get(0).B=1;
                    populations.get(0).pr=0.3;
                    ///Logic Regarding changing parameters
                    /*
                    Changing parameters should be done on a per run basis.
                    */
                    
                    ///Do the initial prime for the groupings for the dimension assignments
                    Vector<Integer> dimTmp=new Vector<>();
                    for (int hh=0;hh<contextVector.size();hh++)
                    {
                        contextVector.set(hh,0.0);
                        dimTmp.add(hh);
                    }
                    populations.get(0).initialisePopulation(dimArry[dimensionIndicator],
                            getDimensions(functionIndicator), B, pr,dimTmp);
                    
                    for (int it=0;it<10;it++)
                    {
                        System.out.println("CURRENT ITERATION OF RUN ("+k+"): "+it);
                        ///Strategy logic regarding changing parameters
                        ///Strategy logic regarding new populations
                        doIteration(obFun.getRange());
                        populations.get(0).B=populations.get(0).B-((1.0-0.7)/50);
                        populations.get(0).pr=populations.get(0).pr+((0.5-0.3)/50);
                    }
                    //Get best from that run.
                    ////Add best to list
                    
                    BigDecimal bestFit=populations.get(0).individuals.get(0).fitnessEvaluation;
                    BigDecimal tmpFit;
                    
                    for (int y=0;y<10;y++)
                    {
                        tmpFit=obFun.functionEvaluation(populations.get(0).individuals.get(y).getVector());
                        if (tmpFit.compareTo(bestFit)<0 && tmpFit.compareTo(BigDecimal.ZERO)>0)
                        {
                           
                            bestFit=tmpFit;
                            tmpPreTrained_lr=populations.get(0).individuals.get(y).positionVector.get(0);
                            tmpFineTuned_lr=populations.get(0).individuals.get(y).positionVector.get(1);
                            
                            tmpFT_e=populations.get(0).individuals.get(y).positionVector.get(2);
                            tmpPT_e=populations.get(0).individuals.get(y).positionVector.get(3);
                            
                            tmpFineTuned_epoches=(int) tmpFT_e;
                            tmpPreTrained_epoches=(int)tmpPT_e;
                            
                            tmpH_1=populations.get(0).individuals.get(y).positionVector.get(4);
                            tmpH_2=populations.get(0).individuals.get(y).positionVector.get(5);
                            tmpH_3=populations.get(0).individuals.get(y).positionVector.get(6);
                            tmpH_4=populations.get(0).individuals.get(y).positionVector.get(7);
                            tmpH_5=populations.get(0).individuals.get(y).positionVector.get(8);
                            tmpH_6=populations.get(0).individuals.get(y).positionVector.get(9);
                            tmpH_7=populations.get(0).individuals.get(y).positionVector.get(10);
                            tmpHU_1=(int)tmpH_1;
                            tmpHU_2=(int)tmpH_2;
                            tmpHU_3=(int)tmpH_3;
                            tmpHU_4=(int)tmpH_4;
                            tmpHU_5=(int)tmpH_5;
                            tmpHU_6=(int)tmpH_6;
                            tmpHU_7=(int)tmpH_7;
                        }
                    }
                    pre_trained_lr[k]=tmpPreTrained_lr;
                    fine_tuned_lr[k]=tmpFineTuned_lr;
                    fine_tuned_epochs[k]=tmpFineTuned_epoches;
                    pre_trained_epochs[k]=tmpPreTrained_epoches;
                    
                    layer_one_hidden_units[k]=tmpHU_1;
                    layer_two_hidden_units[k]=tmpHU_2;
                    layer_three_hidden_units[k]=tmpHU_3;
                    layer_four_hidden_units[k]=tmpHU_4;
                    layer_five_hidden_units[k]=tmpHU_5;
                    layer_six_hidden_units[k]=tmpHU_6;
                    layer_seven_hidden_units[k]=tmpHU_7;
                    
                    runData[k]=bestFit;
                    System.out.println("RUN FINISHED");
                }
                ///Data Reader creating a run file
                System.out.println("======================================================================");
                DataGatherer.createRunDataFile(functionIndicator, dimensionIndicator, strategyIndicator, runData,pre_trained_lr,fine_tuned_lr,fine_tuned_epochs);
            }
        }
    }
    void performDE_FFNN() throws FileNotFoundException, UnsupportedEncodingException
    {
        BigDecimal [] runData=new BigDecimal[10];
        double [] learningData=new double[10];
        double [] momentumData=new double[10];
        int [] hiddenUnitsData=new int[10];
        
        double tmpLearn = 0;
        double tmpMom = 0;
        double tmpH;
        int tmpHU = 0;
        
        
        strategyIndicator=0;
        //int []dimArry={50,100,150,200,250,300,350,400,450,500,600,700,800,900,1000};
        
        int []dimArry={3};
        System.out.println("Running DE Experiment: DE OPTIMISATION");
        for (int i=0;i<1;i++)
        {
            BigDecimal s;
            switchFunction(i);
            System.out.println("Current Function Indicator:" +DataGatherer.getFunctionName(i));
            System.out.println("Current Dimension Lower Bound:"+obFun.getRange()[0]);
            System.out.println("Current Dimension Upper Bound:"+obFun.getRange()[1]);
            System.out.println("======================================================================");
            for (int j=0;j<dimArry.length;j++)
            {
                dimensionIndicator=j;
                ///Initialise Parameters for Experiment

                for (int k=0;k<10;k++)
                {
                    System.out.println("CURRENT RUN INDICATOR: "+k);
                    ///Clear and initialise populations according to strategy
                    populations=null;
                    contextVector.clear();
                    populations=new Vector<>();
                    populations.add(new Population());
                    contextVector.setSize(dimArry[dimensionIndicator]);
                    populations.get(0).B=1;
                    populations.get(0).pr=0.3;
                    ///Logic Regarding changing parameters
                    /*
                    Changing parameters should be done on a per run basis.
                    */
                    
                    ///Do the initial prime for the groupings for the dimension assignments
                    Vector<Integer> dimTmp=new Vector<>();
                    for (int hh=0;hh<contextVector.size();hh++)
                    {
                        contextVector.set(hh,0.0);
                        dimTmp.add(hh);
                    }
                    populations.get(0).initialisePopulation(dimArry[dimensionIndicator],
                            getDimensions(functionIndicator), B, pr,dimTmp);
                    
                    for (int it=0;it<10;it++)
                    {
                        System.out.println("CURRENT ITERATION OF RUN ("+k+"): "+it);
                        ///Strategy logic regarding changing parameters
                        ///Strategy logic regarding new populations
                        doIteration(obFun.getRange());
                        populations.get(0).B=populations.get(0).B-((1.0-0.7)/50);
                        populations.get(0).pr=populations.get(0).pr+((0.5-0.3)/50);
                    }
                    //Get best from that run.
                    ////Add best to list
                    
                    BigDecimal bestFit=populations.get(0).individuals.get(0).fitnessEvaluation;
                    BigDecimal tmpFit;
                    
                    for (int y=0;y<10;y++)
                    {
                        tmpFit=obFun.functionEvaluation(populations.get(0).individuals.get(y).getVector());
                        if (tmpFit.compareTo(bestFit)<0 && tmpFit.compareTo(BigDecimal.ZERO)>0)
                        {
                           
                            bestFit=tmpFit;
                            tmpLearn=populations.get(0).individuals.get(y).positionVector.get(0);
                            tmpMom=populations.get(0).individuals.get(y).positionVector.get(1);
                            tmpH=populations.get(0).individuals.get(y).positionVector.get(2);
                            tmpHU=(int)tmpH;
                        }
                    }
                    learningData[k]=tmpLearn;
                    momentumData[k]=tmpMom;
                    hiddenUnitsData[k]=tmpHU;
                    runData[k]=bestFit;
                    System.out.println("RUN FINISHED");
                }
                ///Data Reader creating a run file
                System.out.println("======================================================================");
                DataGatherer.createRunDataFile(functionIndicator, dimensionIndicator, strategyIndicator, runData,learningData,momentumData,hiddenUnitsData);
            }
        }
        
    }
    
    /**
     Eval Fitness of current particle
     * Create Trail Vector
     * Create Offspring using Crossover
     * if better, replace parent
     */
    
    //Context Vector Maintained out this function
    void doIteration(double [] range)
    {
        BigDecimal bestPopFitness;
        int tmpIndex=0;
        ///Fitness Evaluations
        Vector<Double> conTmp=new Vector<>();
        for (int v=0;v<contextVector.size();v++)
        {
            conTmp.add(contextVector.get(v));
        }
        
        for (int z=0;z<populations.size();z++)
        {
            
            bestPopFitness=populations.get(z).individuals.get(0).fitnessEvaluation;
            tmpIndex=0;
            for(int i=0;i<populations.get(z).individuals.size();i++)
            {
                for(int w=0;w<populations.get(z).sizeOfDimensionComponent;w++)
                {
                conTmp.set(populations.get(z).dimensionComponents.get(w),
                        populations.get(z).individuals.get(i).positionVector.get(w));
                
                }
                populations.get(z).individuals.get(i).fitnessEvaluation=
                        obFun.functionEvaluation(populations.get(z).individuals.get(i).positionVector);
                if (populations.get(z).individuals.get(i).fitnessEvaluation.compareTo(bestPopFitness)<0)
                {
                    bestPopFitness=populations.get(z).individuals.get(i).fitnessEvaluation;
                    tmpIndex=i;
                } 
                conTmp.clear();
                for (int v=0;v<contextVector.size();v++)
                {
                    conTmp.add(contextVector.get(v));
                }
            }
            populations.get(z).currentBestPopBestIndividualIndex=tmpIndex;
            
        }
        int x1,x2,x3;
        Vector<Double> trialVector=new Vector<>();
        Vector<Integer> crossovervector=new Vector<>();
        Vector<Double> offspring=new Vector<>();
        
        ///Actual Iteration Components X-Over, Mutation etc
        for (int z=0;z<populations.size();z++)
        {
            for(int i=0;i<populations.get(z).individuals.size();i++)
            {
                ///Mutation
                trialVector.clear();
                x1=i;
                x2=0;
                x3=0;
                
                while(x1==x2 || x2==x3 || x1==x3)
                {
                    x2=ThreadLocalRandom.current().nextInt(populations.get(z).individuals.size());
                    x3=ThreadLocalRandom.current().nextInt(populations.get(z).individuals.size());
                }
                
                for (int h=0;h<populations.get(z).individuals.get(i).dimensions;h++)
                {
                    trialVector.add(populations.get(z).individuals.get(x1).positionVector.get(h)
                            +B*((populations.get(z).individuals.get(x2).positionVector.get(h))
                            -populations.get(z).individuals.get(x3).positionVector.get(h)));
                }
                
                
                ///CrossOver
                ///0 equals parents, 1 equals trial vector
                crossovervector.clear();
                for (int x=0;x<populations.get(z).individuals.get(i).positionVector.size();x++)
                {
                    crossovervector.add(0);
                }
                int randS=ThreadLocalRandom.current().nextInt(populations.get(z).individuals.get(i).positionVector.size());
                crossovervector.set(randS,1);
                
                double tmpChance;
                
                for (int jj=0;jj<crossovervector.size();jj++)
                {
                    tmpChance=ThreadLocalRandom.current().nextDouble();
                    if (tmpChance<pr && jj!=randS)
                    {
                        crossovervector.set(jj, 1);
                    }
                    
                }
                offspring.clear();
                BigDecimal tmpFitness;
                
                for (int jj=0;jj<crossovervector.size();jj++)
                {
                    if (crossovervector.get(jj)==0)
                    {
                        offspring.add(populations.get(z).individuals.get(i).positionVector.get(jj));
                    } else 
                        {
                            offspring.add(trialVector.get(jj));
                        }
                }
                
                tmpFitness=obFun.functionEvaluation(offspring);
                
                
                if (tmpFitness.compareTo(populations.get(z).individuals.get(i).fitnessEvaluation)<0 &&
                        varsInRange(offspring,range)==true && tmpFitness.compareTo(BigDecimal.ZERO)>0)
                {
                   
                   populations.get(z).individuals.get(i).setPositionVector(offspring);
                   populations.get(z).individuals.get(i).fitnessEvaluation=tmpFitness;
                }
            }
        }
        
        
    }
    
    boolean varsInRange(Vector<Double> vars,double [] range)
    {
        if (vars.get(2)>=65){
            System.out.println("MMM");
        }
        int count1=0,count2=1;
        for(int i=0;i<vars.size();i++)
        {
            if (vars.get(i)<range[count1] || vars.get(i)>range[count2]) return false;
            count1+=2;
            count2+=2;
        }
        return true;
    
    }    
}
