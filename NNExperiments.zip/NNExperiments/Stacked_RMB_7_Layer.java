package NNExperiments;


import java.io.IOException;
import java.math.BigDecimal;
import java.util.Random;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Warmaster
 */
public class Stacked_RMB_7_Layer extends ObjectiveFunction {
    
    public  BigDecimal functionEvaluation(Vector<Double> inputs){ 
        BigDecimal result = new BigDecimal(0);
        
Random rng = new Random(System.currentTimeMillis());
        double error = 0;
        double t;
        double pretrain_lr = inputs.get(0);
        double finetune_lr = inputs.get(1);

        t = inputs.get(2);
        int finetune_epochs = (int) t;
        t = inputs.get(3);
        int pretraining_epochs = (int) t;
        int k = 1;

        int n_ins = 324;
        int n_outs = 62;
        int[] hidden_layer_sizes_in = new int[7];
        int tmpc = 0;

        if (pretrain_lr > 1.0) {
            pretrain_lr = 1;
        }
        if (pretrain_lr < 0.0) {
            pretrain_lr = 0.1;
        }

        if (finetune_lr > 1.0) {
            pretrain_lr = 1;
        }
        if (finetune_lr < 0.0) {
            pretrain_lr = 0.1;
        }

        if (pretraining_epochs > 5000.0) {
            pretrain_lr = 5000;
        }
        if (pretraining_epochs < 0.0) {
            pretrain_lr = 1000;
        }

        if (finetune_epochs > 3000.0) {
            finetune_epochs = 3000;
        }
        if (finetune_epochs < 0.0) {
            finetune_epochs = 1000;
        }

        for (int i = 4; i <= 10; i++) {
            t = inputs.get(i);

            if (t> 300.0) {
                t = 300;
            }
            if (t < 0.0) {
                t = 10;
            }

            hidden_layer_sizes_in[tmpc] = (int) t;
        }

        int n_layers = hidden_layer_sizes_in.length;

        String fn = "normalised_features_opt_file.txt";

        // construct DNN.DBN
        DBN dbn = new DBN(372, n_ins, hidden_layer_sizes_in, n_outs, n_layers, rng);
        try {
            dbn.loadDataSet(fn);
        } catch (IOException ex) {
            Logger.getLogger(Stacked_RMB_3_Layer.class.getName()).log(Level.SEVERE, null, ex);
        }
        dbn.reshuffuleDataSets();
        // pretrain

        dbn.pretrain(dbn.trainingSet, pretrain_lr, k, pretraining_epochs);

        // finetune
        dbn.finetune(dbn.trainingSet, dbn.trainingSet, finetune_lr, finetune_epochs);

        double[][] test_Y = new double[dbn.validationSet.size()][n_outs];
        int tmp;
        int tmp2;
        // test
        for (int i = 0; i < dbn.validationSet.size(); i++) {
            dbn.predict(dbn.validationSet.get(i).pattern, test_Y[i]);
            tmp = dbn.getMaxOfOutput(test_Y[i]);
            tmp2 = dbn.getMaxOfOutput(dbn.validationSet.get(i).target);
            error = error + Math.pow(tmp - tmp2, 2);

        }
        result = new BigDecimal(error / dbn.validationSet.size());
        return result;
    }

    
    public  double[] getRange() {
        double s[]=new double[24];
        s[0] = 0.1;
        s[1] = 1;
        s[2] = 0.1;
        s[3] = 1;
        s[4] = 1000.0;
        s[5] = 3000.0;
        s[6] = 1000.0;
        s[7] = 5000.0;
        s[8] = 1.0;
        s[9] = 5.0;
        s[10] = 10.0;
        s[11] = 30.0;
        s[12] = 10.0;
        s[13] = 300.0;
        s[14] = 10.0;
        s[15] = 300.0;
        s[16] = 10.0;
        s[17] = 300.0;
        s[18] = 10.0;
        s[19] = 300.0;
        s[20] = 10.0;
        s[21] = 300.0;
        s[22] = 10.0;
        s[23] = 300.0;
    return s;
    }
}
