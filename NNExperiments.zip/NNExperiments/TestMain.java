/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package NNExperiments;

import java.io.IOException;
import java.util.Random;

/**
 *
 * @author Warmaster
 */
public class TestMain {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        Random rng = new Random(System.currentTimeMillis());
        double error=0;
        int countRight=0;
        
        double pretrain_lr = 0.1;
        int pretraining_epochs = 3000;
        int k = 1;
        double finetune_lr = 0.1;
        int finetune_epochs = 2000;

        int n_ins = 324;
        int n_outs = 62;
        int[] hidden_layer_sizes_in = {200,100,50, 100, 200};
        int n_layers = hidden_layer_sizes_in.length;
        String fn="normalised_features_opt_file.txt";
        DBN s=new DBN(fn,n_ins, hidden_layer_sizes_in,n_outs, n_layers, rng);
        s.loadDataSet(fn);
        s.reshuffuleDataSets();
        
        // construct DNN.DBN
        System.out.println("Constructing Deep Net");
        DBN dbn = new DBN(s.trainingSet.size(), n_ins, hidden_layer_sizes_in, n_outs, n_layers, rng);

        // pretrain
        System.out.println("Pretraining Deep Net");
        dbn.pretrain(s.trainingSet, pretrain_lr, k, pretraining_epochs);

        // finetune
        System.out.println("Fine Tuning Net");
        dbn.finetune(s.trainingSet, s.trainingSet, finetune_lr, finetune_epochs);
        
        System.out.println("Net Fine Tuned- Starting Prediction");
        double[][] test_Y = new double[s.trainingSet.size()][n_outs];
        int tmp;
        int tmp2;
        // test
        for (int i = 0; i < s.trainingSet.size(); i++) {
            dbn.predict(s.trainingSet.get(i).pattern, test_Y[i]);
            tmp=s.getMaxOfOutput(test_Y[i]);
            tmp2=s.getMaxOfOutput(s.trainingSet.get(i).target);
            if (tmp==tmp2)
            {
                countRight++;
            }
            error=error+Math.pow(tmp-tmp2, 2);
            System.out.println("Predicted Class: "+tmp);
            System.out.println("Actual Class: "+tmp2);
            //for (int j = 0; j < n_outs; j++) {
           //     System.out.print(test_Y[i][j] + " ");
            //}
            
            
            System.out.println();
        }
        System.out.println("Accuracy: "+(100.0*(countRight)/(s.trainingSet.size())));
        System.out.println("Accuracy: "+(error/s.trainingSet.size()));
        
    }
    
}
