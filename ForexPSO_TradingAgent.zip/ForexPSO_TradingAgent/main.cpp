#include <iostream>
#include <vector>

using namespace std;
int main() {
    std::cout << "Hello, World!" << std::endl;
    double * a=new double[3];

    a[0]=1;
    a[1]=2;

    vector<double> b;

    b.resize(4);

    b.at(0)=1;
    b.at(1)=2;
    cout<<a[0]<<endl;
    return 0;
}