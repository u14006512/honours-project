package Ass2;

import java.awt.BorderLayout;
import java.awt.image.BufferedImage;
import java.awt.image.Raster;
import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.Vector;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.WindowConstants;
import org.jtransforms.fft.DoubleFFT_2D;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Warmaster
 */
public class PhaseCongruencyEdgeDetector {

    String fn;
    int row, col;

    DoubleFFT_2D fourier;

    int nscale = 4;
    int norient = 6;
    int minWaveLength = 3;
    int multFactor = 2;
    double sigmaONF = 0.55;
    double dThetaOnSigma = 1.2;
    double k = 2.0;

    double cutoff = 0.4;
    int g = 10;
    double epsilon = 0.0001;
    double thetaSigma = (Math.PI / norient) / dThetaOnSigma;

    BufferedImage imageOriginal;
    BufferedImage transformedImage;

    int[][] pixelMap;
    double[][] imagefft;
    int[][] phaseCongruency;

    double[][] energyTotalMatrix;
    double[][] totalSumAmplitudeMatrix;
    double[][] orientationEnergyMatrix;
    double[][] ones;

    public PhaseCongruencyEdgeDetector(String f) throws IOException {
        this.fn = f;
        imageOriginal = ImageIO.read(new File(fn));

        row = imageOriginal.getHeight();
        col = imageOriginal.getWidth();

        pixelMap = producePixelMatrix(imageOriginal);
        energyTotalMatrix = new double[row][col];
        orientationEnergyMatrix = new double[row][col];
        totalSumAmplitudeMatrix = new double[row][col];
        imagefft = new double[row][2 * col];
        ones = new double[row][col];
        phaseCongruency = new int[row][col];

        for (int i = 0; i < ones.length; i++) {
            for (int j = 0; j < col; j++) {
                ones[i][j] = 1.0;
            }
        }

        setFFT2();
        displayOriginalImage();

        this.fn = fn.substring(0, fn.indexOf("."));

        System.out.println("Finished Init");
    }

    public void displayOriginalImage() {
        JFrame editorFrame = new JFrame("Phase Congruency Detection- Original Image");
        editorFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        ImageIcon imageIcon = new ImageIcon(this.imageOriginal);
        JLabel jLabel = new JLabel();
        jLabel.setIcon(imageIcon);
        editorFrame.getContentPane().add(jLabel, BorderLayout.CENTER);

        editorFrame.pack();
        editorFrame.setLocationRelativeTo(null);
        editorFrame.setVisible(true);
    }

    private int[][] producePixelMatrix(BufferedImage image) {
        int h = image.getHeight();
        int w = image.getWidth();
        int[][] result = new int[h][w];
        Raster r = image.getData();

        for (int i = 0; i < h; i++) {
            for (int j = 0; j < w; j++) {
                result[i][j] = r.getSample(i, j, 0);
            }
        }

        return result;
    }

    private void setFFT2() {
        fourier = new DoubleFFT_2D(row, col);

        double[][] map = new double[row][2 * col];
        for (int i = 0; i < row; i++) {
            for (int j = 0; j < col; j++) {
                map[i][j] = pixelMap[j][i];
            }
        }

        fourier.realForwardFull(map);

        for (int i = 0; i < row; i++) {
            for (int j = 0; j < map[i].length; j++) {
                if (j == 0 || j % 2 == 0) {
                    //pixelMap[i][cc] = (int) map[i][j];
                    imagefft[i][j] = map[i][j];
                } else {
                    imagefft[i][j] = map[i][j];
                }

            }
        }
    }

    public void doPhaseCongruencyProcess() throws IOException {
        //Computing the X component of the Filter

        int[][] x = new int[row][col];

        for (int i = 0; i < row; i++) {
            x[i][col / 2] = 0;
        }
        //Left Split side->go down
        int val = -1;
        for (int j = (col / 2) - 1; j >= 0; j--) {
            for (int i = 0; i < row; i++) {
                x[i][j] = val;
            }
            val--;
        }
        //right split ->go up
        val = 1;
        for (int j = (col / 2) + 1; j < col; j++) {
            for (int i = 0; i < row; i++) {
                x[i][j] = val;
            }
            val++;
        }

        //Computing the Y Component of the Filter
        int[][] y = new int[row][col];

        for (int i = 0; i < row; i++) {
            y[col / 2][i] = 0;
        }
        //Left Split side->go down
        val = -1;
        for (int j = (col / 2) - 1; j >= 0; j--) {
            for (int i = 0; i < row; i++) {
                y[j][i] = val;
            }
            val--;
        }
        //right split ->go up
        val = 1;
        for (int j = (col / 2) + 1; j < col; j++) {
            for (int i = 0; i < row; i++) {
                y[j][i] = val;
            }
            val++;
        }
        /*
        for (int i = 0; i < x.length; i++) {
                    for (int j = 0; j < x[i].length - 1; j++) {
                        System.out.print(x[i][j] + ",");
                    }
                    System.out.print(x[i][x[i].length - 1]);
                    System.out.println("");
                }
        System.out.println("+++");
        
        for (int i = 0; i < y.length; i++) {
                    for (int j = 0; j < y[i].length - 1; j++) {
                        System.out.print(y[i][j] + ",");
                    }
                    System.out.print(y[i][y[i].length - 1]);
                    System.out.println("");
                }
         */
        //Radius
        double[][] radius = new double[row][col];

        for (int i = 0; i < row; i++) {
            for (int j = 0; j < col; j++) {
                radius[i][j] = Math.sqrt(Math.pow(x[i][j], 2) + Math.pow(y[i][j], 2));
            }
        }

        radius[row / 2][col / 2] = 1;
        /*
        for (int i = 0; i < radius.length; i++) {
                    for (int j = 0; j < radius[i].length - 1; j++) {
                        System.out.printf(radius[i][j] + ",");
                    }
                    System.out.print(radius[i][radius[i].length - 1]);
                    System.out.println("");
                }
         */
        double[][] theta = new double[row][col];

        for (int i = 0; i < row; i++) {
            for (int j = 0; j < col; j++) {
                theta[i][j] = Math.atan2(-y[i][j], x[i][j]);
            }
        }
        for (int i = 0; i < col / 2; i++) {
            theta[row / 2][i] = theta[row / 2][i] * -1;
        }
        /*
        for (int i = 0; i < theta.length; i++) {
                    for (int j = 0; j < theta[i].length - 1; j++) {
                        System.out.printf(theta[i][j] + ",");
                    }
                    System.out.print(theta[i][theta[i].length - 1]);
                    System.out.println("");
                }
         */
        System.out.println("A");
        x = null;
        y = null;

        //Main Loop
        double angle;
        int waveLen;
        double currSumE[][] = new double[row][col];
        double currSumO[][] = new double[row][col];
        double currSumAn[][] = new double[row][col];
        double currEnergy[][] = new double[row][col];
        double ds[][] = new double[row][col];
        double dc[][] = new double[row][col];
        double dTheta[][] = new double[row][col];
        double[][] spread = new double[row][col];
        double[][] X_Energy = new double[row][col];
        double[][] MeanE = new double[row][col];
        double[][] MeanO = new double[row][col];
        double[][] Energy_ThisOrient = new double[row][col];
        double[] medianArray = new double[row * col];
        double[][] tmpEO = new double[row][2 * col];
        double[][] tmpEO_Final = new double[row][col];
        double medianE2n = 0.0;
        double meanE2n = 0.0;
        double noisePower = 0.0;
        double[][] EstSumAn2 = new double[row][col];
        double[][] EstSumAiAj = new double[row][col];
        double EstNoiseEnergy = 0.0;
        double EstNoiseEnergy2 = 0.0;
        double EstNoiseEnergySigma = 0.0;
        double t1 = 0.0, t2 = 0.0;
        double tau = 0.0;
        //nscale loop
        double fo;
        double rfo;
        double logGabor[][] = new double[row][col];
        double[][] filterFake = new double[row][2 * col];
        double[][] filterReal = new double[row][col];
        double[][] filterConvolve = new double[row][col];
        double[][] EOfft = new double[row][col * 2];
        double[][] EOfake = new double[row][col * 2];
        double[][] EO = new double[row][col * 2];
        double[][] An = new double[row][col];
        double[][] maxMatrix = new double[row][col];
        double[][] EM_n_Matrix = new double[row][col];
        double em_n = 0.0;
        double T = 0.0;
        double[][] width = new double[row][col];
        double[][] weight = new double[row][col];
        double[][] maxEnergy = new double[row][col];
        double[][] changeA = new double[row][col];
        double[][] changeB = new double[row][col];

        Vector<Double> estMeanE2nVector = new Vector<>();
        Vector<Matrix> filterVector = new Vector<>();
        Vector<Matrix> EOVector = new Vector<>();

        ///Quandrants inside nscale loop
        double[][] q1 = new double[row / 2][col / 2];
        double[][] q2 = new double[row / 2][col / 2];
        double[][] q3 = new double[row / 2][col / 2];
        double[][] q4 = new double[row / 2][col / 2];
        int qR, qC, s;

        ///set to norient
        for (int o = 1; o <= 1; o++) {
            System.out.println("Processing Orientation: " + o);

            angle = (o - 1) * (Math.PI / norient);

            waveLen = minWaveLength;

            //Clear and Re-init the accumulator matrices
            for (int i = 0; i < row; i++) {
                for (int j = 0; j < col; j++) {
                    currEnergy[i][j] = 0;
                    currSumAn[i][j] = 0;
                    currSumE[i][j] = 0;
                    currSumO[i][j] = 0;
                    ds[i][j] = 0;
                    dc[i][j] = 0;
                    dTheta[i][j] = 0;
                    spread[i][j] = 0;
                    logGabor[i][j] = 0;
                }
            }
            filterVector.clear();
            EOVector.clear();

            for (int i = 0; i < row; i++) {
                for (int j = 0; j < col; j++) {
                    ds[i][j] = (Math.sin(theta[i][j]) * Math.cos(angle))
                            - (Math.sin(angle) * Math.cos(theta[i][j]));
                }
            }

            for (int i = 0; i < row; i++) {
                for (int j = 0; j < col; j++) {
                    dc[i][j] = (Math.cos(theta[i][j]) * Math.cos(angle))
                            + (Math.sin(angle) * Math.sin(theta[i][j]));
                }
            }
            /*
            for (int i = 0; i < dc.length; i++) {
                    for (int j = 0; j < dc[i].length - 1; j++) {
                        System.out.printf(dc[i][j] + ",");
                    }
                    System.out.print(dc[i][dc[i].length - 1]);
                    System.out.println("");
                }
             */

            for (int i = 0; i < row; i++) {
                for (int j = 0; j < col; j++) {
                    dTheta[i][j] = Math.abs(Math.atan2(ds[i][j], dc[i][j]));
                }
            }
            /*
            for (int i = 0; i < dTheta.length; i++) {
                    for (int j = 0; j < dTheta[i].length - 1; j++) {
                        System.out.printf(dTheta[i][j] + ",");
                    }
                    System.out.print(dTheta[i][dTheta[i].length - 1]);
                    System.out.println("");
                }
             */
            for (int i = 0; i < row; i++) {
                for (int j = 0; j < col; j++) {
                    spread[i][j] = Math.exp(-Math.pow(dTheta[i][j], 2) / (2 * Math.pow(thetaSigma, 2)));
                }
            }
            /*
            for (int i = 0; i < spread.length; i++) {
                for (int j = 0; j < spread[i].length - 1; j++) {
                    System.out.printf(spread[i][j] + ",");
                }
                System.out.print(spread[i][spread[i].length - 1]);
                System.out.println("");
            }
             */
            ///replace 1 with nscale
            for (s = 1; s <= 1; s++) {
                //Filter Construction
                fo = 1.0 / waveLen;
                rfo = (fo / 0.5) * (col / 2);

                for (int i = 0; i < row; i++) {
                    for (int j = 0; j < col; j++) {
                        logGabor[i][j] = Math.exp((-(Math.pow(Math.log(radius[i][j] / rfo), 2)))
                                / (2 * (Math.pow(Math.log(sigmaONF), 2))));
                    }
                }
                logGabor[row / 2][col / 2] = 0;
                /*
                for (int i = 0; i < logGabor.length; i++) {
                    for (int j = 0; j < logGabor[i].length - 1; j++) {
                        System.out.printf(logGabor[i][j] + ",");
                    }
                    System.out.print(logGabor[i][logGabor[i].length - 1]);
                    System.out.println("");
                }
                 */

                for (int i = 0; i < row; i++) {
                    for (int j = 0; j < col; j++) {
                        filterFake[i][j] = logGabor[i][j] * spread[i][j];
                        filterConvolve[i][j] = logGabor[i][j] * spread[i][j];
                    }
                }

                /*
                for (int i = 0; i < filterConvolve.length; i++) {
                    for (int j = 0; j < filterConvolve[i].length - 1; j++) {
                        System.out.printf(filterConvolve[i][j] + ",");
                    }
                    System.out.print(filterConvolve[i][filterConvolve[i].length - 1]);
                    System.out.println("");
                }
                 */
                //Quadrant Swapping
                //First record all quadrants
                //Q1:Top Left
                qR = 0;
                qC = 0;

                for (int i = 0; i <= (row / 2) - 1; i++) {
                    qC = 0;
                    for (int j = 0; j <= (col / 2) - 1; j++) {
                        q1[qR][qC] = filterFake[i][j];
                        qC++;
                    }
                    qR++;
                }
                //Q2:Top Right
                qR = 0;
                qC = 0;
                for (int i = 0; i <= (row / 2) - 1; i++) {
                    qC = 0;
                    for (int j = col / 2; j < col; j++) {
                        q2[qR][qC] = filterFake[i][j];
                        qC++;
                    }
                    qR++;
                }
                //Q3:Bottom Left
                qR = 0;
                qC = 0;
                for (int i = row / 2; i < row; i++) {
                    qC = 0;
                    for (int j = col / 2; j < col; j++) {
                        q3[qR][qC] = filterFake[i][j];
                        qC++;
                    }
                    qR++;
                }

                //Q4:Bottom Right
                qR = 0;
                qC = 0;
                for (int i = row / 2; i < row; i++) {
                    qC = 0;
                    for (int j = 0; j <= (col / 2) - 1; j++) {
                        q4[qR][qC] = filterFake[i][j];
                        qC++;
                    }
                    qR++;
                }
                //Then swap 1 with 3, and 2 with 4
                qR = 0;
                qC = 0;
                for (int i = 0; i <= (row / 2) - 1; i++) {
                    qC = 0;
                    for (int j = 0; j <= (col / 2) - 1; j++) {
                        filterFake[i][j] = q3[qR][qC];
                        filterConvolve[i][j] = q3[qR][qC];
                        qC++;
                    }
                    qR++;
                }
                qR = 0;
                qC = 0;
                for (int i = (row / 2); i < row; i++) {
                    qC = 0;
                    for (int j = col / 2; j < col; j++) {
                        filterFake[i][j] = q1[qR][qC];
                        filterConvolve[i][j] = q1[qR][qC];
                        qC++;
                    }
                    qR++;
                }
                qR = 0;
                qC = 0;
                for (int i = 0; i <= (row / 2) - 1; i++) {
                    qC = 0;
                    for (int j = col / 2; j < col; j++) {
                        filterFake[i][j] = q4[qR][qC];
                        filterConvolve[i][j] = q4[qR][qC];
                        qC++;
                    }
                    qR++;
                }
                qR = 0;
                qC = 0;
                for (int i = (row / 2); i < row; i++) {
                    qC = 0;
                    for (int j = 0; j <= (col / 2) - 1; j++) {
                        filterFake[i][j] = q2[qR][qC];
                        filterConvolve[i][j] = q2[qR][qC];
                        qC++;
                    }
                    qR++;
                }
                /*
                for (int i = 0; i < filterConvolve.length; i++) {
                    for (int j = 0; j < filterConvolve[i].length - 1; j++) {
                        System.out.printf(filterConvolve[i][j] + ",");
                    }
                    System.out.print(filterConvolve[i][filterConvolve[i].length - 1]);
                    System.out.println("");
                }
                 */
                //Now compute the inverse of filterFake
                fourier.realInverseFull(filterFake, true);

                int cc = 0;
                for (int i = 0; i < row; i++) {
                    cc = 0;
                    for (int j = 0; j < filterFake[i].length; j++) {
                        if (j == 0 || j % 2 == 0) {
                            filterReal[i][cc] = filterFake[i][j];
                            cc++;
                        }
                    }
                }

                for (int i = 0; i < row; i++) {
                    for (int j = 0; j < col; j++) {
                        filterReal[i][j] = filterReal[i][j] * Math.sqrt(row * col);
                    }
                }
                /*
                for (int i = 0; i < filterReal.length; i++) {
                    for (int j = 0; j < filterReal[i].length - 1; j++) {
                        System.out.printf(filterReal[i][j] + ",");
                    }
                    System.out.print(filterReal[i][filterReal[i].length - 1]);
                    System.out.println("");
                }
                 */
 /*
                RECORD THE FILTER THAT WAS PRODUCED
                 */
                filterVector.add(new Matrix(filterReal.length, filterReal.length));

                for (int i = 0; i < row; i++) {
                    for (int j = 0; j < col; j++) {
                        filterVector.lastElement().mat[i][j] = filterReal[i][j];
                    }
                }

                /*
                IMAGE CONVOLVE: Convolve fourier transformed image with filterFake.
                 */
                int cc3 = 0;
                double cv = 0;
                for (int i = 0; i < row; i++) {
                    cc3 = 0;
                    for (int j = 0; j < col * 2; j++) {
                        if (j == 0 || j % 2 == 0) {
                            EOfft[i][j] = imagefft[i][j] * filterConvolve[i][cc3];
                            EOfake[i][j] = EOfft[i][j];
                            cv = filterConvolve[i][cc3];
                            cc3++;
                        } else {
                            EOfft[i][j] = imagefft[i][j] * cv;
                        }
                    }
                }
                /*
                for (int i = 0; i < EOfake.length; i++) {
                    for (int j = 0; j < EOfake[i].length - 1; j++) {
                        System.out.printf(EOfake[i][j] + ",");
                    }
                    System.out.print(EOfake[i][EOfake[i].length - 1]);
                    System.out.println("");
                }
                 */
                fourier.complexInverse(EOfft, true);

                for (int i = 0; i < row; i++) {
                    for (int j = 0; j < EOfft[i].length; j++) {
                        EO[i][j] = EOfft[i][j];
                    }
                }
                /*
                for (int i = 0; i < EO.length; i++) {
                    for (int j = 0; j < EO[i].length - 1; j++) {
                        System.out.printf(EO[i][j] + ",");
                    }
                    System.out.print(EO[i][EO[i].length - 1]);
                    System.out.println("");
                }
                 */
                EOVector.add(new Matrix(EO.length, EO[0].length));

                for (int i = 0; i < row; i++) {
                    for (int j = 0; j < EO[i].length; j++) {
                        EOVector.lastElement().mat[i][j] = EO[i][j];
                    }
                }

                cc = 0;
                double tmp = 0;
                for (int i = 0; i < row; i++) {
                    cc = 0;
                    for (int j = 0; j < col * 2; j++) {

                        if (j == 0 || j % 2 == 0) {
                            tmp = EO[i][j] * EO[i][j];
                        } else {
                            tmp = tmp + EO[i][j] * EO[i][j];
                            tmp = Math.sqrt(tmp);
                            An[i][cc] = tmp;
                            cc++;
                        }
                    }
                }
                /*
                for (int i = 0; i < An.length; i++) {
                    for (int j = 0; j < An[i].length - 1; j++) {
                        System.out.printf(An[i][j] + ",");
                    }
                    System.out.print(An[i][An[i].length - 1]);
                    System.out.println("");
                }
                 */
                for (int i = 0; i < row; i++) {
                    for (int j = 0; j < col; j++) {
                        currSumAn[i][j] = currSumAn[i][j] + An[i][j];
                    }
                }
                /*
                for (int i = 0; i < An.length; i++) {
                    for (int j = 0; j < An[i].length - 1; j++) {
                        System.out.printf(An[i][j] + ",");
                    }
                    System.out.print(An[i][An[i].length - 1]);
                    System.out.println("");
                }
                 */
                cc = 0;
                int cc2 = 0;
                for (int i = 0; i < row; i++) {
                    cc = 0;
                    cc2 = 0;
                    for (int j = 0; j < 2 * col; j++) {
                        if (j == 0 || j % 2 == 0) {
                            currSumE[i][cc] = currSumE[i][cc] + EO[i][j];
                            cc++;
                        } else {
                            currSumO[i][cc2] = currSumO[i][cc2] + EO[i][j];
                            cc2++;
                        }
                    }
                }
                /*
                for (int i = 0; i < currSumE.length; i++) {
                    for (int j = 0; j < currSumE[i].length - 1; j++) {
                        System.out.printf(currSumE[i][j] + ",");
                    }
                    System.out.print(currSumE[i][currSumE[i].length - 1]);
                    System.out.println("");
                }
                
                for (int i = 0; i < currSumO.length; i++) {
                    for (int j = 0; j < currSumO[i].length - 1; j++) {
                        System.out.printf(currSumO[i][j] + ",");
                    }
                    System.out.print(currSumO[i][currSumO[i].length - 1]);
                    System.out.println("");
                }
                 */
                if (s == 1) {
                    for (int i = 0; i < row; i++) {
                        for (int j = 0; j < col; j++) {
                            maxMatrix[i][j] = An[i][j];
                        }
                    }
                } else {
                    double tmpMax;
                    for (int i = 0; i < row; i++) {
                        for (int j = 0; j < col; j++) {

                            tmpMax = Math.max(maxMatrix[i][j], An[i][j]);
                            maxMatrix[i][j] = tmpMax;
                        }
                    }
                }
                if (s == 1) {
                    for (int i = 0; i < row; i++) {
                        for (int j = 0; j < col; j++) {
                            EM_n_Matrix[i][j] = Math.pow(filterConvolve[i][j], 2);
                        }
                    }
                    for (int i = 0; i < row; i++) {
                        for (int j = 0; j < col; j++) {
                            em_n = em_n + EM_n_Matrix[i][j];
                        }
                    }
                }
                /*
                for (int i = 0; i < dc.length; i++) {
                    for (int j = 0; j < dc[i].length - 1; j++) {
                        System.out.print(EO[i][j] + ",");
                    }
                    System.out.print(EO[i][EO[i].length - 1]);
                    System.out.println("");
                }
                 */
                waveLen = waveLen * multFactor;
            }
            /*
            SCALES CALCULATION FINISHED 
            
            CONTINUE WITH ORIENT LOOP
             */
            for (int i = 0; i < row; i++) {
                for (int j = 0; j < col; j++) {
                    X_Energy[i][j] = Math.sqrt(Math.pow(currSumE[i][j], 2) + Math.pow(currSumO[i][j], 2)) + epsilon;
                }
            }
            /*for (int i = 0; i < X_Energy.length; i++) {
                for (int j = 0; j < X_Energy[i].length - 1; j++) {
                    System.out.print(X_Energy[i][j] + ",");
                }
                System.out.print(X_Energy[i][X_Energy[i].length - 1]);
                System.out.println("");
            }*/
            for (int i = 0; i < row; i++) {
                for (int j = 0; j < col; j++) {
                    MeanE[i][j] = currSumE[i][j] / X_Energy[i][j];
                }
            }

            for (int i = 0; i < row; i++) {
                for (int j = 0; j < col; j++) {
                    MeanO[i][j] = currSumO[i][j] / X_Energy[i][j];
                }
            }
            /*
            for (int i = 0; i < MeanO.length; i++) {
                for (int j = 0; j < MeanO[i].length - 1; j++) {
                    System.out.print(MeanO[i][j] + ",");
                }
                System.out.print(MeanO[i][MeanO[i].length - 1]);
                System.out.println("");
            }
             */

            //replace 1 with nscale
            Matrix realMeanE = new Matrix(row, col);
            Matrix imagMeanO = new Matrix(row, col);
            Matrix realMeanO = new Matrix(row, col);
            Matrix imagMeanE = new Matrix(row, col);
            int cc = 0;
            int cc2 = 0;

            for (int a = 0; a < EOVector.size(); a++) {
                for (int i = 0; i < row; i++) {
                    cc = 0;
                    cc2 = 0;
                    for (int j = 0; j < col * 2; j++) {
                        if (j == 0 || j % 2 == 0) {
                            realMeanE.mat[i][cc] = realMeanE.mat[i][cc] + EOVector.get(a).mat[i][j] * MeanE[i][cc];
                            realMeanO.mat[i][cc] = realMeanO.mat[i][cc] + EOVector.get(a).mat[i][j] * MeanO[i][cc];
                            cc++;
                        } else {
                            imagMeanO.mat[i][cc2] = imagMeanO.mat[i][cc2] + EOVector.get(a).mat[i][j] * MeanO[i][cc2];
                            imagMeanE.mat[i][cc2] = imagMeanE.mat[i][cc2] + EOVector.get(a).mat[i][j] * MeanE[i][cc2];
                            cc2++;
                        }
                    }
                }
            }

            for (int i = 0; i < row; i++) {
                for (int j = 0; j < col; j++) {
                    Energy_ThisOrient[i][j] = Energy_ThisOrient[i][j]
                            + realMeanE.mat[i][j] + imagMeanO.mat[i][j]
                            - Math.abs(realMeanO.mat[i][j] - imagMeanE.mat[i][j]);
                }
            }
            realMeanE = null;
            imagMeanO = null;
            realMeanO = null;
            imagMeanE = null;

            /*
            for (int i = 0; i < Energy_ThisOrient.length; i++) {
                for (int j = 0; j < Energy_ThisOrient[i].length - 1; j++) {
                    System.out.print(Energy_ThisOrient[i][j] + ",");
                }
                System.out.print(Energy_ThisOrient[i][Energy_ThisOrient[i].length - 1]);
                System.out.println("");
            }
             */
            for (int i = 0; i < row; i++) {
                for (int j = 0; j < 2 * col; j++) {
                    tmpEO[i][j] = EOVector.get(0).mat[i][j];
                }
            }

            cc = 0;
            double tmp = 0;
            for (int i = 0; i < row; i++) {
                cc = 0;
                for (int j = 0; j < tmpEO[i].length; j++) {
                    if (j == 0 || j % 2 == 0) {

                        tmp = tmpEO[i][j] * tmpEO[i][j];
                    } else {
                        tmp = tmp + tmpEO[i][j] * tmpEO[i][j];
                        tmp = Math.sqrt(tmp);
                        tmpEO_Final[i][cc] = tmp;
                        cc++;
                    }
                }
            }

            for (int i = 0; i < row; i++) {
                for (int j = 0; j < tmpEO_Final[i].length; j++) {
                    tmpEO_Final[i][j] = tmpEO_Final[i][j] * tmpEO_Final[i][j];
                }
            }
            /*
            for (int i = 0; i < tmpEO_Final.length; i++) {
                for (int j = 0; j < tmpEO_Final[i].length - 1; j++) {
                    System.out.print(tmpEO_Final[i][j] + ",");
                }
                System.out.print(tmpEO_Final[i][tmpEO_Final[i].length - 1]);
                System.out.println("");
            }
             */
            cc = 0;
            for (int j = 0; j < tmpEO_Final[0].length; j++) {
                for (int i = 0; i < row; i++) {
                    medianArray[cc] = tmpEO_Final[i][j];
                    cc++;
                }
            }
            /*
            for (int i = 0; i < medianArray.length; i++) {
                System.out.print(medianArray[i] + ",");
            }*/
            Arrays.sort(medianArray);

            if (medianArray.length % 2 == 0) {
                medianE2n = ((double) medianArray[medianArray.length / 2] + (double) medianArray[medianArray.length / 2 - 1]) / 2;
            } else {
                medianE2n = (double) medianArray[medianArray.length / 2];
            }

            meanE2n = -medianE2n / Math.log(0.5);
            estMeanE2nVector.add(meanE2n);
            noisePower = meanE2n / em_n;

            for (int i = 0; i < row; i++) {
                for (int j = 0; j < col; j++) {
                    EstSumAn2[i][j] = 0;
                }
            }
            for (int a = 0; a < filterVector.size(); a++) {
                for (int i = 0; i < row; i++) {
                    for (int j = 0; j < col; j++) {
                        EstSumAn2[i][j] = filterVector.get(a).mat[i][j] * filterVector.get(a).mat[i][j];
                    }
                }
            }

            for (int i = 0; i < row; i++) {
                for (int j = 0; j < col; j++) {
                    EstSumAiAj[i][j] = 0;
                }
            }
            for (int a = 0; a < filterVector.size() - 1; a++) {
                for (int b = a + 1; b < filterVector.size(); b++) {
                    for (int i = 0; i < row; i++) {
                        for (int j = 0; j < col; j++) {
                            EstSumAn2[i][j] = EstSumAn2[i][j]
                                    + (filterVector.get(a).mat[i][j]
                                    * filterVector.get(b).mat[i][j]);
                        }
                    }
                }

            }

            t1 = 0.0;
            t2 = 0.0;

            for (int i = 0; i < row; i++) {
                for (int j = 0; j < col; j++) {
                    t1 = t1 + EstSumAn2[i][j];
                    t2 = t2 + EstSumAiAj[i][j];
                }
            }
            EstNoiseEnergy2 = 2 * noisePower * t1 + 4 * noisePower * t2;

            tau = Math.sqrt(EstNoiseEnergy2 / 2.0);

            EstNoiseEnergy = tau * Math.sqrt(Math.PI / 2);
            EstNoiseEnergySigma = Math.sqrt((2 - (Math.PI / 2)) * (Math.pow(tau, 2)));

            T = EstNoiseEnergy + k * EstNoiseEnergySigma;
            T = T / 1.7;

            for (int i = 0; i < row; i++) {
                for (int j = 0; j < col; j++) {
                    Energy_ThisOrient[i][j] = Double.max(Energy_ThisOrient[i][j] - T, 0);
                }
            }

            for (int i = 0; i < row; i++) {
                for (int j = 0; j < col; j++) {
                    width[i][j] = ((currSumAn[i][j]) / (maxMatrix[i][j] + epsilon)) / nscale;
                }
            }
            for (int i = 0; i < row; i++) {
                for (int j = 0; j < col; j++) {
                    weight[i][j] = ones[i][j] / (1 + Math.exp(g * (cutoff - width[i][j])));
                }
            }
            for (int i = 0; i < row; i++) {
                for (int j = 0; j < col; j++) {
                    Energy_ThisOrient[i][j] = Energy_ThisOrient[i][j] * weight[i][j];
                }
            }
            for (int i = 0; i < row; i++) {
                for (int j = 0; j < col; j++) {
                    totalSumAmplitudeMatrix[i][j] = totalSumAmplitudeMatrix[i][j]
                            + currSumAn[i][j];
                    energyTotalMatrix[i][j] = energyTotalMatrix[i][j] + Energy_ThisOrient[i][j];
                }
            }

            if (o == 1) {
                for (int i = 0; i < row; i++) {
                    for (int j = 0; j < col; j++) {
                        maxEnergy[i][j] = Energy_ThisOrient[i][j];
                    }
                }
            } else {

                for (int i = 0; i < row; i++) {
                    for (int j = 0; j < col; j++) {
                        if (Energy_ThisOrient[i][j] > maxEnergy[i][j]) {
                            changeA[i][j] = 1.0;
                            changeB[i][j] = 0.0;
                        } else {
                            changeA[i][j] = 0.0;
                            changeB[i][j] = 1.0;
                        }
                    }
                }
                for (int i = 0; i < row; i++) {
                    for (int j = 0; j < col; j++) {
                        orientationEnergyMatrix[i][j] = (o - 1) * changeA[i][j]
                                + (orientationEnergyMatrix[i][j] * (changeB[i][j]));
                    }
                }
                for (int i = 0; i < row; i++) {
                    for (int j = 0; j < col; j++) {
                        maxEnergy[i][j] = Double.max(maxEnergy[i][j],
                                Energy_ThisOrient[i][j]);
                    }
                }
            }
            /*
            for (int i = 0; i < EstSumAiAj.length; i++) {
                for (int j = 0; j < EstSumAiAj[i].length - 1; j++) {
                    System.out.print(EstSumAiAj[i][j] + ",");
                }
                System.out.print(EstSumAiAj[i][EstSumAiAj[i].length - 1]);
                System.out.println("");
            }
             */
            System.out.println("");

        }

        for (int i = 0; i < row; i++) {
            for (int j = 0; j < col; j++) {
                phaseCongruency[i][j] = (int) (energyTotalMatrix[i][j]
                        / (totalSumAmplitudeMatrix[i][j] + epsilon));
                orientationEnergyMatrix[i][j] = orientationEnergyMatrix[i][j] * (180 / norient);
            }
        }
        saveTransformedImageToFile();
        displayTransformedImage();
    }

    public void saveTransformedImageToFile() throws IOException {
        transformedImage = new BufferedImage(imageOriginal.getWidth(), imageOriginal.getHeight(), BufferedImage.TYPE_BYTE_BINARY);

        for (int i = 0; i < imageOriginal.getHeight(); i++) {
            for (int j = 0; j < imageOriginal.getWidth(); j++) {
                //int value = transformedMatrix[i][j] << 16 | transformedMatrix[i][j] << 8 | transformedMatrix[i][j];
                transformedImage.setRGB(i, j, (byte) phaseCongruency[i][j]);
            }
        }
        File myfile = new File("phaseCongruency_" + fn + ".png");
        ImageIO.write(transformedImage, "png", myfile);
    }

    public void displayTransformedImage() {
        JFrame editorFrame = new JFrame("Phase Congruency- Final Image");
        editorFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        ImageIcon imageIcon = new ImageIcon(this.transformedImage);
        JLabel jLabel = new JLabel();
        jLabel.setIcon(imageIcon);
        editorFrame.getContentPane().add(jLabel, BorderLayout.EAST);

        editorFrame.pack();
        editorFrame.setLocationRelativeTo(null);
        editorFrame.setVisible(true);
    }
}
