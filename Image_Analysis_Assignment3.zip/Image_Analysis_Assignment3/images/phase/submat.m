function a = submat(big,i,cols)

a = big(:,((i-1)*cols+1):(i*cols));

