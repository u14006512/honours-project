package Assignment3;

import java.awt.BorderLayout;
import java.awt.image.BufferedImage;
import java.awt.image.Raster;
import java.awt.image.WritableRaster;
import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.Vector;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.WindowConstants;
import org.jtransforms.fft.DoubleFFT_2D;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Warmaster
 */
public class PhaseCongruencyEdgeDetector {

    String fn;
    int row, col;

    DoubleFFT_2D fourier;

    int nscale = 4;
    int norient = 6;
    int minWaveLength = 3;
    int multFactor = 2;
    double sigmaONF = 0.55;
    double dThetaOnSigma = 1.2;
    double k = 2.0;
    int pixelMask[][];
    double cutoff = 0.44;
    int g = 10;
    double epsilon = 0.0001;
    double thetaSigma = (Math.PI / norient) / dThetaOnSigma;

    BufferedImage imageOriginal;
    BufferedImage transformedImage;

    int[][] pixelMap;
    double[][] imagefft;
    double[][] phaseCongruency;

    double[][] energyTotalMatrix;
    double[][] totalSumAmplitudeMatrix;
    double[][] orientationEnergyMatrix;
    double[][] ones;

    public PhaseCongruencyEdgeDetector(String f) throws IOException {
        this.fn = f;
        imageOriginal = ImageIO.read(new File(fn));

        row = imageOriginal.getHeight();
        col = imageOriginal.getWidth();

        pixelMap = producePixelMatrix(imageOriginal);
        energyTotalMatrix = new double[row][col];
        orientationEnergyMatrix = new double[row][col];
        totalSumAmplitudeMatrix = new double[row][col];
        pixelMask = new int[row][col];
        imagefft = new double[row][2 * col];
        ones = new double[row][col];
        phaseCongruency = new double[row][col];

        for (int i = 0; i < ones.length; i++) {
            for (int j = 0; j < col; j++) {
                ones[i][j] = 1.0;
            }
        }

        setFFT2();
        displayOriginalImage();

        this.fn = fn.substring(0, fn.indexOf("."));

        System.out.println("Finished Init");
    }

    public void displayOriginalImage() {
        JFrame editorFrame = new JFrame("Phase Congruency Detection- Original Image");
        editorFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        ImageIcon imageIcon = new ImageIcon(this.imageOriginal);
        JLabel jLabel = new JLabel();
        jLabel.setIcon(imageIcon);
        editorFrame.getContentPane().add(jLabel, BorderLayout.CENTER);

        editorFrame.pack();
        editorFrame.setLocationRelativeTo(null);
        editorFrame.setVisible(true);
    }

    private int[][] producePixelMatrix(BufferedImage image) {
        int h = image.getHeight();
        int w = image.getWidth();
        int[][] result = new int[h][w];
        Raster r = image.getData();

        for (int i = 0; i < h; i++) {
            for (int j = 0; j < w; j++) {
                result[i][j] = r.getSample(i, j, 0);
            }
        }

        return result;
    }

    private void setFFT2() {
        fourier = new DoubleFFT_2D(row, col);

        double[][] map = new double[row][2 * col];
        for (int i = 0; i < row; i++) {
            for (int j = 0; j < col; j++) {
                map[i][j] = pixelMap[j][i];
            }
        }

        fourier.realForwardFull(map);

        for (int i = 0; i < row; i++) {
            for (int j = 0; j < map[i].length; j++) {
                if (j == 0 || j % 2 == 0) {
                    //pixelMap[i][cc] = (int) map[i][j];
                    imagefft[i][j] = map[i][j];
                } else {
                    imagefft[i][j] = map[i][j];
                }

            }
        }
    }

    public void doPhaseCongruencyProcess() throws IOException {
        //Computing the X component of the Filter

        int[][] x = new int[row][col];

        for (int i = 0; i < row; i++) {
            x[i][col / 2] = 0;
        }
        //Left Split side->go down
        int val = -1;
        for (int j = (col / 2) - 1; j >= 0; j--) {
            for (int i = 0; i < row; i++) {
                x[i][j] = val;
            }
            val--;
        }
        //right split ->go up
        val = 1;
        for (int j = (col / 2) + 1; j < col; j++) {
            for (int i = 0; i < row; i++) {
                x[i][j] = val;
            }
            val++;
        }

        //Computing the Y Component of the Filter
        int[][] y = new int[row][col];

        for (int i = 0; i < row; i++) {
            y[col / 2][i] = 0;
        }
        //Left Split side->go down
        val = -1;
        for (int j = (col / 2) - 1; j >= 0; j--) {
            for (int i = 0; i < row; i++) {
                y[j][i] = val;
            }
            val--;
        }
        //right split ->go up
        val = 1;
        for (int j = (col / 2) + 1; j < col; j++) {
            for (int i = 0; i < row; i++) {
                y[j][i] = val;
            }
            val++;
        }
        //Radius
        double[][] radius = new double[row][col];

        for (int i = 0; i < row; i++) {
            for (int j = 0; j < col; j++) {
                radius[i][j] = Math.sqrt(Math.pow(x[i][j], 2) + Math.pow(y[i][j], 2));
            }
        }

        radius[row / 2][col / 2] = 1;
        double[][] theta = new double[row][col];

        for (int i = 0; i < row; i++) {
            for (int j = 0; j < col; j++) {
                theta[i][j] = Math.atan2(-y[i][j], x[i][j]);
            }
        }
        for (int i = 0; i < col / 2; i++) {
            theta[row / 2][i] = theta[row / 2][i] * -1;
        }
        x = null;
        y = null;

        //Main Loop
        double angle;
        int waveLen;
        double currSumE[][] = new double[row][col];
        double currSumO[][] = new double[row][col];
        double currSumAn[][] = new double[row][col];
        double currEnergy[][] = new double[row][col];
        double ds[][] = new double[row][col];
        double dc[][] = new double[row][col];
        double dTheta[][] = new double[row][col];
        double[][] spread = new double[row][col];
        double[][] X_Energy = new double[row][col];
        double[][] MeanE = new double[row][col];
        double[][] MeanO = new double[row][col];
        double[][] Energy_ThisOrient = new double[row][col];
        double[] medianArray = new double[row * col];
        double[][] tmpEO = new double[row][2 * col];
        double[][] tmpEO_Final = new double[row][col];
        double medianE2n = 0.0;
        double meanE2n = 0.0;
        double noisePower = 0.0;
        double[][] EstSumAn2 = new double[row][col];
        double[][] EstSumAiAj = new double[row][col];
        double EstNoiseEnergy = 0.0;
        double EstNoiseEnergy2 = 0.0;
        double EstNoiseEnergySigma = 0.0;
        double t1 = 0.0, t2 = 0.0;
        double tau = 0.0;
        //nscale loop
        double fo;
        double rfo;
        double logGabor[][] = new double[row][col];
        double[][] filterFake = new double[row][2 * col];
        double[][] filterReal = new double[row][col];
        double[][] filterConvolve = new double[row][col];
        double[][] EOfft = new double[row][col * 2];
        double[][] EOfake = new double[row][col * 2];
        double[][] EO = new double[row][col * 2];
        double[][] An = new double[row][col];
        double[][] maxMatrix = new double[row][col];
        double[][] EM_n_Matrix = new double[row][col];
        double em_n = 0.0;
        double T = 0.0;
        double[][] width = new double[row][col];
        double[][] weight = new double[row][col];
        double[][] maxEnergy = new double[row][col];
        double[][] changeA = new double[row][col];
        double[][] changeB = new double[row][col];

        Vector<Double> estMeanE2nVector = new Vector<>();
        Vector<Matrix> filterVector = new Vector<>();
        Vector<Matrix> EOVector = new Vector<>();

        ///Quandrants inside nscale loop
        double[][] q1 = new double[row / 2][col / 2];
        double[][] q2 = new double[row / 2][col / 2];
        double[][] q3 = new double[row / 2][col / 2];
        double[][] q4 = new double[row / 2][col / 2];
        int qR, qC, s;

        ///set to norient
        for (int o = 1; o <= norient; o++) {
            System.out.println("Processing Orientation: " + o);

            angle = (o - 1) * (Math.PI / norient);

            waveLen = minWaveLength;

            //Clear and Re-init the accumulator matrices
            for (int i = 0; i < row; i++) {
                for (int j = 0; j < col; j++) {
                    currEnergy[i][j] = 0;
                    currSumAn[i][j] = 0;
                    currSumE[i][j] = 0;
                    currSumO[i][j] = 0;
                    ds[i][j] = 0;
                    dc[i][j] = 0;
                    dTheta[i][j] = 0;
                    spread[i][j] = 0;
                    logGabor[i][j] = 0;
                }
            }
            filterVector.clear();
            EOVector.clear();

            for (int i = 0; i < row; i++) {
                for (int j = 0; j < col; j++) {
                    ds[i][j] = (Math.sin(theta[i][j]) * Math.cos(angle))
                            - (Math.sin(angle) * Math.cos(theta[i][j]));
                }
            }

            for (int i = 0; i < row; i++) {
                for (int j = 0; j < col; j++) {
                    dc[i][j] = (Math.cos(theta[i][j]) * Math.cos(angle))
                            + (Math.sin(angle) * Math.sin(theta[i][j]));
                }
            }

            for (int i = 0; i < row; i++) {
                for (int j = 0; j < col; j++) {
                    dTheta[i][j] = Math.abs(Math.atan2(ds[i][j], dc[i][j]));
                }
            }
            for (int i = 0; i < row; i++) {
                for (int j = 0; j < col; j++) {
                    spread[i][j] = Math.exp(-Math.pow(dTheta[i][j], 2) / (2 * Math.pow(thetaSigma, 2)));
                }
            }
            System.out.println("Pre-processing Done for o:" + o);
            System.out.println("Spread Calculated");
            System.out.println("dTheta Calculated");
            ///replace 1 with nscale
            for (s = 1; s <= nscale; s++) {
                System.out.println("Current Scale: " + s);
                //Filter Construction
                fo = 1.0 / waveLen;
                rfo = (fo / 0.5) * (col / 2);

                for (int i = 0; i < row; i++) {
                    for (int j = 0; j < col; j++) {
                        logGabor[i][j] = Math.exp((-(Math.pow(Math.log(radius[i][j] / rfo), 2)))
                                / (2 * (Math.pow(Math.log(sigmaONF), 2))));
                    }
                }
                logGabor[row / 2][col / 2] = 0;
                System.out.println("Log Gabor Calculated: " + s);
                for (int i = 0; i < row; i++) {
                    for (int j = 0; j < col; j++) {
                        filterFake[i][j] = logGabor[i][j] * spread[i][j];
                        filterConvolve[i][j] = logGabor[i][j] * spread[i][j];
                    }
                }
                System.out.println("Filter Calculated: " + s);
                //Quadrant Swapping
                //First record all quadrants
                //Q1:Top Left
                qR = 0;
                qC = 0;

                for (int i = 0; i <= (row / 2) - 1; i++) {
                    qC = 0;
                    for (int j = 0; j <= (col / 2) - 1; j++) {
                        q1[qR][qC] = filterFake[i][j];
                        qC++;
                    }
                    qR++;
                }
                //Q2:Top Right
                qR = 0;
                qC = 0;
                for (int i = 0; i <= (row / 2) - 1; i++) {
                    qC = 0;
                    for (int j = col / 2; j < col; j++) {
                        q2[qR][qC] = filterFake[i][j];
                        qC++;
                    }
                    qR++;
                }
                //Q3:Bottom Left
                qR = 0;
                qC = 0;
                for (int i = row / 2; i < row; i++) {
                    qC = 0;
                    for (int j = col / 2; j < col; j++) {
                        q3[qR][qC] = filterFake[i][j];
                        qC++;
                    }
                    qR++;
                }

                //Q4:Bottom Right
                qR = 0;
                qC = 0;
                for (int i = row / 2; i < row; i++) {
                    qC = 0;
                    for (int j = 0; j <= (col / 2) - 1; j++) {
                        q4[qR][qC] = filterFake[i][j];
                        qC++;
                    }
                    qR++;
                }
                //Then swap 1 with 3, and 2 with 4
                qR = 0;
                qC = 0;
                for (int i = 0; i <= (row / 2) - 1; i++) {
                    qC = 0;
                    for (int j = 0; j <= (col / 2) - 1; j++) {
                        filterFake[i][j] = q3[qR][qC];
                        filterConvolve[i][j] = q3[qR][qC];
                        qC++;
                    }
                    qR++;
                }
                qR = 0;
                qC = 0;
                for (int i = (row / 2); i < row; i++) {
                    qC = 0;
                    for (int j = col / 2; j < col; j++) {
                        filterFake[i][j] = q1[qR][qC];
                        filterConvolve[i][j] = q1[qR][qC];
                        qC++;
                    }
                    qR++;
                }
                qR = 0;
                qC = 0;
                for (int i = 0; i <= (row / 2) - 1; i++) {
                    qC = 0;
                    for (int j = col / 2; j < col; j++) {
                        filterFake[i][j] = q4[qR][qC];
                        filterConvolve[i][j] = q4[qR][qC];
                        qC++;
                    }
                    qR++;
                }
                qR = 0;
                qC = 0;
                for (int i = (row / 2); i < row; i++) {
                    qC = 0;
                    for (int j = 0; j <= (col / 2) - 1; j++) {
                        filterFake[i][j] = q2[qR][qC];
                        filterConvolve[i][j] = q2[qR][qC];
                        qC++;
                    }
                    qR++;
                }
                System.out.println("Filter Shifted");
                //Now compute the inverse of filterFake
                fourier.realInverseFull(filterFake, true);
                System.out.println("Filter Inverse Calculated: " + s);
                int cc = 0;
                for (int i = 0; i < row; i++) {
                    cc = 0;
                    for (int j = 0; j < filterFake[i].length; j++) {
                        if (j == 0 || j % 2 == 0) {
                            filterReal[i][cc] = filterFake[i][j];
                            cc++;
                        }
                    }
                }

                for (int i = 0; i < row; i++) {
                    for (int j = 0; j < col; j++) {
                        filterReal[i][j] = filterReal[i][j] * Math.sqrt(row * col);
                    }
                }

                /*
                RECORD THE FILTER THAT WAS PRODUCED
                 */
                filterVector.add(new Matrix(filterReal.length, filterReal.length));

                for (int i = 0; i < row; i++) {
                    for (int j = 0; j < col; j++) {
                        filterVector.lastElement().mat[i][j] = filterReal[i][j];
                    }
                }

                /*
                IMAGE CONVOLVE: Convolve fourier transformed image with filterFake.
                 */
                int cc3 = 0;
                double cv = 0;
                for (int i = 0; i < row; i++) {
                    cc3 = 0;
                    for (int j = 0; j < col * 2; j++) {
                        if (j == 0 || j % 2 == 0) {
                            EOfft[i][j] = imagefft[i][j] * filterConvolve[i][cc3];
                            EOfake[i][j] = EOfft[i][j];
                            cv = filterConvolve[i][cc3];
                            cc3++;
                        } else {
                            EOfft[i][j] = imagefft[i][j] * cv;
                        }
                    }
                }
                System.out.println("Filter Convolution Done: " + s);
                fourier.complexInverse(EOfft, true);
                System.out.println("EOfft Inverse Calculated: " + s);
                for (int i = 0; i < row; i++) {
                    for (int j = 0; j < EOfft[i].length; j++) {
                        EO[i][j] = EOfft[i][j];
                    }
                }
                EOVector.add(new Matrix(EO.length, EO[0].length));

                for (int i = 0; i < row; i++) {
                    for (int j = 0; j < EO[i].length; j++) {
                        EOVector.lastElement().mat[i][j] = EO[i][j];
                    }
                }

                cc = 0;
                double tmp = 0;
                for (int i = 0; i < row; i++) {
                    cc = 0;
                    for (int j = 0; j < col * 2; j++) {

                        if (j == 0 || j % 2 == 0) {
                            tmp = EO[i][j] * EO[i][j];
                        } else {
                            tmp = tmp + EO[i][j] * EO[i][j];
                            tmp = Math.sqrt(tmp);
                            An[i][cc] = tmp;
                            cc++;
                        }
                    }
                }
                for (int i = 0; i < row; i++) {
                    for (int j = 0; j < col; j++) {
                        currSumAn[i][j] = currSumAn[i][j] + An[i][j];
                    }
                }
                cc = 0;
                int cc2 = 0;
                for (int i = 0; i < row; i++) {
                    cc = 0;
                    cc2 = 0;
                    for (int j = 0; j < 2 * col; j++) {
                        if (j == 0 || j % 2 == 0) {
                            currSumE[i][cc] = currSumE[i][cc] + EO[i][j];
                            cc++;
                        } else {
                            currSumO[i][cc2] = currSumO[i][cc2] + EO[i][j];
                            cc2++;
                        }
                    }
                }
                if (s == 1) {
                    for (int i = 0; i < row; i++) {
                        for (int j = 0; j < col; j++) {
                            maxMatrix[i][j] = An[i][j];
                        }
                    }
                } else {
                    double tmpMax;
                    for (int i = 0; i < row; i++) {
                        for (int j = 0; j < col; j++) {

                            tmpMax = Math.max(maxMatrix[i][j], An[i][j]);
                            maxMatrix[i][j] = tmpMax;
                        }
                    }
                }
                if (s == 1) {
                    for (int i = 0; i < row; i++) {
                        for (int j = 0; j < col; j++) {
                            EM_n_Matrix[i][j] = Math.pow(filterConvolve[i][j], 2);
                        }
                    }
                    for (int i = 0; i < row; i++) {
                        for (int j = 0; j < col; j++) {
                            em_n = em_n + EM_n_Matrix[i][j];
                        }
                    }
                }
                waveLen = waveLen * multFactor;
            }
            /*
            SCALES CALCULATION FINISHED 
            
            CONTINUE WITH ORIENT LOOP
             */
            for (int i = 0; i < row; i++) {
                for (int j = 0; j < col; j++) {
                    X_Energy[i][j] = Math.sqrt(Math.pow(currSumE[i][j], 2) + Math.pow(currSumO[i][j], 2)) + epsilon;
                }
            }
            for (int i = 0; i < row; i++) {
                for (int j = 0; j < col; j++) {
                    MeanE[i][j] = currSumE[i][j] / X_Energy[i][j];
                }
            }

            for (int i = 0; i < row; i++) {
                for (int j = 0; j < col; j++) {
                    MeanO[i][j] = currSumO[i][j] / X_Energy[i][j];
                }
            }
            System.out.println("X-Energy Calculated");
            System.out.println("Mean O Calculated");
            System.out.println("Mean E Calculated");
            //replace 1 with nscale
            Matrix realMeanE = new Matrix(row, col);
            Matrix imagMeanO = new Matrix(row, col);
            Matrix realMeanO = new Matrix(row, col);
            Matrix imagMeanE = new Matrix(row, col);
            int cc = 0;
            int cc2 = 0;

            for (int a = 0; a < EOVector.size(); a++) {
                for (int i = 0; i < row; i++) {
                    cc = 0;
                    cc2 = 0;
                    for (int j = 0; j < col * 2; j++) {
                        if (j == 0 || j % 2 == 0) {
                            realMeanE.mat[i][cc] = realMeanE.mat[i][cc] + EOVector.get(a).mat[i][j] * MeanE[i][cc];
                            realMeanO.mat[i][cc] = realMeanO.mat[i][cc] + EOVector.get(a).mat[i][j] * MeanO[i][cc];
                            cc++;
                        } else {
                            imagMeanO.mat[i][cc2] = imagMeanO.mat[i][cc2] + EOVector.get(a).mat[i][j] * MeanO[i][cc2];
                            imagMeanE.mat[i][cc2] = imagMeanE.mat[i][cc2] + EOVector.get(a).mat[i][j] * MeanE[i][cc2];
                            cc2++;
                        }
                    }
                }
            }

            for (int i = 0; i < row; i++) {
                for (int j = 0; j < col; j++) {
                    Energy_ThisOrient[i][j] = Energy_ThisOrient[i][j]
                            + realMeanE.mat[i][j] + imagMeanO.mat[i][j]
                            - Math.abs(realMeanO.mat[i][j] - imagMeanE.mat[i][j]);
                }
            }
            realMeanE = null;
            imagMeanO = null;
            realMeanO = null;
            imagMeanE = null;

            for (int i = 0; i < row; i++) {
                for (int j = 0; j < 2 * col; j++) {
                    tmpEO[i][j] = EOVector.get(0).mat[i][j];
                }
            }

            cc = 0;
            double tmp = 0;
            for (int i = 0; i < row; i++) {
                cc = 0;
                for (int j = 0; j < tmpEO[i].length; j++) {
                    if (j == 0 || j % 2 == 0) {

                        tmp = tmpEO[i][j] * tmpEO[i][j];
                    } else {
                        tmp = tmp + tmpEO[i][j] * tmpEO[i][j];
                        tmp = Math.sqrt(tmp);
                        tmpEO_Final[i][cc] = tmp;
                        cc++;
                    }
                }
            }

            for (int i = 0; i < row; i++) {
                for (int j = 0; j < tmpEO_Final[i].length; j++) {
                    tmpEO_Final[i][j] = tmpEO_Final[i][j] * tmpEO_Final[i][j];
                }
            }

            cc = 0;
            for (int j = 0; j < tmpEO_Final[0].length; j++) {
                for (int i = 0; i < row; i++) {
                    medianArray[cc] = tmpEO_Final[i][j];
                    cc++;
                }
            }
            Arrays.sort(medianArray);

            if (medianArray.length % 2 == 0) {
                medianE2n = ((double) medianArray[medianArray.length / 2] + (double) medianArray[medianArray.length / 2 - 1]) / 2;
            } else {
                medianE2n = (double) medianArray[medianArray.length / 2];
            }

            meanE2n = -medianE2n / Math.log(0.5);
            estMeanE2nVector.add(meanE2n);
            noisePower = meanE2n / em_n;
            System.out.println("Median Calculated");
            for (int i = 0; i < row; i++) {
                for (int j = 0; j < col; j++) {
                    EstSumAn2[i][j] = 0;
                }
            }
            for (int a = 0; a < filterVector.size(); a++) {
                for (int i = 0; i < row; i++) {
                    for (int j = 0; j < col; j++) {
                        EstSumAn2[i][j] = filterVector.get(a).mat[i][j] * filterVector.get(a).mat[i][j];
                    }
                }
            }

            for (int i = 0; i < row; i++) {
                for (int j = 0; j < col; j++) {
                    EstSumAiAj[i][j] = 0;
                }
            }
            for (int a = 0; a < filterVector.size() - 1; a++) {
                for (int b = a + 1; b < filterVector.size(); b++) {
                    for (int i = 0; i < row; i++) {
                        for (int j = 0; j < col; j++) {
                            EstSumAn2[i][j] = EstSumAn2[i][j]
                                    + (filterVector.get(a).mat[i][j]
                                    * filterVector.get(b).mat[i][j]);
                        }
                    }
                }

            }

            t1 = 0.0;
            t2 = 0.0;

            for (int i = 0; i < row; i++) {
                for (int j = 0; j < col; j++) {
                    t1 = t1 + EstSumAn2[i][j];
                    t2 = t2 + EstSumAiAj[i][j];
                }
            }
            EstNoiseEnergy2 = 2 * noisePower * t1 + 4 * noisePower * t2;

            tau = Math.sqrt(EstNoiseEnergy2 / 2.0);

            EstNoiseEnergy = tau * Math.sqrt(Math.PI / 2);
            EstNoiseEnergySigma = Math.sqrt((2 - (Math.PI / 2)) * (Math.pow(tau, 2)));

            T = EstNoiseEnergy + k * EstNoiseEnergySigma;
            T = T / 1.7;

            for (int i = 0; i < row; i++) {
                for (int j = 0; j < col; j++) {
                    Energy_ThisOrient[i][j] = Double.max(Energy_ThisOrient[i][j] - T, 0);
                }
            }

            for (int i = 0; i < row; i++) {
                for (int j = 0; j < col; j++) {
                    width[i][j] = ((currSumAn[i][j]) / (maxMatrix[i][j] + epsilon)) / nscale;
                }
            }
            for (int i = 0; i < row; i++) {
                for (int j = 0; j < col; j++) {
                    weight[i][j] = ones[i][j] / (1 + Math.exp(g * (cutoff - width[i][j])));
                }
            }
            for (int i = 0; i < row; i++) {
                for (int j = 0; j < col; j++) {
                    Energy_ThisOrient[i][j] = Energy_ThisOrient[i][j] * weight[i][j];
                }
            }
            for (int i = 0; i < row; i++) {
                for (int j = 0; j < col; j++) {
                    totalSumAmplitudeMatrix[i][j] = totalSumAmplitudeMatrix[i][j]
                            + currSumAn[i][j];
                    energyTotalMatrix[i][j] = energyTotalMatrix[i][j] + Energy_ThisOrient[i][j];
                }
            }

            if (o == 1) {
                for (int i = 0; i < row; i++) {
                    for (int j = 0; j < col; j++) {
                        maxEnergy[i][j] = Energy_ThisOrient[i][j];
                    }
                }
            } else {

                for (int i = 0; i < row; i++) {
                    for (int j = 0; j < col; j++) {
                        if (Energy_ThisOrient[i][j] > maxEnergy[i][j]) {
                            changeA[i][j] = 1.0;
                            changeB[i][j] = 0.0;
                        } else {
                            changeA[i][j] = 0.0;
                            changeB[i][j] = 1.0;
                        }
                    }
                }
                for (int i = 0; i < row; i++) {
                    for (int j = 0; j < col; j++) {
                        orientationEnergyMatrix[i][j] = (o - 1) * changeA[i][j]
                                + (orientationEnergyMatrix[i][j] * (changeB[i][j]));
                    }
                }
                for (int i = 0; i < row; i++) {
                    for (int j = 0; j < col; j++) {
                        maxEnergy[i][j] = Double.max(maxEnergy[i][j],
                                Energy_ThisOrient[i][j]);
                    }
                }
            }
            System.out.println("Orientation: " + o + " calculated");
        }
        
        System.out.println("Image Processing Finished- Calculating Phase Congruency");
        for (int i = 0; i < row; i++) {
            for (int j = 0; j < col; j++) {
                phaseCongruency[i][j]
                        =  (energyTotalMatrix[i][j]/(totalSumAmplitudeMatrix[i][j] + epsilon));
                orientationEnergyMatrix[i][j] = orientationEnergyMatrix[i][j] * (180 / norient);
            }
        }
        double m=findMax();
        for (int i = 0; i < row; i++) {
            for (int j = 0; j < col; j++) {
                phaseCongruency[i][j]=phaseCongruency[i][j]/m;
         
            }
        }
        
        System.out.println("Normalising Phase Congruency");
        phaseTransform();
        hystersisOperation();
        imagePrepare();
        saveEdgesBinary();

        //saveTransformedImageToFile();
        System.out.println("Saving Image");
        displayTransformedImage();

    }
    private double findMax()
    {
        double max=-1;
        for(int i=0;i<row;i++)
        {
            for(int j=0;j<col;j++)
            {
                if (phaseCongruency[i][j]>max)
                {
                    max=phaseCongruency[i][j];
                }
            }
        }
        return max;
    }
    
    private void imagePrepare() {
        for (int i = 0; i < row; i++) {
            for (int j = 0; j < col; j++) {
                if (pixelMask[i][j]==1) {
                    phaseCongruency[i][j] = 255;
                } else {
                 phaseCongruency[i][j]=0;
                }

            }
        }
    }

    private void phaseTransform() {
        for (int i = 0; i < row; i++) {
            for (int j = 0; j < col; j++) {
                if (phaseCongruency[i][j] < 0.42) {
                    pixelMask[i][j] = 0;
                } else {
                    if (phaseCongruency[i][j] > 0.45) {
                        pixelMask[i][j] = 1;
                    } else {
                        pixelMask[i][j] = -1;
                    }
                }

            }
        }
    }

    private void saveTransformedImageToFile() throws IOException {
        transformedImage = new BufferedImage(imageOriginal.getWidth(), imageOriginal.getHeight(), BufferedImage.TYPE_BYTE_BINARY);

        for (int i = 0; i < imageOriginal.getHeight(); i++) {
            for (int j = 0; j < imageOriginal.getWidth(); j++) {
                //int value = transformedMatrix[i][j] << 16 | transformedMatrix[i][j] << 8 | transformedMatrix[i][j];
                transformedImage.setRGB(i, j, (byte) phaseCongruency[j][i]);
            }
        }
        File myfile = new File("phaseCongruency_" + fn + ".png");
        ImageIO.write(transformedImage, "png", myfile);
    }

    private void displayTransformedImage() {
        JFrame editorFrame = new JFrame("Phase Congruency- Final Image");
        editorFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        ImageIcon imageIcon = new ImageIcon(this.transformedImage);
        JLabel jLabel = new JLabel();
        jLabel.setIcon(imageIcon);
        editorFrame.getContentPane().add(jLabel, BorderLayout.EAST);

        editorFrame.pack();
        editorFrame.setLocationRelativeTo(null);
        editorFrame.setVisible(true);
    }

    private void saveEdgesBinary() throws IOException {
        transformedImage = new BufferedImage(phaseCongruency.length, phaseCongruency.length, BufferedImage.TYPE_BYTE_BINARY);
        int d;
        WritableRaster raster = transformedImage.getRaster();

        for (int i = 0; i < transformedImage.getHeight(); i++) {
            for (int j = 0; j < transformedImage.getWidth(); j++) {
                d = (int) phaseCongruency[i][j];
                raster.setSample(i, j, 0, phaseCongruency[j][i]);
            }
        }
        File myfile = new File("phaseCongruency" + fn + ".png");
        ImageIO.write(transformedImage, "png", myfile);
    }

    private void hystersisOperation() {
        int la = row;
        int ha = col;
        boolean change = true;

        // connection
        while (change) {
            change = false;
            for (int x = 1; x < la - 1; x++) {
                for (int y = 1; y < ha - 1; y++) {
                    if (pixelMask[x][y] == 1) {
                        if (pixelMask[x + 1][y] == -1) {
                            change = true;
                            pixelMask[x + 1][y] = 1;
                        }
                        if (pixelMask[x - 1][y] == -1) {
                            change = true;
                            pixelMask[x - 1][y] = 1;
                        }
                        if (pixelMask[x][y + 1] == -1) {
                            change = true;
                            pixelMask[x][y + 1] = 1;
                        }
                        if (pixelMask[x][y - 1] == -1) {
                            change = true;
                            pixelMask[x][y - 1] = 1;
                        }
                        if (pixelMask[x + 1][y + 1] == -1) {
                            change = true;
                            pixelMask[x + 1][y + 1] = 1;
                        }
                        if (pixelMask[x - 1][y - 1] == -1) {
                            change = true;
                            pixelMask[x - 1][y - 1] = 1;
                        }
                        if (pixelMask[x - 1][y + 1] == -1) {
                            change = true;
                            pixelMask[x - 1][y + 1] = 1;
                        }
                        if (pixelMask[x + 1][y - 1] == -1) {
                            change = true;
                            pixelMask[x + 1][y - 1] = 1;
                        }
                    }
                }
            }
            if (change) {
                for (int x = la - 2; x > 0; x--) {
                    for (int y = ha - 2; y > 0; y--) {
                        if (pixelMask[x][y] == 1) {
                            if (pixelMask[x + 1][y] == -1) {
                                change = true;
                                pixelMask[x + 1][y] = 1;
                            }
                            if (pixelMask[x - 1][y] == -1) {
                                change = true;
                                pixelMask[x - 1][y] = 1;
                            }
                            if (pixelMask[x][y + 1] == -1) {
                                change = true;
                                pixelMask[x][y + 1] = 1;
                            }
                            if (pixelMask[x][y - 1] == -1) {
                                change = true;
                                pixelMask[x][y - 1] = 1;
                            }
                            if (pixelMask[x + 1][y + 1] == -1) {
                                change = true;
                                pixelMask[x + 1][y + 1] = 1;
                            }
                            if (pixelMask[x - 1][y - 1] == -1) {
                                change = true;
                                pixelMask[x - 1][y - 1] = 1;
                            }
                            if (pixelMask[x - 1][y + 1] == -1) {
                                change = true;
                                pixelMask[x - 1][y + 1] = 1;
                            }
                            if (pixelMask[x + 1][y - 1] == -1) {
                                change = true;
                                pixelMask[x + 1][y - 1] = 1;
                            }
                        }
                    }
                }
            }
        }
    }
}
