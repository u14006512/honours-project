package Assignment3;

import java.awt.BorderLayout;
import java.awt.image.BufferedImage;
import java.awt.image.Raster;
import java.awt.image.WritableRaster;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.WindowConstants;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Warmaster
 */
public class CannyEdgeDetector {

    int[][] pixelMap;
    int row;
    int col;
    double sigma;
    int gaussianTemplateSize;
    double[][] gaussianTemplate;
    int[][] sobelX;
    int[][] sobelY;

    double[][] directionMatrix;
    int[][] magnitudeMatrix;
    int[][] suppressedMatrix;
    int[][] pixelMask;

    BufferedImage sobelImage;
    BufferedImage imageOriginal;
    BufferedImage nonMaxSuppression;
    BufferedImage cannyEdges;

    double t1, t2;

    String fn;

    public CannyEdgeDetector(String fn, double sig, int templateSize, double t, double tt) throws IOException {
        this.fn = fn;
        this.sigma = sig;
        this.gaussianTemplateSize = templateSize;

        this.t1 = t;
        this.t2 = tt;

        gaussianTemplate = new double[templateSize][templateSize];
        imageOriginal = ImageIO.read(new File(fn));

        row = imageOriginal.getHeight();
        col = imageOriginal.getWidth();

        displayOriginalImage();
        this.fn = fn.substring(0, fn.indexOf("."));

        pixelMap = producePixelMatrix(imageOriginal);

        constructGaussianTemplate();
        sobelX = new int[3][3];
        sobelY = new int[3][3];

        //SOBEL X
        sobelX[0][0] = -1;
        sobelX[0][1] = 0;
        sobelX[0][2] = 1;
        sobelX[1][0] = -2;
        sobelX[1][1] = 0;
        sobelX[1][2] = 2;
        sobelX[2][0] = -1;
        sobelX[2][1] = 0;
        sobelX[2][2] = 1;

        //SOBEL Y
        sobelY[0][0] = -1;
        sobelY[0][1] = -2;
        sobelY[0][2] = -1;
        sobelY[1][0] = 0;
        sobelY[1][1] = 0;
        sobelY[1][2] = 0;
        sobelY[2][0] = 1;
        sobelY[2][1] = 2;
        sobelY[2][2] = 1;

        System.out.println("Finished Init");
    }

    public void displayOriginalImage() {
        JFrame editorFrame = new JFrame("Canny Edge Detection- Original Image");
        editorFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        ImageIcon imageIcon = new ImageIcon(this.imageOriginal);
        JLabel jLabel = new JLabel();
        jLabel.setIcon(imageIcon);
        editorFrame.getContentPane().add(jLabel, BorderLayout.CENTER);

        editorFrame.pack();
        editorFrame.setLocationRelativeTo(null);
        editorFrame.setVisible(true);
    }

    public void produceCannyEdges() throws IOException {
        //Step 1: Gaussian Filter
        //Assumes template was constructed in constructor
        int[][] convoltMatrix;
        int shift = (int) Math.floor(gaussianTemplateSize / 2);
        int tmpVal = 0;
        int conRow, conCol;
        int r = 0, c = 0;

        conRow = row - shift * 2;
        conCol = col - shift * 2;

        convoltMatrix = new int[conRow][conCol];

        for (int i = shift; i <= row - shift - 1; i++) {
            c = 0;
            for (int j = shift; j <= col - shift - 1; j++) {
                tmpVal = produceConvolutedValue(i, j);
                convoltMatrix[r][c] = tmpVal;
                c++;
            }
            r++;
        }
        printTemplate();
        System.out.println("Gaussian Filter Applied");

        ///Now apply the Gradient detection algorithm
        int gradRow, gradCol;
        shift = (int) Math.floor(sobelX.length / 2);

        gradRow = conRow - shift * 2;
        gradCol = conCol - shift * 2;

        magnitudeMatrix = new int[gradRow][gradCol];
        directionMatrix = new double[gradRow][gradCol];

        r = 0;
        c = 0;
        int pixelX, pixelY;
        int val;

        for (int i = shift; i <= conRow - shift - 1; i++) {
            c = 0;
            for (int j = shift; j <= conCol - shift - 1; j++) {

                pixelX = sobelX[0][0] * convoltMatrix[i - 1][j - 1]
                        + sobelX[0][1] * convoltMatrix[i][j]
                        + sobelX[0][2] * convoltMatrix[i + 1][j - 1]
                        + sobelX[1][0] * convoltMatrix[i - 1][j]
                        + sobelX[1][1] * convoltMatrix[i][j]
                        + sobelX[1][2] * convoltMatrix[i + 1][j]
                        + sobelX[2][0] * convoltMatrix[i - 1][j + 1]
                        + sobelX[2][1] * convoltMatrix[i][j + 1]
                        + sobelX[2][2] * convoltMatrix[i + 1][j + 1];

                pixelY = sobelY[0][0] * convoltMatrix[i - 1][j - 1]
                        + sobelY[0][1] * convoltMatrix[i][j]
                        + sobelY[0][2] * convoltMatrix[i + 1][j - 1]
                        + sobelY[1][0] * convoltMatrix[i - 1][j]
                        + sobelY[1][1] * convoltMatrix[i][j]
                        + sobelY[1][2] * convoltMatrix[i + 1][j]
                        + sobelY[2][0] * convoltMatrix[i - 1][j + 1]
                        + sobelY[2][1] * convoltMatrix[i][j + 1]
                        + sobelY[2][2] * convoltMatrix[i + 1][j + 1];

                val = (int) Math.sqrt(Math.pow(pixelX, 2) + Math.pow(pixelY, 2));

                magnitudeMatrix[r][c] = val % 255;

                if (pixelY == 0) {
                    pixelY = 1;
                }
                directionMatrix[r][c] = Math.toDegrees(Math.atan(pixelX / pixelY));

                if (directionMatrix[r][c] < 0) {
                    directionMatrix[r][c] = directionMatrix[r][c] + 180;
                }
                c++;
            }
            r++;
        }
        System.out.println("Magnitudes Calculated");
        System.out.println("Directions Calculated");
        //saveSobelEdges();
        //displaySobelEdgesPicture();

        //Now Non-Maximum Suppression is done.
        suppressedMatrix = new int[magnitudeMatrix.length][magnitudeMatrix.length];

        for (int i = 0; i < magnitudeMatrix.length; i++) {
            for (int j = 0; j < magnitudeMatrix.length; j++) {
                suppressedMatrix[i][j] = magnitudeMatrix[i][j];
            }
        }

        ///Left 
        for (int i = 1; i < magnitudeMatrix.length - 1; i++) {
            if (directionMatrix[i][0] != 0) {
                if (directionMatrix[i][0] >= 67.5 && directionMatrix[i][0] < 112.5) {
                    if (magnitudeMatrix[i][0] > magnitudeMatrix[i - 1][0]
                            && magnitudeMatrix[i][0] > magnitudeMatrix[i + 1][0]) {
                        suppressedMatrix[i][0] = magnitudeMatrix[i][0];
                    } else {
                        suppressedMatrix[i][0] = 0;
                    }
                }
            }
        }
        ///Right
        for (int i = 1; i < magnitudeMatrix.length - 1; i++) {
            if (directionMatrix[i][magnitudeMatrix.length - 1] != 0) {
                if (directionMatrix[i][magnitudeMatrix.length - 1] >= 67.5 && directionMatrix[i][magnitudeMatrix.length - 1] < 112.5) {
                    if (magnitudeMatrix[i][magnitudeMatrix.length - 1] > magnitudeMatrix[i - 1][magnitudeMatrix.length - 1]
                            && magnitudeMatrix[i][magnitudeMatrix.length - 1] > magnitudeMatrix[i + 1][magnitudeMatrix.length - 1]) {
                        suppressedMatrix[i][magnitudeMatrix.length - 1] = magnitudeMatrix[i][magnitudeMatrix.length - 1];
                    } else {
                        suppressedMatrix[i][magnitudeMatrix.length - 1] = 0;
                    }
                }
            }
        }
        //Top
        for (int j = 1; j < magnitudeMatrix.length - 1; j++) {
            if (directionMatrix[0][j] != 0) {
                if (directionMatrix[0][j] >= 0 && directionMatrix[0][j] < 22.5) {
                    if (magnitudeMatrix[0][j] > magnitudeMatrix[0][j - 1]
                            && magnitudeMatrix[0][j] > magnitudeMatrix[0][j + 1]) {
                        suppressedMatrix[0][j] = magnitudeMatrix[0][j];
                    } else {
                        suppressedMatrix[0][j] = 0;
                    }
                }
                if (directionMatrix[0][j] > 157.5 && directionMatrix[0][j] <= 180) {
                    if (magnitudeMatrix[0][j] > magnitudeMatrix[0][j - 1]
                            && magnitudeMatrix[0][j] > magnitudeMatrix[0][j + 1]) {
                        suppressedMatrix[0][j] = magnitudeMatrix[0][j];
                    } else {
                        suppressedMatrix[0][j] = 0;
                    }
                }
            }
        }
        //Bottom
        int gg = magnitudeMatrix.length - 1;
        for (int j = 1; j < magnitudeMatrix.length - 1; j++) {
            if (directionMatrix[gg][j] != 0) {
                if (directionMatrix[gg][j] >= 0 && directionMatrix[gg][j] < 22.5) {
                    if (magnitudeMatrix[gg][j] > magnitudeMatrix[gg][j - 1]
                            && magnitudeMatrix[gg][j] > magnitudeMatrix[gg][j + 1]) {
                        suppressedMatrix[gg][j] = magnitudeMatrix[gg][j];
                    } else {
                        suppressedMatrix[gg][j] = 0;
                    }
                }
                if (directionMatrix[gg][j] > 157.5 && directionMatrix[gg][j] <= 180) {
                    if (magnitudeMatrix[gg][j] > magnitudeMatrix[gg][j - 1]
                            && magnitudeMatrix[gg][j] > magnitudeMatrix[gg][j + 1]) {
                        suppressedMatrix[gg][j] = magnitudeMatrix[gg][j];
                    } else {
                        suppressedMatrix[gg][j] = 0;
                    }
                }
            }
        }

        for (int i = 1; i < magnitudeMatrix.length - 1; i++) {
            for (int j = 1; j < magnitudeMatrix.length - 1; j++) {
                if (directionMatrix[i][j] != 0) {

                    //Case A: Top Left and Bottom Right
                    if (directionMatrix[i][j] >= 22.5 && directionMatrix[i][j] < 67.5) {
                        if (magnitudeMatrix[i][j] > magnitudeMatrix[i - 1][j - 1]
                                && magnitudeMatrix[i][j] > magnitudeMatrix[i + 1][j + 1]) {
                            suppressedMatrix[i][j] = magnitudeMatrix[i][j];
                        } else {
                            suppressedMatrix[i][j] = 0;
                        }
                    }
                    //Case B: Top and Bottom 
                    if (directionMatrix[i][j] >= 67.5 && directionMatrix[i][j] < 112.5) {
                        if (magnitudeMatrix[i][j] > magnitudeMatrix[i - 1][j]
                                && magnitudeMatrix[i][j] > magnitudeMatrix[i + 1][j]) {
                            suppressedMatrix[i][j] = magnitudeMatrix[i][j];
                        } else {
                            suppressedMatrix[i][j] = 0;
                        }
                    }
                    //Case C: Top Right and Bottom Left
                    if (directionMatrix[i][j] >= 112.5 && directionMatrix[i][j] < 157.5) {
                        if (magnitudeMatrix[i][j] > magnitudeMatrix[i - 1][j + 1]
                                && magnitudeMatrix[i][j] > magnitudeMatrix[i + 1][j - 1]) {
                            suppressedMatrix[i][j] = magnitudeMatrix[i][j];
                        } else {
                            suppressedMatrix[i][j] = 0;
                        }
                    }
                    //Case D: Left and Right A
                    if (directionMatrix[i][j] >= 0.0 && directionMatrix[i][j] < 22.5) {
                        if (magnitudeMatrix[i][j] > magnitudeMatrix[i][j - 1]
                                && magnitudeMatrix[i][j] > magnitudeMatrix[i][j + 1]) {
                            suppressedMatrix[i][j] = magnitudeMatrix[i][j];
                        } else {
                            suppressedMatrix[i][j] = 0;
                        }
                    }
                    //Case E: Left and Right B
                    if (directionMatrix[i][j] >= 157.5 && directionMatrix[i][j] <= 180.0) {
                        if (magnitudeMatrix[i][j] > magnitudeMatrix[i][j - 1]
                                && magnitudeMatrix[i][j] > magnitudeMatrix[i][j + 1]) {
                            suppressedMatrix[i][j] = magnitudeMatrix[i][j];
                        } else {
                            suppressedMatrix[i][j] = 0;
                        }
                    }

                }
            }
        }
        //saveNonMaxSuppression();
        //displaySuppressionPicture();
        System.out.println("Non-Maximum Suppression Done");

        ///Double Thresholding
        double highThreshold, lowThreshold;

        int max = getMax();

        highThreshold = (t1 * max);

        lowThreshold = (highThreshold * t2);

        pixelMask = new int[magnitudeMatrix.length][magnitudeMatrix.length];
        /*
        1: Strong edge
       -1: weak edge
        0: suppresed
         */

        for (int i = 0; i < suppressedMatrix.length; i++) {
            for (int j = 0; j < suppressedMatrix.length; j++) {

                if ((suppressedMatrix[i][j]) >= highThreshold) {
                    suppressedMatrix[i][j] = 255;
                    pixelMask[i][j] = 1;
                }
                if ((suppressedMatrix[i][j]) <= lowThreshold) {
                    suppressedMatrix[i][j] = 0;
                }
                if ((suppressedMatrix[i][j]) > lowThreshold && (suppressedMatrix[i][j]) <= highThreshold) {
                    pixelMask[i][j] = -1;
                }

            }
        }

        //saveNonMaxSuppressionWithDoubleThreshold();
        //displaySuppressionPicture();
        System.out.println("Double Thresholding Done");

        //Hystersis Operation
        //Corners
        //Top Left
        /*
        if (pixelMask[0][0] == -1) {
            if (pixelMask[1][0] == 1
                    || pixelMask[0][1] == 1
                    || pixelMask[1][1] == 1) {
                pixelMask[0][0] = 1;
            }
        }
        //Top Right
        if (pixelMask[0][magnitudeMatrix.length - 1] == -1) {
            if (pixelMask[0][magnitudeMatrix.length - 2] == 1
                    || pixelMask[1][magnitudeMatrix.length - 1] == 1
                    || pixelMask[1][magnitudeMatrix.length - 2] == 1) {
                pixelMask[0][magnitudeMatrix.length - 1] = 1;
            }
        }
        //Bottom Left
        if (pixelMask[magnitudeMatrix.length - 1][0] == -1) {
            if (pixelMask[magnitudeMatrix.length - 2][0] == 1
                    || pixelMask[magnitudeMatrix.length - 1][1] == 1
                    || pixelMask[magnitudeMatrix.length - 2][1] == 1) {
                pixelMask[magnitudeMatrix.length - 1][0] = 1;
            }
        }

        //Bottom Right
        if (pixelMask[magnitudeMatrix.length - 1][magnitudeMatrix.length - 1] == -1) {
            if (pixelMask[magnitudeMatrix.length - 1][magnitudeMatrix.length - 2] == 1
                    || pixelMask[magnitudeMatrix.length - 2][magnitudeMatrix.length - 1] == 1
                    || pixelMask[magnitudeMatrix.length - 2][magnitudeMatrix.length - 2] == 1) {
                pixelMask[magnitudeMatrix.length - 1][magnitudeMatrix.length - 1] = 1;
            }
        }
        //Edges
        //Left
        for (int i = 1; i < magnitudeMatrix.length - 1; i++) {
            if (pixelMask[i][0] ==-1) {
                if (pixelMask[i-1][0]==1||pixelMask[i-1][1]==1||pixelMask[i][1]==1||
                        pixelMask[i+1][1]==1||pixelMask[i+1][1]==1)
                {
                    pixelMask[i][0]=1;
                }
            }
        }
        //Right
        for (int i = 1; i < magnitudeMatrix.length - 1; i++) {
            if (pixelMask[i][magnitudeMatrix.length - 1] ==-1) {
                if (pixelMask[i-1][magnitudeMatrix.length - 1]==1||pixelMask[i-1][magnitudeMatrix.length - 2]==1||pixelMask[i][magnitudeMatrix.length - 2]==1||
                        pixelMask[i+1][magnitudeMatrix.length - 1]==1||pixelMask[i+1][magnitudeMatrix.length -2]==1)
                {
                    pixelMask[i][magnitudeMatrix.length - 1]=1;
                }
            }
        }
        //Top
        for (int j = 1; j < magnitudeMatrix.length - 1; j++) {
            if (pixelMask[0][j] ==-1) {
                if (pixelMask[0][j-1]==1||pixelMask[1][j-1]==1||pixelMask[1][j]==1||
                        pixelMask[1][j+1]==1||pixelMask[0][j+1]==1)
                {
                    pixelMask[0][j]=1;
                }
            }
        }
        gg = magnitudeMatrix.length - 1;
        //Bottom
        for (int j = 1; j < magnitudeMatrix.length - 1; j++) {
            if (pixelMask[gg][j] ==-1) {
                if (pixelMask[gg][j-1]==1||pixelMask[gg-1][j-1]==1||pixelMask[gg-1][j]==1||
                        pixelMask[gg-1][j+1]==1||pixelMask[gg][j+1]==1)
                {
                    pixelMask[gg][j]=1;
                }
            }
        }
        //General Case
        for (int i = 1; i < magnitudeMatrix.length - 1; i++) {
            for (int j = 1; j < magnitudeMatrix.length - 1; j++) {
                if (pixelMask[i][j] == -1) {
                    if (pixelMask[i - 1][j + 1] == 1 && pixelMask[i + 1][j - 1] == 1) {
                        pixelMask[i][j] = 1;
                    }
                    if (pixelMask[i - 1][j] == 1 && pixelMask[i + 1][j] == 1) {
                        pixelMask[i][j] = 1;
                    }
                    if (pixelMask[i - 1][j - 1] == 1 && pixelMask[i + 1][j + 1] == 1) {
                        pixelMask[i][j] = 1;
                    }
                    if (pixelMask[i][j - 1] == 1 && pixelMask[i][j + 1] == 1) {
                        pixelMask[i][j] = 1;
                    }
                }
            }
        }
         */
        hystersisOperation();
        for (int i = 0; i < magnitudeMatrix.length; i++) {
            for (int j = 0; j < magnitudeMatrix.length; j++) {
                if (pixelMask[i][j] == 1) {
                    suppressedMatrix[i][j] = 255;
                }
                if (pixelMask[i][j] == -1 || pixelMask[i][j] == 0) {
                    suppressedMatrix[i][j] = 0;
                }
            }
        }
        saveSobelEdges();
        displaySobelEdgesPicture();

        //saveCannyEdgesGrey();
        saveCannyEdgesBinary();
        displayCannyEdgesPicture();
        System.out.println("Hystersis Done");

    }

    private int getMax() {
        int v = -1;

        for (int i = 0; i < magnitudeMatrix.length; i++) {
            for (int j = 0; j < magnitudeMatrix.length; j++) {
                if (magnitudeMatrix[i][j] > v) {
                    v = magnitudeMatrix[i][j];
                }
            }
        }

        return v;
    }

    private void displayCannyEdgesPicture() {
        JFrame editorFrame = new JFrame("Canny Edge Detection- Final Image");
        editorFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        ImageIcon imageIcon = new ImageIcon(this.cannyEdges);
        JLabel jLabel = new JLabel();
        jLabel.setIcon(imageIcon);
        editorFrame.getContentPane().add(jLabel, BorderLayout.CENTER);

        editorFrame.pack();
        editorFrame.setLocationRelativeTo(null);
        editorFrame.setVisible(true);
    }

    private void saveCannyEdgesBinary() throws IOException {
        cannyEdges = new BufferedImage(magnitudeMatrix.length, magnitudeMatrix.length, BufferedImage.TYPE_BYTE_BINARY);
        int d;
        WritableRaster raster = cannyEdges.getRaster();

        for (int i = 0; i < cannyEdges.getHeight(); i++) {
            for (int j = 0; j < cannyEdges.getWidth(); j++) {
                d = suppressedMatrix[i][j];
                raster.setSample(i, j, 0, suppressedMatrix[i][j]);
            }
        }
        File myfile = new File("binary_cannyEdges" + fn + ".png");
        ImageIO.write(cannyEdges, "png", myfile);
    }

    private void saveCannyEdgesGrey() throws IOException {
        cannyEdges = new BufferedImage(magnitudeMatrix.length, magnitudeMatrix.length, BufferedImage.TYPE_BYTE_BINARY);
        int d;

        for (int i = 0; i < cannyEdges.getHeight(); i++) {
            for (int j = 0; j < cannyEdges.getWidth(); j++) {
                d = suppressedMatrix[i][j];
                cannyEdges.setRGB(i, j, (byte) suppressedMatrix[i][j]);
            }
        }
        File myfile = new File("grey_cannyEdges" + fn + ".png");
        ImageIO.write(cannyEdges, "png", myfile);
    }

    private void saveNonMaxSuppressionWithDoubleThreshold() throws IOException {
        nonMaxSuppression = new BufferedImage(magnitudeMatrix.length, magnitudeMatrix.length, BufferedImage.TYPE_BYTE_BINARY);
        int d;

        for (int i = 0; i < nonMaxSuppression.getHeight(); i++) {
            for (int j = 0; j < nonMaxSuppression.getWidth(); j++) {
                d = suppressedMatrix[i][j];
                nonMaxSuppression.setRGB(i, j, (byte) suppressedMatrix[i][j]);
            }
        }
        File myfile = new File("nonMax_Double_Threshold" + fn + ".png");
        ImageIO.write(nonMaxSuppression, "png", myfile);
    }

    private void saveNonMaxSuppression() throws IOException {
        nonMaxSuppression = new BufferedImage(magnitudeMatrix.length, magnitudeMatrix.length, BufferedImage.TYPE_BYTE_GRAY);
        int d;
        WritableRaster raster = nonMaxSuppression.getRaster();

        for (int i = 0; i < nonMaxSuppression.getHeight(); i++) {
            for (int j = 0; j < nonMaxSuppression.getWidth(); j++) {
                d = suppressedMatrix[i][j];
                raster.setSample(i, j, 0, suppressedMatrix[i][j]);
            }
        }
        File myfile = new File("nonMax_" + fn + ".png");
        ImageIO.write(nonMaxSuppression, "png", myfile);
    }

    private void displaySuppressionPicture() {
        JFrame editorFrame = new JFrame("Canny Edge Detection- Non-Maximum Suppression Image");
        editorFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        ImageIcon imageIcon = new ImageIcon(this.nonMaxSuppression);
        JLabel jLabel = new JLabel();
        jLabel.setIcon(imageIcon);
        editorFrame.getContentPane().add(jLabel, BorderLayout.CENTER);

        editorFrame.pack();
        editorFrame.setLocationRelativeTo(null);
        editorFrame.setVisible(true);
    }

    private void saveSobelEdges() throws IOException {
        sobelImage = new BufferedImage(magnitudeMatrix.length, magnitudeMatrix.length, BufferedImage.TYPE_BYTE_GRAY);
        int d;
        WritableRaster raster = sobelImage.getRaster();

        for (int i = 0; i < sobelImage.getHeight(); i++) {
            for (int j = 0; j < sobelImage.getWidth(); j++) {
                d = magnitudeMatrix[i][j];
                raster.setSample(i, j, 0, magnitudeMatrix[i][j]);
            }
        }
        File myfile = new File("sobel_" + fn + ".png");
        ImageIO.write(sobelImage, "png", myfile);
    }

    private void displaySobelEdgesPicture() {
        JFrame editorFrame = new JFrame("Canny Edge Detection- SOBEL Image");
        editorFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        ImageIcon imageIcon = new ImageIcon(this.sobelImage);
        JLabel jLabel = new JLabel();
        jLabel.setIcon(imageIcon);
        editorFrame.getContentPane().add(jLabel, BorderLayout.CENTER);

        editorFrame.pack();
        editorFrame.setLocationRelativeTo(null);
        editorFrame.setVisible(true);
    }

    private int produceConvolutedValue(int x, int y) {
        double value = 0;
        if (gaussianTemplateSize == 3) {
            value = gaussianTemplate[0][0] * pixelMap[x - 1][y - 1]
                    + gaussianTemplate[0][1] * pixelMap[x - 1][y]
                    + gaussianTemplate[0][2] * pixelMap[x - 1][y + 1]
                    + gaussianTemplate[1][0] * pixelMap[x][y - 1]
                    + gaussianTemplate[1][1] * pixelMap[x][y]
                    + gaussianTemplate[1][2] * pixelMap[x][y + 1]
                    + gaussianTemplate[2][0] * pixelMap[x + 1][y - 1]
                    + gaussianTemplate[2][1] * pixelMap[x + 1][y]
                    + gaussianTemplate[2][2] * pixelMap[x + 1][y + 1];
        }
        if (gaussianTemplateSize == 5) {
            value = gaussianTemplate[0][0] * pixelMap[x - 2][y - 2]
                    + +gaussianTemplate[0][1] * pixelMap[x - 2][y - 1]
                    + gaussianTemplate[0][2] * pixelMap[x - 2][y]
                    + gaussianTemplate[0][3] * pixelMap[x - 2][y + 1]
                    + gaussianTemplate[0][4] * pixelMap[x - 2][y + 2]
                    + gaussianTemplate[1][0] * pixelMap[x - 1][y - 2]
                    + gaussianTemplate[1][1] * pixelMap[x - 1][y - 1]
                    + gaussianTemplate[1][2] * pixelMap[x - 1][y]
                    + gaussianTemplate[1][3] * pixelMap[x - 1][y + 1]
                    + gaussianTemplate[1][4] * pixelMap[x - 1][y + 2]
                    + gaussianTemplate[2][0] * pixelMap[x][y - 2]
                    + gaussianTemplate[2][1] * pixelMap[x][y - 1]
                    + gaussianTemplate[2][2] * pixelMap[x][y]
                    + gaussianTemplate[2][3] * pixelMap[x][y + 1]
                    + gaussianTemplate[2][4] * pixelMap[x][y + 2]
                    + gaussianTemplate[3][0] * pixelMap[x + 1][y - 2]
                    + gaussianTemplate[3][1] * pixelMap[x + 1][y - 1]
                    + gaussianTemplate[3][2] * pixelMap[x + 1][y]
                    + gaussianTemplate[3][3] * pixelMap[x + 1][y + 1]
                    + gaussianTemplate[3][4] * pixelMap[x + 1][y + 2]
                    + gaussianTemplate[4][0] * pixelMap[x + 2][y - 2]
                    + gaussianTemplate[4][1] * pixelMap[x + 2][y - 1]
                    + gaussianTemplate[4][2] * pixelMap[x + 2][y]
                    + gaussianTemplate[4][3] * pixelMap[x + 2][y + 1]
                    + gaussianTemplate[4][4] * pixelMap[x + 2][y + 2];
        }

        return (int) Math.floor(value);
    }

    private int[][] producePixelMatrix(BufferedImage image) {
        int h = image.getHeight();
        int w = image.getWidth();
        int[][] result = new int[h][w];
        Raster r = image.getData();

        for (int i = 0; i < h; i++) {
            for (int j = 0; j < w; j++) {
                result[i][j] = r.getSample(i, j, 0);
            }
        }

        return result;
    }

    private void constructGaussianTemplate() {
        int centre;
        double sum = 0;
        double sigma2 = 2.0 * sigma * sigma;
        double r;

        centre = (int) (Math.floor(this.gaussianTemplateSize / 2));

        for (int i = 0; i < gaussianTemplateSize; i++) {
            for (int j = 0; j < gaussianTemplateSize; j++) {
                r = Math.sqrt(Math.pow(i - centre, 2) + Math.pow(j - centre, 2));
                gaussianTemplate[i][j] = (Math.exp(-(r * r) / sigma2)) / (Math.PI * sigma2);
                sum = sum + gaussianTemplate[i][j];
            }
        }
        for (int i = 0; i < gaussianTemplateSize; i++) {
            for (int j = 0; j < gaussianTemplateSize; j++) {
                gaussianTemplate[i][j] = gaussianTemplate[i][j] / sum;
            }
        }

        System.out.println("Gaussian Template Created");
    }

    private void printTemplate() {
        for (int i = 0; i < gaussianTemplate.length; i++) {
            for (int j = 0; j < gaussianTemplate[i].length - 1; j++) {
                System.out.print(gaussianTemplate[i][j] + ",");
            }
            System.out.print(gaussianTemplate[i][gaussianTemplate[i].length - 1]);
            System.out.println("");
        }
    }

    private void hystersisOperation() {
        int la = magnitudeMatrix.length;
        int ha = magnitudeMatrix.length;
        
        float pix;
        boolean change = true;

        // connection
        while (change) {
            change = false;
            for (int x = 1; x < la - 1; x++) {
                for (int y = 1; y < ha - 1; y++) {
                    if (pixelMask[x][y] == 1) {
                        if (pixelMask[x + 1][y] == -1) {
                            change = true;
                            pixelMask[x + 1] [y]=1;
                        }
                        if (pixelMask[x - 1][y] == -1) {
                            change = true;
                            pixelMask[x - 1][y]=1;
                        }
                        if (pixelMask[x][y + 1] == -1) {
                            change = true;
                            pixelMask[x][y + 1]= 1;
                        }
                        if (pixelMask[x][y - 1] == -1) {
                            change = true;
                            pixelMask[x][y - 1]=1;
                        }
                        if (pixelMask[x + 1][y + 1] == -1) {
                            change = true;
                            pixelMask[x + 1][y + 1]=1;
                        }
                        if (pixelMask[x - 1][ y - 1] == -1) {
                            change = true;
                            pixelMask[x - 1][y - 1] =1;
                        }
                        if (pixelMask[x - 1][ y + 1] == -1) {
                            change = true;
                            pixelMask[x - 1][y + 1]=1;
                        }
                        if (pixelMask[x + 1][y - 1]==-1) {
                            change = true;
                            pixelMask[x + 1][ y - 1]=1;
                        }
                    }
                }
            }
            if (change) {
                for (int x = la - 2; x > 0; x--) {
                    for (int y = ha - 2; y > 0; y--) {
                        if (pixelMask[x][y] == 1) {
                            if (pixelMask[x + 1][y] == -1) {
                                change = true;
                                pixelMask[x + 1][y]= 1;
                            }
                            if (pixelMask[x - 1][ y] == -1) {
                                change = true;
                                pixelMask[x - 1][y]= 1;
                            }
                            if (pixelMask[x][y + 1] ==-1) {
                                change = true;
                                pixelMask[x][y + 1]=1;
                            }
                            if (pixelMask[x][y - 1] == -1) {
                                change = true;
                                pixelMask[x] [y - 1]=1;
                            }
                            if (pixelMask[x + 1][y + 1] == -1) {
                                change = true;
                                pixelMask[x + 1][y + 1]=1;
                            }
                            if (pixelMask[x - 1][y - 1] == -1) {
                                change = true;
                                pixelMask[x - 1] [y - 1]= 1;
                            }
                            if (pixelMask[x - 1] [y + 1] == -1) {
                                change = true;
                                pixelMask[x - 1][y + 1]=1;
                            }
                            if (pixelMask[x + 1][y - 1] == -1) {
                                change = true;
                                pixelMask[x + 1][y - 1]=1;
                            }
                        }
                    }
                }
            }
        }
    }
}
