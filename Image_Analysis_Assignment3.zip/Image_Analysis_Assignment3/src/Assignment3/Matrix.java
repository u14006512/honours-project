/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Assignment3;

/**
 *
 * @author Warmaster
 */
public class Matrix {
    double [][] mat;
    
    int row;
    int col;
    
    Matrix(int r, int c)
    {
        row=r;
        col=c;
        
        mat=new double[r][c];
    }
          
}
