package Assignment3;

import java.io.IOException;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Warmaster
 */
public class CannyMain {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        String fn="mandrill.png";
        double t1=0.5;
        double t2=0.2;
       
        CannyEdgeDetector c=new CannyEdgeDetector(fn, 1, 5,t1,t2);
        c.produceCannyEdges();
    }
    
}
