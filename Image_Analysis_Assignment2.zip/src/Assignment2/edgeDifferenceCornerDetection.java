/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Assignment2;

import java.awt.BorderLayout;
import java.awt.image.BufferedImage;
import java.awt.image.WritableRaster;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.WindowConstants;

/**
 *
 * @author Warmaster
 */
public class edgeDifferenceCornerDetection {

    CannyEdgeDetector canny;
    int row;
    int col;

    BufferedImage edgeDifferenceCornerDetection;
    BufferedImage modImage;
    BufferedImage imageOriginal;
    
    String fn;
    int[][] initialProcessedMatrix;
    double[][] gradientMatrix;
    int[][] cornerMap;

    
    public edgeDifferenceCornerDetection(String fn) throws IOException {

        this.fn = fn;

        imageOriginal = ImageIO.read(new File(fn));
        imageOriginal=convertImage(imageOriginal);
        canny = new CannyEdgeDetector(fn, 1.4, 3, 0.5, 0.2);
        canny.produceCannyEdges();

        
        gradientMatrix = new double[canny.directionMatrix.length][canny.directionMatrix.length];
        initialProcessedMatrix = new int[canny.suppressedMatrix.length][canny.suppressedMatrix.length];
        for (int i = 0; i < canny.suppressedMatrix.length; i++) {
            for (int j = 0; j < canny.suppressedMatrix.length; j++) {
                initialProcessedMatrix[i][j] = canny.suppressedMatrix[i][j];
            }
        }

        for (int i = 0; i < canny.directionMatrix.length; i++) {
            for (int j = 0; j < canny.directionMatrix.length; j++) {
                gradientMatrix[i][j] = canny.directionMatrix[i][j];
            }
        }
        row = initialProcessedMatrix.length;
        col = initialProcessedMatrix.length;

        cornerMap = new int[initialProcessedMatrix.length][initialProcessedMatrix.length];
    }

    public void produceEdgeDifferenceCorners() throws IOException {
        for (int i = 1; i < cornerMap.length - 1; i++) {
            for (int j = 1; j < cornerMap.length - 1; j++) {
                if (initialProcessedMatrix[i][j] != 0) {

                    if (initialProcessedMatrix[i - 1][j] != 0
                            && initialProcessedMatrix[i + 1][j] != 0) {
                        cornerMap[i][j] = (int) Math.floor(Math.abs(gradientMatrix[i - 1][j] - gradientMatrix[i + 1][j]));
                    } else if (initialProcessedMatrix[i][j - 1] != 0
                            && initialProcessedMatrix[i][j + 1] != 0) {
                        cornerMap[i][j] = (int) Math.floor(Math.abs(gradientMatrix[i][j - 1] - gradientMatrix[i][j + 1]));
                    } else if (initialProcessedMatrix[i - 1][j - 1] != 0
                            && initialProcessedMatrix[i + 1][j + 1] != 0) {
                        cornerMap[i][j] = (int) Math.floor(Math.abs(gradientMatrix[i - 1][j - 1] - gradientMatrix[i + 1][j + 1]));
                    } else if (initialProcessedMatrix[i + 1][j - 1] != 0
                            && initialProcessedMatrix[i - 1][j + 1] != 0) {
                        cornerMap[i][j] = (int) Math.floor(Math.abs(gradientMatrix[i + 1][j - 1] - gradientMatrix[i - 1][j + 1]));
                    }

                }
            }
        }
        doTransform();
        saveCorners();
        saveModifiedPicture();
        displayCornerPicture();
        displayModifiedPicture();
    }
    
    private void doTransform()
    {
        for(int i=0;i<cornerMap.length;i++)
        {
            for(int j=0;j<cornerMap.length;j++)
            {
                if (cornerMap[i][j]>0)
                {
                    cornerMap[i][j]=255;
                }
            }
        }
    }
    private void saveCorners() throws IOException {
        edgeDifferenceCornerDetection = new BufferedImage(cornerMap.length, cornerMap.length, BufferedImage.TYPE_BYTE_BINARY);
        int d;
        WritableRaster raster = edgeDifferenceCornerDetection.getRaster();

        for (int i = 0; i < edgeDifferenceCornerDetection.getHeight(); i++) {
            for (int j = 0; j < edgeDifferenceCornerDetection.getWidth(); j++) {
                d = cornerMap[i][j];
                raster.setSample(i, j, 0, cornerMap[i][j]);
            }
        }
        File myfile = new File("edgeDifferenceCorners" + fn + ".png");
        ImageIO.write(edgeDifferenceCornerDetection, "png", myfile);
    }

    private void displayCornerPicture() {
        JFrame editorFrame = new JFrame("Edge Difference Corner Detection- Final Picture");
        editorFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        ImageIcon imageIcon = new ImageIcon(this.edgeDifferenceCornerDetection);
        JLabel jLabel = new JLabel();
        jLabel.setIcon(imageIcon);
        editorFrame.getContentPane().add(jLabel, BorderLayout.CENTER);

        editorFrame.pack();
        editorFrame.setLocationRelativeTo(null);
        editorFrame.setVisible(true);
    }
    private void saveModifiedPicture() throws IOException {
        int d;
        int start=imageOriginal.getHeight()-edgeDifferenceCornerDetection.getHeight();
        for (int i = start; i < edgeDifferenceCornerDetection.getHeight(); i++) {
            for (int j = start; j <edgeDifferenceCornerDetection.getHeight(); j++) {
           
                if (cornerMap[i][j] == 255) {
                    int r = 255;
                    int g = 0;
                    int b = 0;
                    int col = (r << 16) | (g << 8) | b;
                    imageOriginal.setRGB(i, j,col);
                } 
            }
        }
        File myfile = new File("ModifiedImage_EdgeDifference" + fn + ".png");
        ImageIO.write(imageOriginal, "png", myfile);
    }
    private void displayModifiedPicture() {
        JFrame editorFrame = new JFrame("Edge Difference Corner Detection- Final Picture Modified");
        editorFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        ImageIcon imageIcon = new ImageIcon(this.imageOriginal);
        JLabel jLabel = new JLabel();
        jLabel.setIcon(imageIcon);
        editorFrame.getContentPane().add(jLabel, BorderLayout.CENTER);

        editorFrame.pack();
        editorFrame.setLocationRelativeTo(null);
        editorFrame.setVisible(true);
    }
    private BufferedImage convertImage(BufferedImage bufferedImage) {
        if (bufferedImage.getType() == BufferedImage.TYPE_4BYTE_ABGR) {
            BufferedImage tmp=new BufferedImage(bufferedImage.getHeight(),bufferedImage.getWidth(),BufferedImage.TYPE_3BYTE_BGR);
            for (int y = 0; y < bufferedImage.getHeight(); ++y) {
                for (int x = 0; x < bufferedImage.getWidth(); ++x) {
                    int argb = bufferedImage.getRGB(x, y);
                    if ((argb & 0x00FFFFFF) == 0x00FFFFFF) { //if the pixel is transparent
                        tmp.setRGB(x, y, 0xFFFFFFFF); // white color.
                    }else 
                    {
                        tmp.setRGB(x, y, bufferedImage.getRGB(x, y));
                    }
                }
            }
            return tmp;
        }
        return bufferedImage;
    }
}
