/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Assignment2;

import java.awt.BorderLayout;
import java.awt.image.BufferedImage;
import java.awt.image.Raster;
import java.awt.image.WritableRaster;
import java.io.File;
import java.io.IOException;
import java.util.Vector;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.WindowConstants;

/**
 *
 * @author Warmaster
 */
public class MoravecCornerDetection {

    BufferedImage modImage;
    BufferedImage nonMaxSuppression;
    BufferedImage imageOriginal;
    String fn;
    int templateSize;
    double threshold;
    int row;
    int col;

//    double[][] gaussianTemplate;
    int[][] pixelMap;
    int[][] cornerMap;
    double[][] normalisedMap;

    int[][] sobelX;
    int[][] sobelY;

    double[][] directionMatrix;
    int[][] magnitudeMatrix;
    int[][] suppressedMatrix;

    public void produceMoravecCorners() throws IOException {
        for (int i = 0; i < row; i++) {
            for (int j = 0; j < col; j++) {
                cornerMap[i][j] = computeMinimumIntensityAroundPixel(i, j);
            }
        }
        //  printCornerMap();
        for (int i = 0; i < row; i++) {
            for (int j = 0; j < col; j++) {
                cornerMap[i][j] = cornerMap[i][j] % 255;
            }
        }
        double m = getMax();

        for (int i = 0; i < row; i++) {
            for (int j = 0; j < col; j++) {
                normalisedMap[i][j] = cornerMap[i][j] / m;
            }
        }/*
        printCornerMap();
        System.out.println("++++++++++++++++++++++++++++++++++++++++++++++++++");
        printNormalisedMap();
        System.out.println("++++++++++++++++++++++++++++++++++++++++++++++++++");
        performThresholding();
        printCornerMap();
        System.out.println("++++++++++++++++++++++++++++++++++++++++++++++++++");
        printNormalisedMap();
        System.out.println("++++++++++++++++++++++++++++++++++++++++++++++++++");
         */
        performThresholding();
        doNonMaxSuppression();

        saveModifiedPicture();
        displayModifiedPicture();
        //saveNonMaxSuppression();

        //displaySuppressionPicture();
    }

    private void performThresholding() {
        for (int i = 0; i < row; i++) {
            for (int j = 0; j < col; j++) {
                if (normalisedMap[i][j] < threshold) {
                    normalisedMap[i][j] = 0;
                    cornerMap[i][j] = 0;
                }
            }
        }
    }

    private int transformX(int xVal, int direction) {
        int b = xVal;
        switch (direction) {
            case 0:
                b = xVal - 1;
                break;
            case 1:
                b = xVal - 1;
                break;
            case 3:
                b = xVal + 1;
                break;
            case 4:
                b = xVal + 1;
                break;
            case 5:
                b = xVal + 1;
                break;
            case 7:
                b = xVal - 1;
                break;
        }
        return b;
    }

    private int transformY(int yVal, int direction) {
        int b = yVal;
        switch (direction) {
            case 1:
                b = yVal + 1;
                break;
            case 2:
                b = yVal + 1;
                break;
            case 3:
                b = yVal + 1;
                break;
            case 5:
                b = yVal - 1;
                break;
            case 6:
                b = yVal - 1;
                break;
            case 7:
                b = yVal - 1;
                break;
        }
        return b;
    }

    private int sumIntensity(Vector<Integer> a) {
        int b = 0;
        for (int i = 0; i < a.size(); i++) {
            b = b + a.get(i);
        }
        return b;
    }

    private int computeMinimumIntensityAroundPixel(int x, int y) {
        int[][][] templateWithCoordinates = new int[templateSize][templateSize][2];
        int minIntensity;
        int currentIntensity;
        int tmpIntensity;
        int shift = (int) Math.floor(templateSize / 2.0);
        int cshift = -1 * shift;
        int rshift = -1 * shift;

        Vector<Integer> baseIntensityVector = new Vector<>();
        Vector<Integer> shiftIntensityVector = new Vector<>();

        for (int i = 0; i < templateSize; i++) {
            cshift = -1 * shift;
            for (int j = 0; j < templateSize; j++) {
                templateWithCoordinates[i][j][0] = x + rshift;
                templateWithCoordinates[i][j][1] = y + cshift;
                cshift++;
            }
            rshift++;
        }

        for (int i = 0; i < templateSize; i++) {
            for (int j = 0; j < templateSize; j++) {
                if (templateWithCoordinates[i][j][0] >= 0
                        && templateWithCoordinates[i][j][1] >= 0
                        && templateWithCoordinates[i][j][1] < row
                        && templateWithCoordinates[i][j][0] < col) {
                    baseIntensityVector.add(
                            pixelMap[templateWithCoordinates[i][j][0]][templateWithCoordinates[i][j][1]]);
                }
            }
        }
        currentIntensity = sumIntensity(baseIntensityVector);
        minIntensity = Integer.MAX_VALUE;
        for (int a = 0; a < 8; a++) {
            shiftIntensityVector.clear();
            rshift = -1 * shift;

            for (int i = 0; i < templateSize; i++) {
                cshift = -1 * shift;
                for (int j = 0; j < templateSize; j++) {
                    templateWithCoordinates[i][j][0] = transformX(x, a) + rshift;
                    templateWithCoordinates[i][j][1] = transformY(y, a) + cshift;
                    cshift++;
                }
                rshift++;
            }
            for (int i = 0; i < templateSize; i++) {
                for (int j = 0; j < templateSize; j++) {
                    if (templateWithCoordinates[i][j][0] >= 0
                            && templateWithCoordinates[i][j][1] >= 0
                            && templateWithCoordinates[i][j][1] < row
                            && templateWithCoordinates[i][j][0] < col) {
                        shiftIntensityVector.add(
                                pixelMap[templateWithCoordinates[i][j][0]][templateWithCoordinates[i][j][1]]);
                    }
                }
            }
            tmpIntensity = sumIntensity(shiftIntensityVector);
            //System.out.println("Tmp Intensity for "+a+" : "+tmpIntensity);
            if (Math.pow(currentIntensity - tmpIntensity, 2) < minIntensity) {
                //System.out.println("tmp intensity:" +tmpIntensity);
                minIntensity = (int) Math.floor(Math.pow(currentIntensity - tmpIntensity, 2));

            }
        }
        return minIntensity;
    }

    private void doNonMaxSuppression() {
        int[][][] templateWithCoordinates = new int[templateSize][templateSize][2];
        int shift = (int) Math.floor(templateSize / 2.0);
        int cshift = -1 * shift;
        int rshift = -1 * shift;
        int max;
        Vector<Integer> baseIntensityVector = new Vector<>();

        for (int x = 0; x < row; x++) {
            for (int y = 0; y < col; y++) {

                rshift = -1 * shift;
                baseIntensityVector.clear();

                for (int i = 0; i < templateSize; i++) {
                    cshift = -1 * shift;
                    for (int j = 0; j < templateSize; j++) {
                        templateWithCoordinates[i][j][0] = x + rshift;
                        templateWithCoordinates[i][j][1] = y + cshift;
                        cshift++;
                    }
                    rshift++;
                }

                for (int i = 0; i < templateSize; i++) {
                    for (int j = 0; j < templateSize; j++) {
                        if (templateWithCoordinates[i][j][0] >= 0
                                && templateWithCoordinates[i][j][1] >= 0
                                && templateWithCoordinates[i][j][1] < row
                                && templateWithCoordinates[i][j][0] < col) {
                            baseIntensityVector.add(
                                    cornerMap[templateWithCoordinates[i][j][0]][templateWithCoordinates[i][j][1]]);
                        }
                    }
                }

                max = cornerMap[x][y];
                for (int w = 0; w < baseIntensityVector.size(); w++) {
                    if (baseIntensityVector.get(w) > max && baseIntensityVector.get(w) != 0) {
                        max = baseIntensityVector.get(w);
                    }
                }

                if (cornerMap[x][y] == max) {
                    suppressedMatrix[x][y] = 0;
                } else {
                    suppressedMatrix[x][y] = 255;
                }
            }
        }
    }

    private double getMax() {
        double max = -1.0;

        for (int i = 0; i < row; i++) {
            for (int j = 0; j < col; j++) {
                if (cornerMap[i][j] > max) {
                    max = cornerMap[i][j];
                }
            }
        }
        return max;
    }

    private void printCornerMap() {
        for (int i = 0; i < cornerMap.length; i++) {
            for (int j = 0; j < cornerMap[i].length - 1; j++) {
                System.out.print(cornerMap[i][j] + ",");
            }
            System.out.print(cornerMap[i][cornerMap[i].length - 1]);
            System.out.println("");
        }
    }

    private void printNormalisedMap() {
        for (int i = 0; i < normalisedMap.length; i++) {
            for (int j = 0; j < normalisedMap[i].length - 1; j++) {
                System.out.print(normalisedMap[i][j] + ",");
            }
            System.out.print(normalisedMap[i][normalisedMap[i].length - 1]);
            System.out.println("");
        }
    }

    private BufferedImage convertImage(BufferedImage bufferedImage) {
        if (bufferedImage.getType() == BufferedImage.TYPE_4BYTE_ABGR) {
            BufferedImage tmp=new BufferedImage(bufferedImage.getHeight(),bufferedImage.getWidth(),BufferedImage.TYPE_3BYTE_BGR);
            for (int y = 0; y < bufferedImage.getHeight(); ++y) {
                for (int x = 0; x < bufferedImage.getWidth(); ++x) {
                    int argb = bufferedImage.getRGB(x, y);
                    if ((argb & 0x00FFFFFF) == 0x00FFFFFF) { //if the pixel is transparent
                        tmp.setRGB(x, y, 0xFFFFFFFF); // white color.
                    }else 
                    {
                        tmp.setRGB(x, y, bufferedImage.getRGB(x, y));
                    }
                }
            }
            return tmp;
        }
        return bufferedImage;
    }

    public MoravecCornerDetection(String fn, int template, double thres) throws IOException {
        this.fn = fn;
        this.templateSize = template;

        this.threshold = thres;
        //4byte_ABGR -->images like engine
        //3byte_bgr           -->images I got from class
        imageOriginal = ImageIO.read(new File(fn));
        imageOriginal=convertImage(imageOriginal);
        row = imageOriginal.getHeight();
        col = imageOriginal.getWidth();

        displayOriginalImage();
        this.fn = fn.substring(0, fn.indexOf("."));

        pixelMap = producePixelMatrix(imageOriginal);
        cornerMap = new int[row][col];
        normalisedMap = new double[row][col];
        suppressedMatrix = new int[row][col];

    }

    private int[][] producePixelMatrix(BufferedImage image) {
        int h = image.getHeight();
        int w = image.getWidth();
        int[][] result = new int[h][w];
        Raster r = image.getData();

        for (int i = 0; i < h; i++) {
            for (int j = 0; j < w; j++) {
                result[i][j] = r.getSample(i, j, 0);
            }
        }

        return result;
    }

    private void displayOriginalImage() {
        JFrame editorFrame = new JFrame("Moravec Corner Detection- Original Image");
        editorFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        ImageIcon imageIcon = new ImageIcon(this.imageOriginal);
        JLabel jLabel = new JLabel();
        jLabel.setIcon(imageIcon);
        editorFrame.getContentPane().add(jLabel, BorderLayout.CENTER);

        editorFrame.pack();
        editorFrame.setLocationRelativeTo(null);
        editorFrame.setVisible(true);
    }

    private void saveModifiedPicture() throws IOException {
        int d;

        for (int i = 0; i < imageOriginal.getHeight(); i++) {
            for (int j = 0; j < imageOriginal.getWidth(); j++) {
                d = pixelMap[i][j];

                if (suppressedMatrix[i][j] == 255) {
                    int r = 255;
                    int g = 0;
                    int b = 0;
                    int col = (r << 16) | (g << 8) | b;
                    imageOriginal.setRGB(i, j, col);
                }
            }
        }
        File myfile = new File("ModifiedImage_Moravec" + fn + ".png");
        ImageIO.write(imageOriginal, "png", myfile);
    }

    private void displayModifiedPicture() {
        JFrame editorFrame = new JFrame("Moravec Corner Detection- Final Picture Modified");
        editorFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        ImageIcon imageIcon = new ImageIcon(this.imageOriginal);
        JLabel jLabel = new JLabel();
        jLabel.setIcon(imageIcon);
        editorFrame.getContentPane().add(jLabel, BorderLayout.CENTER);

        editorFrame.pack();
        editorFrame.setLocationRelativeTo(null);
        editorFrame.setVisible(true);
    }

    private void saveNonMaxSuppression() throws IOException {
        nonMaxSuppression = new BufferedImage(row, col, BufferedImage.TYPE_BYTE_BINARY);
        int d;
        WritableRaster raster = nonMaxSuppression.getRaster();

        for (int i = 0; i < nonMaxSuppression.getHeight(); i++) {
            for (int j = 0; j < nonMaxSuppression.getWidth(); j++) {
                d = suppressedMatrix[i][j];
                raster.setSample(i, j, 0, suppressedMatrix[i][j]);
            }
        }
        File myfile = new File("nonMax_" + fn + ".png");
        ImageIO.write(nonMaxSuppression, "png", myfile);
    }

    private void displaySuppressionPicture() {
        JFrame editorFrame = new JFrame("Moravec Corner Detection- Final Picture");
        editorFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        ImageIcon imageIcon = new ImageIcon(this.nonMaxSuppression);
        JLabel jLabel = new JLabel();
        jLabel.setIcon(imageIcon);
        editorFrame.getContentPane().add(jLabel, BorderLayout.CENTER);

        editorFrame.pack();
        editorFrame.setLocationRelativeTo(null);
        editorFrame.setVisible(true);
    }
}
