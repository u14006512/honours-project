/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Warmaster
 */
public class DataPoint {
   private long epochNum;
   private double accValue;
   
   DataPoint()
   {
       
   }
   
   DataPoint(long inE,double inA)
   {
       epochNum=inE;
       accValue=inA;
   }
   
   double getA()
   {
       return  accValue;
   }
   
   long getE()
   {
       return  epochNum;
   }
}
