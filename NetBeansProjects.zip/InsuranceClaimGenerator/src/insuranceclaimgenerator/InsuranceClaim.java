/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package insuranceclaimgenerator;

/**
 *
 * @author Warmaster
 */
public class InsuranceClaim {
    ///TO DO: ADD ALL TYPES; The machine learning will be extracted from a single line and stored in an array.
    //Generate a full claim 
    ///Classification Base Data
    public Boolean claimIndicator;
    public String dateOfLoss,dateOfClaim,dateOfBirth;
    public double sumInsured,policyRevenue,amountPaid;
    public String policyStartDate,policyEndDate;
    public String serviceProvider;
    
    ///Other needed Information
    
    public String claimReason;
    public String agencyID;
    public String insuredID;
    public String insuredName;
    public String insuredSurname;
    public String gender;
    public String kindOfLoss;
    public String policyStreet;
    public String policyProvince;
    public String policyCity;
    public String policyArea;
    public String policyPostalCode;
    public String province;
    public String city;
    public String area;
    public String postalCode;
    public String maritalStatus;
    public String otherName;
    public String otherSurname;
}
