/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package insuranceclaimgenerator;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author Warmaster
 */
public class InsuranceClaimGenerator {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        GenerationEngine genEng=new GenerationEngine();
        String c;
        int x,y;
        String a,b;
        
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("===============================================");
        System.out.println("Enter an option to proceed");
        System.out.println("1 - Generate Full Insurance Claim Data");
        System.out.println("2 - Generate Classifer Training Set");
        System.out.print("Choice: ");
        c=(reader.readLine());
        
        if (c.equals("1"))
        {
            genEng.generateFullClaims();
            
        } else 
            {
                System.out.println("Enter the number of positive training examples");
                System.out.print("Number: ");
                a=reader.readLine();
                System.out.println("Enter the number of negative training examples");
                System.out.print("Number: ");
                b=reader.readLine();
                
                x=Integer.parseInt(a);
                y=Integer.parseInt(b);
                genEng.generateTrainingData(x, y);
            }
        
        
        System.out.println("===============================================");
    }
    
}
