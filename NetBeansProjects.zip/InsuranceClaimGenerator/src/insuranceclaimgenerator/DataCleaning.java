/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package insuranceclaimgenerator;

import java.util.Random;

/**
 *
 * @author Warmaster
 */
public class DataCleaning {
    public static void dirtyClaim(InsuranceClaim claim)
    {
        String garbage[]=new String[10];
        garbage[0]="#";
        garbage[1]="%";
        garbage[2]="@";
        garbage[3]="!";
        garbage[4]="&";
        garbage[5]="^";
        garbage[6]="~";
        garbage[7]="}";
        garbage[8]="?";
        garbage[9]="$";
        
        Random s=new Random(System.nanoTime());
        
        int c=s.nextInt(100)+1;
        double chance=c/100.0;
        String g;
        int v;
        String zz;
        if (chance<=0.6)
        {
            int c2;
            
                c2=s.nextInt(5);

            switch (c2) {
                case 0:
                    int numTimes=s.nextInt(10);
                    for (int i=0;i<numTimes;i++){
                    g=garbage[s.nextInt(10)];
                    v= s.nextInt(claim.serviceProvider.length());
                    
                    if (v==0){v=1;}
                    
                    
                    zz=claim.serviceProvider.substring(0,v)+g;
                   zz=zz+claim.serviceProvider.substring(v);
                   claim.serviceProvider=zz;
                    }
                    break;
                case 1:
                    numTimes=s.nextInt(10);
                    for (int i=0;i<numTimes;i++){
                    g=garbage[s.nextInt(10)];
                    v= s.nextInt(claim.kindOfLoss.length());
                    
                    if (v==0){v=1;}
                    
                    
                    zz=claim.kindOfLoss.substring(0,v)+g;
                   zz=zz+claim.kindOfLoss.substring(v);
                   claim.kindOfLoss=zz;
                    } 
                   break;
                case 2:
                    numTimes=s.nextInt(10);
                    for (int i=0;i<numTimes;i++){ 
                    g=garbage[s.nextInt(10)];
                    v= s.nextInt(claim.otherName.length());
                    
                    if (v==0){v=1;}
                    
                    
                   zz=claim.otherName.substring(0,v)+g;
                   zz=zz+claim.otherName.substring(v);
                   claim.otherName=zz;
                    }
                   break;
                case 3:
                     numTimes=s.nextInt(10);
                    for (int i=0;i<numTimes;i++){
                    g=garbage[s.nextInt(10)];
                    v= s.nextInt(claim.otherSurname.length());
                    
                    if (v==0){v=1;}
                    
                    
                   zz=claim.otherSurname.substring(0,v)+g;
                   zz=zz+claim.otherSurname.substring(v);
                   claim.otherSurname=zz;
                    } 
                   break;
                case 4:
                     numTimes=s.nextInt(10);
                    for (int i=0;i<numTimes;i++){
                    g=garbage[s.nextInt(10)];
                    v= s.nextInt(claim.agencyID.length());
                    
                    if (v==0){v=1;}
                    
                    
                   zz=claim.agencyID.substring(0,v)+g;
                   zz=zz+claim.agencyID.substring(v);
                   claim.agencyID=zz;
                    } 
                   break;
            }
                
            
        } else 
            {
                int c2=s.nextInt(3);
                int x,y,z;
                if (c2==0)
                {
                
                x=Integer.parseInt(claim.dateOfBirth.split("/")[0]);
                y=Integer.parseInt(claim.dateOfBirth.split("/")[1]);
                z=Integer.parseInt(claim.dateOfBirth.split("/")[2]);
                ///yyyy/mm/dd
                claim.dateOfBirth=String.valueOf(z)+"|"+String.valueOf(y)+"|"+String.valueOf(x);
                }
                
                if (c2==1)
                {
                x=Integer.parseInt(claim.dateOfClaim.split("/")[0]);
                y=Integer.parseInt(claim.dateOfClaim.split("/")[1]);
                z=Integer.parseInt(claim.dateOfClaim.split("/")[2]);
                ///yyyy/mm/dd
                claim.dateOfClaim=String.valueOf(z)+":"+String.valueOf(y)+":"+String.valueOf(x);
                }
                if (c2==2)
                {
                x=Integer.parseInt(claim.dateOfLoss.split("/")[0]);
                y=Integer.parseInt(claim.dateOfLoss.split("/")[1]);
                z=Integer.parseInt(claim.dateOfLoss.split("/")[2]);
                ///yyyy/mm/dd
                claim.dateOfLoss=String.valueOf(z)+","+String.valueOf(y)+","+String.valueOf(x);
                }
            }
        
    }
    public static String purgeString(String text,String symbol)
    {   int pos;
        while (text.contains(symbol)==true)
        {
            pos=text.indexOf(symbol);
            
            if (pos==0)
            {
                text=text.substring(1);
            }else 
            if (pos==(text.length()-1))
            {
                text=text.substring(0,text.length()-2);
            } else
                {
                    text=text.substring(0,pos)+text.substring(pos+1);
                } 
        }
        
        return text;
    }
    public static void cleanupClaim(InsuranceClaim claim)
    {
        ///////////////////////////////////////////////////////////////////////////
        if (claim.agencyID.contains("#"))
        {
            claim.agencyID=purgeString(claim.agencyID,"#");
        }
        if (claim.otherName.contains("#"))
        {
            claim.otherName=purgeString(claim.otherName,"#");
        }
        
        if (claim.otherSurname.contains("#"))
        {
            claim.otherSurname=purgeString(claim.otherSurname,"#");
        }
        if (claim.kindOfLoss.contains("#"))
        {
            claim.kindOfLoss=purgeString(claim.kindOfLoss,"#");
        }
        if (claim.serviceProvider.contains("#"))
        {
            claim.serviceProvider=purgeString(claim.serviceProvider,"#");
        }
        //////////////////////////////////////////////////////////////////////////
        
        ///////////////////////////////////////////////////////////////////////////
        if (claim.agencyID.contains("%"))
        {
            claim.agencyID=purgeString(claim.agencyID,"%");
        }
        if (claim.otherName.contains("%"))
        {
            claim.otherName=purgeString(claim.otherName,"%");
        }
        
        if (claim.otherSurname.contains("%"))
        {
            claim.otherSurname=purgeString(claim.otherSurname,"%");
        }
        if (claim.kindOfLoss.contains("%"))
        {
            claim.kindOfLoss=purgeString(claim.kindOfLoss,"%");
        }
        if (claim.serviceProvider.contains("%"))
        {
            claim.serviceProvider=purgeString(claim.serviceProvider,"%");
        }
        //////////////////////////////////////////////////////////////////////////
        
        ///////////////////////////////////////////////////////////////////////////
        if (claim.agencyID.contains("@"))
        {
            claim.agencyID=purgeString(claim.agencyID,"@");
        }
        if (claim.otherName.contains("@"))
        {
            claim.otherName=purgeString(claim.otherName,"@");
        }
        
        if (claim.otherSurname.contains("@"))
        {
            claim.otherSurname=purgeString(claim.otherSurname,"@");
        }
        if (claim.kindOfLoss.contains("@"))
        {
            claim.kindOfLoss=purgeString(claim.kindOfLoss,"@");
        }
        if (claim.serviceProvider.contains("@"))
        {
            claim.serviceProvider=purgeString(claim.serviceProvider,"@");
        }
        //////////////////////////////////////////////////////////////////////////
        
        ///////////////////////////////////////////////////////////////////////////
        if (claim.agencyID.contains("!"))
        {
            claim.agencyID=purgeString(claim.agencyID,"!");
        }
        if (claim.otherName.contains("!"))
        {
            claim.otherName=purgeString(claim.otherName,"!");
        }
        
        if (claim.otherSurname.contains("!"))
        {
            claim.otherSurname=purgeString(claim.otherSurname,"!");
        }
        if (claim.kindOfLoss.contains("!"))
        {
            claim.kindOfLoss=purgeString(claim.kindOfLoss,"!");
        }
        if (claim.serviceProvider.contains("!"))
        {
            claim.serviceProvider=purgeString(claim.serviceProvider,"!");
        }
        //////////////////////////////////////////////////////////////////////////
        
        ///////////////////////////////////////////////////////////////////////////
        if (claim.agencyID.contains("&"))
        {
            claim.agencyID=purgeString(claim.agencyID,"&");
        }
        if (claim.otherName.contains("&"))
        {
            claim.otherName=purgeString(claim.otherName,"&");
        }
        
        if (claim.otherSurname.contains("&"))
        {
            claim.otherSurname=purgeString(claim.otherSurname,"&");
        }
        if (claim.kindOfLoss.contains("&"))
        {
            claim.kindOfLoss=purgeString(claim.kindOfLoss,"&");
        }
        if (claim.serviceProvider.contains("&"))
        {
            claim.serviceProvider=purgeString(claim.serviceProvider,"&");
        }
        //////////////////////////////////////////////////////////////////////////
        
        ///////////////////////////////////////////////////////////////////////////
        if (claim.agencyID.contains("^"))
        {
            claim.agencyID=purgeString(claim.agencyID,"^");
        }
        if (claim.otherName.contains("^"))
        {
            claim.otherName=purgeString(claim.otherName,"^");
        }
        
        if (claim.otherSurname.contains("^"))
        {
            claim.otherSurname=purgeString(claim.otherSurname,"^");
        }
        if (claim.kindOfLoss.contains("^"))
        {
            claim.kindOfLoss=purgeString(claim.kindOfLoss,"^");
        }
        if (claim.serviceProvider.contains("^"))
        {
            claim.serviceProvider=purgeString(claim.serviceProvider,"^");
        }
        //////////////////////////////////////////////////////////////////////////
        
        ///////////////////////////////////////////////////////////////////////////
        if (claim.agencyID.contains("~"))
        {
            claim.agencyID=purgeString(claim.agencyID,"~");
        }
        if (claim.otherName.contains("~"))
        {
            claim.otherName=purgeString(claim.otherName,"~");
        }
        
        if (claim.otherSurname.contains("~"))
        {
            claim.otherSurname=purgeString(claim.otherSurname,"~");
        }
        if (claim.kindOfLoss.contains("~"))
        {
            claim.kindOfLoss=purgeString(claim.kindOfLoss,"~");
        }
        if (claim.serviceProvider.contains("~"))
        {
            claim.serviceProvider=purgeString(claim.serviceProvider,"~");
        }
        //////////////////////////////////////////////////////////////////////////
        
        ///////////////////////////////////////////////////////////////////////////
        if (claim.agencyID.contains("}"))
        {
            claim.agencyID=purgeString(claim.agencyID,"}");
        }
        if (claim.otherName.contains("}"))
        {
            claim.otherName=purgeString(claim.otherName,"}");
        }
        
        if (claim.otherSurname.contains("}"))
        {
            claim.otherSurname=purgeString(claim.otherSurname,"}");
        }
        if (claim.kindOfLoss.contains("}"))
        {
            claim.kindOfLoss=purgeString(claim.kindOfLoss,"}");
        }
        if (claim.serviceProvider.contains("}"))
        {
            claim.serviceProvider=purgeString(claim.serviceProvider,"}");
        }
        //////////////////////////////////////////////////////////////////////////
        
        ///////////////////////////////////////////////////////////////////////////
        if (claim.agencyID.contains("?"))
        {
            claim.agencyID=purgeString(claim.agencyID,"?");
        }
        if (claim.otherName.contains("?"))
        {
            claim.otherName=purgeString(claim.otherName,"?");
        }
        
        if (claim.otherSurname.contains("?"))
        {
            claim.otherSurname=purgeString(claim.otherSurname,"?");
        }
        if (claim.kindOfLoss.contains("?"))
        {
            claim.kindOfLoss=purgeString(claim.kindOfLoss,"?");
        }
        if (claim.serviceProvider.contains("?"))
        {
            claim.serviceProvider=purgeString(claim.serviceProvider,"?");
        }
        //////////////////////////////////////////////////////////////////////////
        
        ///////////////////////////////////////////////////////////////////////////
        if (claim.agencyID.contains("$"))
        {
            claim.agencyID=purgeString(claim.agencyID,"$");
        }
        if (claim.otherName.contains("$"))
        {
            claim.otherName=purgeString(claim.otherName,"$");
        }
        
        if (claim.otherSurname.contains("$"))
        {
            claim.otherSurname=purgeString(claim.otherSurname,"$");
        }
        if (claim.kindOfLoss.contains("$"))
        {
            claim.kindOfLoss=purgeString(claim.kindOfLoss,"$");
        }
        if (claim.serviceProvider.contains("$"))
        {
            claim.serviceProvider=purgeString(claim.serviceProvider,"$");
        }
        //////////////////////////////////////////////////////////////////////////
        
        ////check the dates
        
        int x = 0,y = 0,z = 0;
        if (claim.dateOfBirth.contains(":"))
        {
            x=Integer.parseInt(claim.dateOfBirth.split(":")[0]);
            y=Integer.parseInt(claim.dateOfBirth.split(":")[1]);
            z=Integer.parseInt(claim.dateOfBirth.split(":")[2]);
          claim.dateOfBirth=String.valueOf(x)+"/"+String.valueOf(y)+"/"+String.valueOf(z);
        }
        if (claim.dateOfBirth.contains(","))
        {
            x=Integer.parseInt(claim.dateOfBirth.split(",")[0]);
            y=Integer.parseInt(claim.dateOfBirth.split(",")[1]);
            z=Integer.parseInt(claim.dateOfBirth.split(",")[2]);
          claim.dateOfBirth=String.valueOf(x)+"/"+String.valueOf(y)+"/"+String.valueOf(z);
        }
        if (claim.dateOfBirth.contains("|"))
        {
            x=Integer.parseInt(claim.dateOfBirth.split("|")[0]);
            y=Integer.parseInt(claim.dateOfBirth.split("|")[1]);
            z=Integer.parseInt(claim.dateOfBirth.split("|")[2]);
            claim.dateOfBirth=String.valueOf(x)+"/"+String.valueOf(y)+"/"+String.valueOf(z);
        }
        if (claim.dateOfLoss.contains(":"))
        {
            x=Integer.parseInt(claim.dateOfLoss.split(":")[0]);
            y=Integer.parseInt(claim.dateOfLoss.split(":")[1]);
            z=Integer.parseInt(claim.dateOfLoss.split(":")[2]);
          claim.dateOfLoss=String.valueOf(x)+"/"+String.valueOf(y)+"/"+String.valueOf(z);
        }
        if (claim.dateOfLoss.contains(","))
        {
            x=Integer.parseInt(claim.dateOfLoss.split(",")[0]);
            y=Integer.parseInt(claim.dateOfLoss.split(",")[1]);
            z=Integer.parseInt(claim.dateOfLoss.split(",")[2]);
          claim.dateOfLoss=String.valueOf(x)+"/"+String.valueOf(y)+"/"+String.valueOf(z);
        }
        if ( claim.dateOfLoss.contains("|"))
        {
            x=Integer.parseInt(claim.dateOfLoss.split("|")[0]);
            y=Integer.parseInt(claim.dateOfLoss.split("|")[1]);
            z=Integer.parseInt(claim.dateOfLoss.split("|")[2]);
          claim.dateOfLoss=String.valueOf(x)+"/"+String.valueOf(y)+"/"+String.valueOf(z);
        }
        if (claim.dateOfClaim.contains(":"))
        {
            x=Integer.parseInt(claim.dateOfClaim.split(":")[0]);
            y=Integer.parseInt(claim.dateOfClaim.split(":")[1]);
            z=Integer.parseInt(claim.dateOfClaim.split(":")[2]);
          claim.dateOfClaim=String.valueOf(x)+"/"+String.valueOf(y)+"/"+String.valueOf(z);
        }
        if (claim.dateOfClaim.contains("|"))
        {
            x=Integer.parseInt(claim.dateOfClaim.split("|")[0]);
            y=Integer.parseInt(claim.dateOfClaim.split("|")[1]);
            z=Integer.parseInt(claim.dateOfClaim.split("|")[2]);
          claim.dateOfClaim=String.valueOf(x)+"/"+String.valueOf(y)+"/"+String.valueOf(z);
        }if (claim.dateOfClaim.contains(","))
        {
            x=Integer.parseInt(claim.dateOfClaim.split(",")[0]);
            y=Integer.parseInt(claim.dateOfClaim.split(",")[1]);
            z=Integer.parseInt(claim.dateOfClaim.split(",")[2]);
          claim.dateOfClaim=String.valueOf(x)+"/"+String.valueOf(y)+"/"+String.valueOf(z);
        }
          
    }
}
