/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package insuranceclaimgenerator;

import java.io.IOException;
import java.util.Random;

/**
 *
 * @author Warmaster
 */
public class GenerationEngine {
    int numClaims;
    InsuranceClaim arrClaims[];
    
    public InsuranceClaim[] generateFullClaims() throws IOException
    {
        System.out.println("Beginning Claim Generation");
        arrClaims=new InsuranceClaim[100000];
        Random s=new Random(System.nanoTime());
        double chance;
        for(int i=0;i<100000;i++)
        {
            
            arrClaims[i]=randomClaimGenerator.generateInsuranceClaim();
            chance=s.nextDouble();
            if (chance<=.10)
            {
                DataCleaning.cleanupClaim(arrClaims[i]);
                randomClaimGenerator.generateFraudulentClaim(arrClaims[i]);
            }
            
            DataCleaning.cleanupClaim(arrClaims[i]);
        }
        System.out.println("Beginning Process of Data Cleaning");
        PPDM.produceFileForNN(arrClaims);
        System.out.println("Finished Producing CSV File");
        PPDM.produceInputSetForNN();
        System.out.println("Finished Producing Data For Neural Network");
        
        return arrClaims;
    }
    
    public InsuranceClaim[] generateTrainingData(int numPositiveExamples,int numNegExamples) throws IOException
    {
        int chance;
        Random s=new Random(System.nanoTime());
        int countPos=0,countNeg=0;
        int total=numNegExamples+numPositiveExamples;
        int tot[]=new int[total];
        
        ///0-->pos, 1-->neg
        while (countPos!=numPositiveExamples || countNeg!=numNegExamples)
        {
            countNeg=0;
            countPos=0;
            for(int i=0;i<total;i++)
            {
                tot[i]=-1;
            }
            
            for(int i=0;i<total;i++)
            {
                chance=s.nextInt(2);
                
                if (chance==0)
                {
                    tot[i]=0;
                    countPos++;
                } else {
                    tot[i]=1;
                    countNeg++;
                    }
            }
        }
        InsuranceClaim f[]=new InsuranceClaim[total];
        for(int i=0;i<total;i++)
        {
            f[i]=randomClaimGenerator.generateInsuranceClaim();
            if (tot[i]==1)
            {
               randomClaimGenerator.generateFraudulentClaim(f[i]);
            }
            DataCleaning.cleanupClaim(arrClaims[i]);
        }
        PPDM.produceFileForNN(arrClaims);
        PPDM.produceInputSetForNN();
        
        return f;
    }
    public static int getMonthEndDay(int year,int month)
    {
        int a=0;
        if ((month==2)&&(((year % 4==0)  && (year % 100!=0))||(year % 400 ==0)))
        {
            return 29;
        } else 
            switch (month)
            {
                case 1: a=31;
                    break;
                case 2: a=28;
                    break;
                case 3: a=31;
                    break;
                case 4: a=30;
                    break;
                case 5: a=31;
                    break;
                case 6: a=30;
                    break;
                case 7: a=31;
                    break;
                case 8: a=31;
                    break;
                case 9: a=30;
                    break;
                case 10: a=31;
                    break;
                case 11: a=30;
                    break;
                case 12: a=30;
                    break;
            }
        
        return a;
    }
    
    public void clearClaims()
    {
    for(int i=0;i<numClaims;i++)
    {
        arrClaims[i]=null;
    }
    }
    
}
