/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package insuranceclaimgenerator;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.util.Date;
import org.jasypt.util.text.BasicTextEncryptor;

/**
 *
 * @author Warmaster
 */
public class PPDM {
    
    private static BasicTextEncryptor enc;
    public static void produceInputSetForNN() throws FileNotFoundException, IOException
    {
        System.out.println("Beginning the Process of producing Neural Network Information");
        String line;
        PrintWriter writer = new PrintWriter("nnFile.txt", "UTF-8");
         FileReader reader = new FileReader("finalFile.txt");
         BufferedReader bufferedReader =new BufferedReader(reader);

         String [] tmp=new String[9];
         String temp="";
         while((line = bufferedReader.readLine()) != null) {
             for(int r=0;r<9;r++)
             {
                 tmp[r]="";
             }
             temp="";
             tmp=line.split(":");
             
             for(int i=0;i<9;i++)
             {
                 tmp[i]=decryptString(tmp[i]);
             }
            
            //Transform Information into final numerical presentation for NN
            /*
            fields[0] = String.valueOf(claims[i].claimIndicator);
            fields[1] = claims[i].dateOfLoss;
            fields[2] = claims[i].dateOfClaim;
            fields[3] = claims[i].dateOfBirth;
            fields[4] = String.valueOf(claims[i].sumInsured);
            fields[5] = String.valueOf(claims[i].policyRevenue);
            fields[6] = String.valueOf(claims[i].amountPaid);
            fields[7] = claims[i].policyStartDate;
            fields[8] = claims[i].policyEndDate;
            fields[9] = claims[i].serviceProvider;
            */
            tmp[1]=String.valueOf(produceDateTransformation(tmp[1]));
            tmp[2]=String.valueOf(produceDateTransformation(tmp[2]));
            tmp[3]=String.valueOf(produceDateTransformation(tmp[3]));
            tmp[4]=String.valueOf(produceSumInsureNormalTransformation(tmp[4]));
            if (tmp[0].compareTo("F")==0)
            {
                tmp[5]=String.valueOf(producePolicyRevTransformation(tmp[5]));
                tmp[6]=String.valueOf(produceAmountPaidTransformation(tmp[6]));
            } else 
                {
                    tmp[5]=String.valueOf(producePolicyRevTransformation(tmp[5]));
                    tmp[6]=String.valueOf(produceAmountPaidTransformation(tmp[6]));
                }
            
            tmp[7]=String.valueOf(produceDateTransformation(tmp[7]));
            tmp[8]=String.valueOf(produceDateTransformation(tmp[8]));
            
            for (int k = 0; k < 9; k++) {
                if (k != 8) {
                     if (tmp[0].compareTo("true")==0)
                        {
                            tmp[0]="T";
                        } else tmp[0]="F";
                     
                    temp = temp+tmp[k]+",";
                } else {
                       
                    
                    temp =temp+tmp[k];
                }
            }
            
             
            writer.println(temp);
         }  
         
         writer.close();
         
         bufferedReader.close();
    }
    public static void produceFileForNN(InsuranceClaim[] claims) throws FileNotFoundException, UnsupportedEncodingException{
        
        System.out.println("Beginning the process of compiling CSV Document");
        enc=new BasicTextEncryptor();
        enc.setPassword("password");
        PrintWriter writer = new PrintWriter("rawData.csv", "UTF-8");
        PrintWriter writer2 = new PrintWriter("finalFile.txt", "UTF-8");
         

        String fields[] = new String[9];
        String excelLine = "";
        String finalLine=""; 
        
        for (int i = 0; i < claims.length; i++) {
            for (int j = 0; j < 9; j++) {
                fields[j] = "";
            }

            fields[0] = String.valueOf(claims[i].claimIndicator);
            fields[1] = claims[i].dateOfLoss;
            fields[2] = claims[i].dateOfClaim;
            fields[3] = claims[i].dateOfBirth;
            fields[4] = String.valueOf(claims[i].sumInsured);
            fields[5] = String.valueOf(claims[i].policyRevenue);
            fields[6] = String.valueOf(claims[i].amountPaid);
            fields[7] = claims[i].policyStartDate;
            fields[8] = claims[i].policyEndDate;
            
            ///Make a string to writing to file
            excelLine = "";

            for (int k = 0; k < 9; k++) {
                if (k != 8) {
                    excelLine = excelLine + fields[k] + ",";
                } else {
                    excelLine = excelLine + fields[k];
                }
            }
                
            writer.println(excelLine);
            
            ///Now, we individually encrypt each of the fields before writing to file.
            
            for(int t=0;t<9;t++)
            {
                fields[t]=encryptString(fields[t]);
            }
            
            finalLine = "";

            for (int k = 0; k < 9; k++) {
                if (k != 8) {
                    finalLine = finalLine + fields[k] + ":";
                } else {
                    finalLine = finalLine + fields[k];
                }
            }
                
            writer2.println(finalLine);
        }
        
        writer.close();
        writer2.close();
        produceDataSetCSV(claims);
    }
    public static void produceDataSetCSV(InsuranceClaim[] claims) throws FileNotFoundException, UnsupportedEncodingException
    {
        System.out.println("Beginning the process of compiling CSV Document");
        PrintWriter writer = new PrintWriter("rawFullData.csv", "UTF-8");         

        String fields[] = new String[29];
        String excelLine = "";
        
        for (int i = 0; i < claims.length; i++) {
            for (int j = 0; j < 29; j++) {
                fields[j] = "";
            }

            fields[0] = String.valueOf(claims[i].claimIndicator);
            fields[1] = claims[i].claimReason;
            fields[2] = claims[i].dateOfLoss;
            fields[3] = claims[i].dateOfClaim;
            fields[4] = claims[i].agencyID;
            fields[5] = claims[i].insuredID;
            fields[6] = claims[i].insuredName;
            fields[7] = claims[i].insuredSurname;
            fields[8] = claims[i].gender;
            fields[9] =claims[i].kindOfLoss;
            fields[10] =claims[i].policyStreet;
            fields[11] =claims[i].policyProvince;
            fields[12] =claims[i].policyCity;
            fields[13] =claims[i].policyArea;
            fields[14] =claims[i].policyPostalCode;
            fields[15] =claims[i].province;
            fields[16] =claims[i].city;
            fields[17] =claims[i].area;
            fields[18] =claims[i].postalCode;
            fields[19] =claims[i].maritalStatus;
            fields[20] =claims[i].dateOfBirth;
            fields[21] =String.valueOf(claims[i].sumInsured);
            fields[22] =String.valueOf(claims[i].policyRevenue);
            fields[23] =String.valueOf(claims[i].amountPaid);
            fields[24] =claims[i].policyStartDate;
            fields[25] =claims[i].policyEndDate;
            fields[26] =claims[i].otherName;
            fields[27] =claims[i].otherSurname;
            fields[28] =claims[i].serviceProvider;
            ///Make a string to writing to file
            excelLine = "";

            for (int k = 0; k < 29; k++) {
                if (k != 28) {
                    excelLine = excelLine + fields[k] + ":";
                } else {
                    excelLine = excelLine + fields[k];
                }
            }
                
            writer.println(excelLine);            
        }
        writer.close();
    }
   
    public static void generaliseClaim(InsuranceClaim claim) {
        claim.gender = claim.gender.substring(0, 1);
        claim.maritalStatus = claim.maritalStatus.substring(0, 1);
    }

    public static String convertClaimToString(InsuranceClaim claim) {
        ///Use the symbol | as the divider
        String finalOutput = "";

        String fields[] = new String[29];
        fields[0] = Boolean.toString(claim.claimIndicator);
        fields[1] = claim.claimReason;
        fields[2] = claim.dateOfLoss;
        fields[4] = claim.dateOfClaim;
        fields[5] = claim.agencyID;
        fields[6] = claim.insuredID;
        fields[7] = claim.insuredName;
        fields[8] = claim.insuredSurname;
        fields[9] = claim.gender;
        fields[10] = claim.kindOfLoss;
        fields[11] = claim.policyStreet;
        fields[12] = claim.policyProvince;
        fields[13] = claim.policyCity;
        fields[14] = claim.policyArea;
        fields[15] = claim.policyPostalCode;
        fields[16] = claim.province;
        fields[17] = claim.city;
        fields[18] = claim.area;
        fields[19] = claim.postalCode;
        fields[20] = claim.maritalStatus;
        fields[21] = claim.dateOfBirth;
        fields[22] = String.valueOf(claim.sumInsured);
        fields[23] = String.valueOf(claim.policyRevenue);
        fields[24] = String.valueOf(claim.amountPaid);
        fields[25] = claim.policyStartDate;
        fields[26] = claim.policyEndDate;
        fields[27] = claim.otherName;
        fields[28] = claim.otherSurname;
        fields[29] = claim.serviceProvider;

        for (int i = 0; i < 29; i++) {
            if (i != 28) {
                finalOutput = finalOutput + fields[i] + "|";
            } else {
                finalOutput = finalOutput + fields[i];
            }
        }
        return finalOutput;
    }

    public static InsuranceClaim convertStringToClaim(String claim) {
        InsuranceClaim s = new InsuranceClaim();

        String fields[] = claim.split("|");
        s.claimIndicator = Boolean.parseBoolean(fields[0]);
        s.claimReason = fields[1];
        s.dateOfLoss = fields[2];
        s.dateOfClaim = fields[4];
        s.agencyID = fields[5];
        s.insuredID = fields[6];
        s.insuredName = fields[7];
        s.insuredSurname = fields[8];
        s.gender = fields[9];
        s.kindOfLoss = fields[10];
        s.policyStreet = fields[11];
        s.policyProvince = fields[12];
        s.policyCity = fields[13];
        s.policyArea = fields[14];
        s.policyPostalCode = fields[15];
        s.province = fields[16];
        s.city = fields[17];
        s.area = fields[18];
        s.postalCode = fields[19];
        s.maritalStatus = fields[20];
        s.dateOfBirth = fields[21];
        s.sumInsured = Double.parseDouble(fields[22]);
        s.policyRevenue = Double.parseDouble(fields[23]);
        s.amountPaid = Double.parseDouble(fields[24]);
        s.policyStartDate = fields[25];
        s.policyEndDate = fields[26];
        s.otherName = fields[27];
        s.otherSurname = fields[28];
        s.serviceProvider = fields[29];

        return s;
    }

    public static String encryptString(String plainText) {
        
        
        return enc.encrypt(plainText);
    }

    public static String decryptString(String cipherText) {
        return enc.decrypt(cipherText);
    }

    public static double produceClaimTransformation(String claim) {
        double tmp = Double.parseDouble(claim);
        return tmp / 2.0;
    }

    public static double produceServiceProviderTransformation(String claim) {
        double tmp;
        if (claim.compareTo("N/A")==0)
        {
            tmp=0;
        } else
        tmp = Double.parseDouble(claim);
        
        return tmp / 2.0;
    }

    public static double produceDateTransformation(String claim) {
        int x, y, z;

        x = Integer.parseInt(claim.split("/")[0]);
        y = Integer.parseInt(claim.split("/")[1]);
        z = Integer.parseInt(claim.split("/")[2]);
        z = z - 1900;
        y = y - 1;

        Date d = new Date(z, y, x);
        BigDecimal tmp = new BigDecimal(d.getTime());

        double a;
        BigDecimal b, e;
        b = new BigDecimal(100000000000.0);
        e = tmp.divide(b);

        a = e.doubleValue();
        a = (a - 23.678784) / 40.0;

        return a;
    }

    public static double produceSumInsureNormalTransformation(String claim) {
        double val = Double.parseDouble(claim);
        val = ((val / 10000.0) - 2) / 6.0;
        return val;
    }

    public static double producePolicyRevTransformation(String claim) {
        double val = Double.parseDouble(claim);
        val = ((val / 10000.0) - 2.075) / 3.5;
        return val;
    }

    public static double producePolicyRevFraudTransformation(String claim) {
        double val = Double.parseDouble(claim);
        val = ((val / 1000.0) - 2.13) / 5.0;
        return val;
    }

    public static double produceAmountPaidTransformation(String claim) {
        double val = Double.parseDouble(claim);
        val = ((val / 10000.0) - 2.175) / 4.5;
        return val;
    }

    public static double produceAmountPaidFraudTransformation(String claim) {
        double val = Double.parseDouble(claim) / 2.0;
        val = ((val / 10000.0) - 2) / 6.0;
        return val;
    }
    
}
