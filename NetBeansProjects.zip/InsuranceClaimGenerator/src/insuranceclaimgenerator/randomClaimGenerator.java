/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package insuranceclaimgenerator;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import static java.lang.Math.round;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

/**
 *
 * @author Warmaster
 */
public class randomClaimGenerator {

    public static String names[]=new String[400];
    public static String cities[]=new String[600];
    public static String areas[]=new String[600];
    public static String surnames[]=new String[400];
    public static String streets[]=new String[400];

    public static InsuranceClaim generateInsuranceClaim() throws IOException
    {
        Random s=new Random(System.nanoTime());
        InsuranceClaim c=new InsuranceClaim();
        
        populateAreas();
        populateCities();
        populateNames();
        populateStreets();
        populateSurnames();
        
        //Claims
        c.claimIndicator=false;
        c.claimReason="Valid Claim";
        
        ///Finances
        c.sumInsured=genSumInsured();
        c.amountPaid=genAmountPaid(c.sumInsured);
        c.policyRevenue=genPolicyRevenue(c.sumInsured);
        
        ///Profile Information
        c.dateOfBirth=genDateOfBirth();
        c.policyStartDate=genStartDate(Integer.parseInt(c.dateOfBirth.split("/")[2]));
        c.policyEndDate=genEndDate(c.policyStartDate);
        c.dateOfClaim=genDateOfClaim(c.policyStartDate, c.policyEndDate);
        c.dateOfLoss=genDateOfLoss(c.dateOfClaim);
        c.kindOfLoss=genKindOfLoss();
        c.maritalStatus=genMaritalStatus();
        
        //IDS
        c.serviceProvider=genServiceProvider();
        c.agencyID=genAgencyID();
        c.insuredID=genInsuredID();
        c.insuredName=genInsuredName();
        c.insuredSurname=genInsuredSurname();
        c.otherName=genOtherName();
        c.otherSurname=genOtherSurname();
        c.gender=genGender();
        
        //Addressses
        c.policyStreet=genPolicyStreet();
        c.policyProvince=genPolicyProvince();
        c.policyCity=genPolicyCity();
        c.policyArea=genPolicyArea();
        c.policyPostalCode=genPolicyPostalCode();
        
        c.province=genProvince();
        c.city=genCity();
        c.area=genArea();
        c.postalCode=genPostalCode();
        
        
        double chance=s.nextInt(100)/100.0;
        
        if (chance<=0.55)
        {
            DataCleaning.dirtyClaim(c);
        }
        
        return c;
    }
    public static void populateNames() throws FileNotFoundException, IOException {
        //read in from file -> fill array
        BufferedReader br = null;
        FileReader fr = null;
        fr = new FileReader("names.txt");
        
        String sCurrentLine;

        br = new BufferedReader(new FileReader("names.txt"));
        int i=0;
        while ((sCurrentLine = br.readLine()) != null) {
            names[i]=sCurrentLine;
            i++;
        }
    }
    public static void populateCities() throws FileNotFoundException, IOException {
        BufferedReader br = null;
        FileReader fr = null;
        fr = new FileReader("cities.txt");
        
        String sCurrentLine;

        br = new BufferedReader(new FileReader("cities.txt"));
        int i=0;
        while ((sCurrentLine = br.readLine()) != null) {
            cities[i]=sCurrentLine;
            i++;
        }
    }

    public static void populateSurnames() throws FileNotFoundException, IOException {
        BufferedReader br = null;
        FileReader fr = null;
        fr = new FileReader("surnames.txt");
        
        String sCurrentLine;

        br = new BufferedReader(new FileReader("surnames.txt"));
        int i=0;
        while ((sCurrentLine = br.readLine()) != null) {
            surnames[i]=sCurrentLine;
            i++;
        }
    }

    public static void populateStreets() throws FileNotFoundException, IOException {
        BufferedReader br = null;
        FileReader fr = null;
        fr = new FileReader("streets.txt");
        
        String sCurrentLine;

        br = new BufferedReader(new FileReader("streets.txt"));
        int i=0;
        while ((sCurrentLine = br.readLine()) != null) {
            streets[i]=sCurrentLine;
            i++;
        }
    }

    public static void populateAreas() throws FileNotFoundException, IOException {
        BufferedReader br = null;
        FileReader fr = null;
        fr = new FileReader("cities.txt");
        
        String sCurrentLine;

        br = new BufferedReader(new FileReader("cities.txt"));
        int i=0;
        while ((sCurrentLine = br.readLine()) != null) {
            areas[i]=sCurrentLine;
            i++;
        }
    }
    public static String genDateOfClaim(String start,String end) {
        int b,c,y,z;
        int day,month,year;

        b=Integer.parseInt(start.split("/")[1]);
        c=Integer.parseInt(start.split("/")[2]);
        

        y=Integer.parseInt(end.split("/")[1]);
        z=Integer.parseInt(end.split("/")[2]);
        
        if (b==1)
        {
            y++;
            b++;
        }
        
        month=ThreadLocalRandom.current().nextInt(b, y+1);
        year=ThreadLocalRandom.current().nextInt(c, z+1);
        day=ThreadLocalRandom.current().nextInt(2,25+1);
        
        return String.valueOf(day)+"/"+String.valueOf(month)+"/"+String.valueOf(year);
    }

    public static String genDateOfLoss(String claim) {
        int a=ThreadLocalRandom.current().nextInt(7)+1;
        
        int x,y,z;
        x=Integer.parseInt(claim.split("/")[0]);
        y=Integer.parseInt(claim.split("/")[1]);
        z=Integer.parseInt(claim.split("/")[2]);
       
        if (x-a<=0)
        {
            x=(GenerationEngine.getMonthEndDay(z,y)+1)-(a-x);
            y=y-1;
        } else 
            {
                x=x-a;
            }
        
        return String.valueOf(x)+"/"+String.valueOf(y)+"/"+String.valueOf(z);
    }

    public static String genAgencyID() {
        Random s = new Random(System.nanoTime());
        String a;

        a = String.valueOf(s.nextInt(9)) + String.valueOf(s.nextInt(9)) + String.valueOf(s.nextInt(9))
                + String.valueOf(s.nextInt(9))+String.valueOf(s.nextInt(9))+String.valueOf(s.nextInt(9))+
                String.valueOf(s.nextInt(9))+String.valueOf(s.nextInt(9));

        return a;
    }

    public static String genInsuredID() {
        Random s = new Random(System.nanoTime());
        String a;

        a = String.valueOf(s.nextInt(9)) + String.valueOf(s.nextInt(9)) + String.valueOf(s.nextInt(9))
                + String.valueOf(s.nextInt(9))+String.valueOf(s.nextInt(9))+String.valueOf(s.nextInt(9))+
                String.valueOf(s.nextInt(9))+String.valueOf(s.nextInt(9));

        return a;
    }

    public static String genInsuredName() {
        Random s = new Random(System.nanoTime());
        return names[s.nextInt(names.length)];
    }

    public static String genInsuredSurname() {
        Random s = new Random(System.nanoTime());
        return surnames[s.nextInt(surnames.length)];
    }

    public static String genGender() {
        Random s = new Random(System.nanoTime());
        if (s.nextBoolean() == true) {
            return "Male";
        } else {
            return "Female";
        }
    }

    public static String genKindOfLoss() {
        String losses[]={"Personal","Property","Vehicular","Death","Theft","Business"};
        Random s=new Random(System.nanoTime());
        
        int a=s.nextInt(6);
        return losses[a];
    }

    public static String genPolicyStreet() {
        Random s = new Random(System.nanoTime());
        return streets[s.nextInt(streets.length)];
    }

    public static String genPolicyProvince() {
        Random s = new Random(System.nanoTime());
        return names[s.nextInt(names.length)];
    }

    public static String genPolicyCity() {
        Random s = new Random(System.nanoTime());
        return cities[s.nextInt(cities.length)];
    }

    public static String genPolicyArea() {
        Random s = new Random(System.nanoTime());
        return cities[s.nextInt(cities.length)];
    }

    public static String genPolicyPostalCode() {
        Random s = new Random(System.nanoTime());
        String a;

        a = String.valueOf(s.nextInt(9)) + String.valueOf(s.nextInt(9)) + String.valueOf(s.nextInt(9))
                + String.valueOf(s.nextInt(9));

        return a;

    }

    public static String genProvince() {
        Random s = new Random(System.nanoTime());
        return names[s.nextInt(names.length)];
    }

    public static String genCity() {
        Random s = new Random(System.nanoTime());
        return names[s.nextInt(names.length)];
    }

    public static String genArea() {
        Random s = new Random(System.nanoTime());
        return names[s.nextInt(names.length)];
    }

    public static String genPostalCode() {
        Random s = new Random(System.nanoTime());
        String a;

        a = String.valueOf(s.nextInt(9)) + String.valueOf(s.nextInt(9)) + String.valueOf(s.nextInt(9))
                + String.valueOf(s.nextInt(9));

        return a;
    }

    public static String genMaritalStatus() {
        Random a = new Random(System.nanoTime());
        int s = a.nextInt(2);

        if (s == 0) {
            return "Married";
        } else {
            return "Single";
        }

    }

    public static String genDateOfBirth() {
        int bound1,bound2,a,b,c;
        String output="";
        bound1=1980;
        bound2=2000;
        Random s=new Random(System.nanoTime());
        a = ThreadLocalRandom.current().nextInt(bound1, bound2+1);
        b=s.nextInt(12)+1;
        c=s.nextInt(GenerationEngine.getMonthEndDay(a, b))+1;

        output=String.valueOf(c)+"/"+String.valueOf(b)+"/"+String.valueOf(a);
        return output;
    }

    public static double genSumInsured() {
        return ThreadLocalRandom.current().nextInt(10000, 50000+1);
    }

    public static double genPolicyRevenue(double iVal) {
        
        int a=ThreadLocalRandom.current().nextInt(40, 75+1);
        double b=a/100.0;
        
        return Math.round((iVal*b)*100.0)/100.0;
    }

    public static double genAmountPaid(double iVal) {
        int a=ThreadLocalRandom.current().nextInt(10, 85+1);
        double b=a/100.0;
        
        return Math.round((iVal*b)*100.0)/100.0;
    }

    public static String genStartDate(int year) {
        //int lifeSpan=70;
        Random s=new Random(System.nanoTime());
        
        int b,c;
        int ran = ThreadLocalRandom.current().nextInt(18, 40+1);
        int a=year+ran;
        b=s.nextInt(12)+1;
        c=s.nextInt(GenerationEngine.getMonthEndDay(a, b))+1;
        
        return String.valueOf(c)+"/"+String.valueOf(b)+"/"+String.valueOf(a);
    }

    public static String genEndDate(String date) {
        int z=Integer.parseInt(date.split("/")[2]);
        z=z+50;
        int x,y;
        
        x=Integer.parseInt(date.split("/")[0]);
        y=Integer.parseInt(date.split("/")[1]);
        return String.valueOf(x)+"/"+String.valueOf(y)+"/"+String.valueOf(z);
    }

    public static String genOtherName() {
        Random s = new Random(System.nanoTime());
        return names[s.nextInt(names.length)];
    }

    public static String genOtherSurname() {
        Random s = new Random(System.nanoTime());
        return surnames[s.nextInt(surnames.length)];
    }

    public static String genServiceProvider() {
        Random s = new Random(System.nanoTime());
        String a;

        a = String.valueOf(s.nextInt(9)) + String.valueOf(s.nextInt(9)) + String.valueOf(s.nextInt(9))
                + String.valueOf(s.nextInt(9)) + String.valueOf(s.nextInt(9)) + String.valueOf(s.nextInt(9));

        return a;
    }
    
    public static void generateFraudulentClaim(InsuranceClaim claim)
    {
        //Take newly made claim
        //Roll for fraudulent type
        //Apply effect to claim. 
        //pass claim back out
        claim.claimIndicator=true;
        Random s=new Random(System.nanoTime());
        String claimReason="";
        int chance=s.nextInt(7);
        
        switch (chance)
        {
            case 0: claimReason="FF01";
                    claim.serviceProvider="N/A";
                break;
            case 1:claimReason="FF02";
                int x,y,z,c;
                
                x=Integer.parseInt(claim.dateOfClaim.split("/")[0]);
                y=Integer.parseInt(claim.dateOfClaim.split("/")[1]);
                
                c=Integer.parseInt(claim.policyEndDate.split("/")[2]);
                
                int offset=ThreadLocalRandom.current().nextInt(c+1,c+6);
           
                z=offset;
                claim.dateOfClaim=String.valueOf(x)+"/"+String.valueOf(y)+"/"+String.valueOf(z);
                
                break;
            case 2:claimReason="FF03";
                int x1,y1,z1,c1;
                
                x1=Integer.parseInt(claim.dateOfClaim.split("/")[0]);
                y1=Integer.parseInt(claim.dateOfClaim.split("/")[1]);
                
                c1=Integer.parseInt(claim.policyStartDate.split("/")[2]);
                
                int offset1=ThreadLocalRandom.current().nextInt(c1-5,(c1));
           
                z1=offset1;
                claim.dateOfClaim=String.valueOf(x1)+"/"+String.valueOf(y1)+"/"+String.valueOf(z1);
            
                break;
            case 3:claimReason="FF04";
            
                claim.kindOfLoss="N/A";
                
            
                break;
            case 4:claimReason="FF05";
                
               double tVal=2*claim.sumInsured;
               tVal=Math.round(tVal*100.0)/100.0;
               claim.amountPaid=tVal;
                break;
            case 5:claimReason="FF06";
                claim.claimReason="#####";
                break;
            case 6:claimReason="FF07";
                int bVal=ThreadLocalRandom.current().nextInt(10)+1;
                double rev=(bVal/100.0)*claim.amountPaid;
                
                claim.policyRevenue=rev;
                
                break;
                
        }
        claim.claimReason=claimReason;
        
        
    }
}
