/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author Warmaster
 */
public class Experiment1 {

    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        System.out.println("=====================================================================================");
        System.out.println("Insurance Profiling");
        System.out.println("=====================================================================================");
        
        
        String letter="T";
        
        NetworkTrainer trainer1=new NetworkTrainer();
        boolean useBatch=false;
        //trainer1.RunExperiment(16,1,1,"letter-recognition.data", 16, 1, letter, 0,useBatch);
        //trainer1.adaptiveGrowExperiment(16,1,1,"letter-recognition.data", 16, 1, letter, 0,useBatch);
        
        trainer1.performNetworkTrainingAccuracySet(10, 15, 1,"nnFile.txt", 8, 1, letter, 0, useBatch, 0.3, 0.3);
        
        double test[]=new double[8];
        
       
       
        //-0.014149800000000035,-0.014085000000000037,-0.47044980000000003,0.43624999999999997,0.25148571428571426,0.2759888888888889,-0.155997,0.2384622,61578.0 F 1
        //-0.1778562,-0.1777698,-0.48425219999999997,0.1722,-0.08154628571428571,0.08960444444444447,-0.23248260000000004,0.16199820000000004 T 0
        //-0.050588999999999995,-0.0504378,-0.47880900000000004,-0.021483333333333337,-0.3041731428571429,-0.4417533333333333,-0.18483299999999997,0.20962619999999993 1
        /*
        test[0]=-0.050588999999999995;
        test[1]=-0.0504378;
        test[2]=-0.47880900000000004;
        test[3]=-0.021483333333333337;
        test[4]=-0.3041731428571429;
        test[5]=-0.4417533333333333;
        test[6]=-0.18483299999999997;
        test[7]=0.20962619999999993;
        */
        
        test[0]=-0.1778562;
        test[1]=-0.1777698;
        test[2]=-0.48425219999999997;
        test[3]=0.1722;
        test[4]=-0.08154628571428571;
        test[5]=0.08960444444444447;
        test[6]=-0.23248260000000004;
        test[7]=0.16199820000000004;
      
        int [] check=trainer1.pokemon.feedForwardPattern(test);
        int result=check[0];
        
        System.out.println("Classification of Claim: "+result);
        /*
        check=trainer1.pokemon.feedForwardPattern(test);
        result=check[0];
        
        System.out.println("Classification of B: "+result);
        
        test[0]=2;
        test[1]=8;
        test[2]=3;
        test[3]=5;
        test[4]=1;
        test[5]=8;
        test[6]=13;
        test[7]=0;
        test[8]=6;
        test[9]=6;
        test[10]=10;
        test[11]=8;
        test[12]=0;
        test[13]=8;
        test[14]=0;
        test[15]=8;
        
        for (int x = 0; x < 16; x++) {
            test[x] = test[x] - 7.0;
            test[x] = test[x] / 16.0;
        }
       
        check=trainer1.pokemon.feedForwardPattern(test);
        result=check[0];
        
        System.out.println("Classification of T: "+result);
        
        test[0]=1;
        test[1]=1;
        test[2]=3;
        test[3]=2;
        test[4]=1;
        test[5]=8;
        test[6]=2;
        test[7]=2;
        test[8]=2;
        test[9]=8;
        test[10]=2;
        test[11]=8;
        test[12]=1;
        test[13]=6;
        test[14]=2;
        test[15]=7;
        
        for (int x = 0; x < 16; x++) {
            test[x] = test[x] - 7.0;
            test[x] = test[x] / 16.0;
        }
       
        check=trainer1.pokemon.feedForwardPattern(test);
        result=check[0];
        
        System.out.println("Classification of A: "+result);
        
        test[0]=8;
        test[1]=12;
        test[2]=8;
        test[3]=6;
        test[4]=4;
        test[5]=3;
        test[6]=10;
        test[7]=4;
        test[8]=7;
        test[9]=12;
        test[10]=11;
        test[11]=9;
        test[12]=3;
        test[13]=7;
        test[14]=3;
        test[15]=4;
        
        for (int x = 0; x < 16; x++) {
            test[x] = test[x] - 7.0;
            test[x] = test[x] / 16.0;
        }
       
        check=trainer1.pokemon.feedForwardPattern(test);
        result=check[0];
        
        System.out.println("Classification of X: "+result);
        
        test[0]=3;
        test[1]=8;
        test[2]=5;
        test[3]=6;
        test[4]=3;
        test[5]=9;
        test[6]=2;
        test[7]=2;
        test[8]=3;
        test[9]=8;
        test[10]=2;
        test[11]=8;
        test[12]=2;
        test[13]=6;
        test[14]=3;
        test[15]=7;
        
        for (int x = 0; x < 16; x++) {
            test[x] = test[x] - 7.0;
            test[x] = test[x] / 16.0;
        }
       
        check=trainer1.pokemon.feedForwardPattern(test);
        result=check[0];
        
        System.out.println("Classification of A: "+result);
*/
    }
    
}
