/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

/**
 *
 * @author Warmaster
 */
public class NetworkTrainer {

    NeuralNetwork pokemon;
    Long epochCount;

    NetworkTrainer() {
        pokemon = new NeuralNetwork();
    }

    void RunExperiment(int inInput, int inHidden, int inOutput, String fn, int inputs, int targets, String search, int experiment, boolean batch) throws IOException {
        DataReader dataInput = new DataReader();

        int hiddenUnits = inHidden;
        int i = 0;
        int logNumber = 0;

        double learningRate = pokemon.LEARNING_RATE_DEFAULT;
        double momentum = pokemon.MOMENTUM;

        dataInput.loadFileExperiment(fn, inputs, targets, search, experiment);
        double[] baselines = new double[3];
        dataInput.reshuffleAndGenerateSets();
        System.out.println("Determining Variable Baseline Values");
        baselines = detBaselines(inInput, inHidden, inOutput, fn, inputs, targets, search, experiment, batch, dataInput.trainingSet, dataInput.generalisationSet, dataInput.validationSet);

        //Base Line Values have now been established.
        double left, right, current;
        if (pokemon != null) {
            pokemon = null;
        }
        pokemon = new NeuralNetwork(16, (int) baselines[0], inOutput, batch, baselines[1], baselines[2]);
        dataInput.reshuffleAndGenerateSets();
        trainNetwork(dataInput.trainingSet, dataInput.generalisationSet, dataInput.validationSet, logNumber, experiment + 1);

        current = pokemon.getValidationSetMeanSqError();
        pokemon = null;
        if ((int) baselines[0] > 1) {
            pokemon = new NeuralNetwork(16, (int) baselines[0] - 1, inOutput, batch, baselines[1] - 0.03, baselines[2] - 0.03);
        } else {
            pokemon = new NeuralNetwork(16, (int) baselines[0], inOutput, batch, baselines[1] - 0.03, baselines[2] - 0.03);
        }
        pokemon.resetNetwork();
        trainNetwork(dataInput.trainingSet, dataInput.generalisationSet, dataInput.validationSet, logNumber, experiment + 1);
        left = pokemon.getValidationSetMeanSqError();

        System.out.println("Determining Left Value");

        pokemon = null;
        pokemon = new NeuralNetwork(16, (int) baselines[0] + 1, inOutput, batch, baselines[1] + 0.03, baselines[2] + 0.03);
        pokemon.resetNetwork();
        trainNetwork(dataInput.trainingSet, dataInput.generalisationSet, dataInput.validationSet, logNumber, experiment + 1);
        right = pokemon.getValidationSetMeanSqError();

        System.out.println("Determining Right Value");
        double tmpHU, tmpLR, tmpMom;

        tmpHU = baselines[0];
        tmpLR = baselines[1];
        tmpMom = baselines[2];

        System.out.println("Commencing Hill Climbing Procedure");
        if (left < current || right < current) {

            if (left < right) {
                while (left < current && (tmpHU >= 1.0 && tmpLR >= 0.01 && tmpMom >= 0.01)) {
                    current = left;
                    pokemon = null;

                    tmpHU = tmpHU - 1;
                    tmpLR = tmpLR - 0.03;
                    tmpMom = tmpMom - 0.03;

                    pokemon = new NeuralNetwork(16, (int) tmpHU, inOutput, batch, tmpLR, tmpMom);
                    pokemon.resetNetwork();
                    trainNetwork(dataInput.trainingSet, dataInput.generalisationSet, dataInput.validationSet, logNumber, experiment);
                    left = pokemon.getValidationSetMeanSqError();
                }

                tmpHU = tmpHU + 1;
                tmpLR = tmpLR + 0.03;
                tmpMom = tmpMom + 0.03;
            } else {
                while (right < current && (tmpLR <= 1.0 && tmpMom <= 1.0)) {
                    current = right;
                    pokemon = null;

                    tmpHU = tmpHU + 1;
                    tmpLR = tmpLR + 0.03;
                    tmpMom = tmpMom + 0.03;

                    pokemon = new NeuralNetwork(16, (int) tmpHU, inOutput, batch, tmpLR, tmpMom);
                    pokemon.resetNetwork();
                    trainNetwork(dataInput.trainingSet, dataInput.generalisationSet, dataInput.validationSet, logNumber, experiment);
                    right = pokemon.getValidationSetMeanSqError();
                }

                tmpHU = tmpHU - 1;
                tmpLR = tmpLR - 0.03;
                tmpMom = tmpMom - 0.03;
            }
        }

        pokemon = null;

        System.out.println("Hill Climbing Complete");
        System.out.println("Performing 30 Tests on Finalised Values");

        pokemon = new NeuralNetwork(16, (int) tmpHU, inOutput, batch, tmpLR, tmpMom);
        while (i < 30) {

            if (pokemon != null) {
                pokemon = null;
            }

            pokemon = new NeuralNetwork(16, (int) tmpHU, inOutput, batch, tmpLR, tmpMom);

            trainNetworkFinal(dataInput.trainingSet, dataInput.generalisationSet, dataInput.validationSet, i, 1);
            pokemon.resetNetwork();
            i++;
        }
        System.out.println("Tests Complete");
    }

    void adaptiveGrowExperiment(int inInput, int inHidden, int inOutput, String fn, int inputs, int targets, String search, int experiment, boolean batch) throws IOException {
        DataReader dataInput = new DataReader();
        double learningRate = pokemon.LEARNING_RATE_DEFAULT;
        double momentum = pokemon.MOMENTUM;

        double aLR = learningRate, aMom = momentum, aHU = inHidden;

        pokemon = new NeuralNetwork(16, (int) inHidden, inOutput, batch, aLR, aMom);
        int hiddenUnits = inHidden;
        int i = 0;

        dataInput.loadFileExperiment(fn, inputs, targets, search, experiment);

        System.out.println("Loading File");
        dataInput.reshuffleAndGenerateSets();
        System.out.println("Generating Training,Generalisation and Validation Sets");
        System.out.println("Starting Training");

        File dataFile = new File("Experiment Report0.txt");

        FileWriter fdw = new FileWriter(dataFile.getCanonicalFile());
        BufferedWriter brd = new BufferedWriter(fdw);
        dataFile.createNewFile();

        File dataFileRaw = new File("Experiment_Data.txt");

        FileWriter fdw2 = new FileWriter(dataFileRaw.getCanonicalFile());
        BufferedWriter brd2 = new BufferedWriter(fdw2);
        dataFileRaw.createNewFile();

        brd.write("NEURAL NETWORK TRAINING SESSION");
        brd.newLine();
        brd.write("==========================================================================");
        brd.newLine();

        trainNetworkFinal(dataInput.trainingSet, dataInput.generalisationSet, dataInput.validationSet, i + 1, 1);

        brd.write(String.format("%-24s %-13s %-14s %-9s %-21s %-23s %-23s %-29s %-21s", "Training Session Number", "Hidden Units", "Learning Rate", "Momentum", "Final Training Error", "Final Validation Error",
                "Average Training Error", "Average Generalisation Accuracy", "Validation Error \n"));
        brd.newLine();

        brd.write(String.format("%-24s %-13s %-14s %-9s %-21s %-23s %-23s %-29s %-21s", String.valueOf(i + 1), String.valueOf(pokemon.getHiddenN()), String.valueOf(pokemon.getLearningRate()), String.valueOf(pokemon.getMomentum()), String.valueOf(pokemon.getTrainingSetAccuracy()), String.valueOf(pokemon.getValidationSetAccuracy()),
                pokemon.getTrainingSetAverage(), pokemon.getGenSetAverage(), String.valueOf(pokemon.validationSetMeanSqError) + " \n"));
        brd.newLine();

        brd2.write(String.format("%s %s %s %s %s %s %s %s %s", String.valueOf(i + 1), String.valueOf(aHU), String.valueOf(aLR), String.valueOf(aMom), String.valueOf(pokemon.getTrainingSetAccuracy()), String.valueOf(pokemon.getValidationSetAccuracy()),
                pokemon.getTrainingSetAverage(), pokemon.getGenSetAverage(), String.valueOf(pokemon.validationSetMeanSqError) + " \n"));

        dataInput.reshuffleAndGenerateSets();

        i++;

        double priorMSE = 0.0, currentMSE = 0.0;
        double percentDiff = 0.0;
        priorMSE = pokemon.getValidationSetMeanSqError();
        currentMSE = pokemon.getValidationSetMeanSqError();

        while (i < 30) {

            if (pokemon != null) {
                pokemon = null;
            }

            pokemon = new NeuralNetwork(16, (int) aHU, inOutput, batch, aLR, aMom);

            trainNetworkFinal(dataInput.trainingSet, dataInput.generalisationSet, dataInput.validationSet, i + 1, 1);
            priorMSE = currentMSE;
            currentMSE = pokemon.getValidationSetMeanSqError();
            /*
            Growing Strategy
             */
            percentDiff = Math.abs(currentMSE - priorMSE);

            if (currentMSE < priorMSE) {

                /*
                aHU++;
                aLR = aLR + (percentDiff * aLR);
                aMom = aMom + (percentDiff * aMom);
                 */
                aHU++;
                aLR = aLR + 0.01;
                aMom = aMom + 0.03;
            } else {
                /*
                aHU--;
                if (aHU<1) aHU=1;
                aLR = aLR - (percentDiff * aLR);
                aMom = aMom - (percentDiff * aMom);
                 */

                aHU--;
                if (aHU < 1) {
                    aHU = 1;
                }
                aLR = aLR - 0.005;
                aMom = aMom - 0.015;

            }
            brd.write(String.format("%-24s %-13s %-14s %-9s %-21s %-23s %-23s %-29s %-21s", String.valueOf(i + 1), String.valueOf(aHU), String.valueOf(aLR), String.valueOf(aMom), String.valueOf(pokemon.getTrainingSetAccuracy()), String.valueOf(pokemon.getValidationSetAccuracy()),
                    pokemon.getTrainingSetAverage(), pokemon.getGenSetAverage(), String.valueOf(pokemon.validationSetMeanSqError) + " \n"));
            brd.newLine();
            brd2.write(String.format("%s %s %s %s %s %s %s %s %s", String.valueOf(i + 1), String.valueOf(aHU), String.valueOf(aLR), String.valueOf(aMom), String.valueOf(pokemon.getTrainingSetAccuracy()), String.valueOf(pokemon.getValidationSetAccuracy()),
                    pokemon.getTrainingSetAverage(), pokemon.getGenSetAverage(), String.valueOf(pokemon.validationSetMeanSqError) + " \n"));
            pokemon.resetNetwork();
            dataInput.reshuffleAndGenerateSets();
            i++;
        }
        brd2.close();
        brd.close();
        System.out.println("Training Done");
    }

    public double[] detBaselines(int inInput, int inHidden, int inOutput, String fn, int inputs, int targets, String search, int experiment, boolean batch, ArrayList<DataRecord> trainingSet, ArrayList<DataRecord> generalisationSet, ArrayList<DataRecord> validationSet) throws IOException {

        int hiddenUnits = inHidden;
        int i = 0;
        double learningRate = pokemon.LEARNING_RATE_DEFAULT;
        double momentum = pokemon.MOMENTUM;

        double hiddenBaseline, learningBaseline, momentumBaseline;
        double[][] baseHiddenData = new double[30][2];
        double[][] baseLRData = new double[30][2];
        double[][] baseMomData = new double[30][2];
        //Hidden Unit Baseline Test
        while (i < 30) {

            if (pokemon != null) {
                pokemon = null;
            }

            pokemon = new NeuralNetwork(16, hiddenUnits, inOutput, batch, learningRate, momentum);

            trainBaseline(trainingSet, generalisationSet, validationSet);
            baseHiddenData[i][0] = hiddenUnits;
            baseHiddenData[i][1] = pokemon.getValidationSetMeanSqError();
            pokemon.resetNetwork();
            i++;
            hiddenUnits = hiddenUnits + 1;

        }

        //Hidden Unit Baseline Test
        learningRate = pokemon.LEARNING_RATE_DEFAULT;
        momentum = pokemon.MOMENTUM;
        hiddenUnits = 1;
        i = 0;
        while (i < 30) {

            if (pokemon != null) {
                pokemon = null;
            }

            pokemon = new NeuralNetwork(16, hiddenUnits, inOutput, batch, learningRate, momentum);

            trainBaseline(trainingSet, generalisationSet, validationSet);
            baseMomData[i][0] = momentum;
            baseMomData[i][1] = pokemon.getValidationSetMeanSqError();
            pokemon.resetNetwork();
            i++;
            momentum = momentum + 0.03;
        }

        learningRate = pokemon.LEARNING_RATE_DEFAULT;
        momentum = pokemon.MOMENTUM;
        hiddenUnits = 1;
        i = 0;
        while (i < 30) {

            if (pokemon != null) {
                pokemon = null;
            }

            pokemon = new NeuralNetwork(16, hiddenUnits, inOutput, batch, learningRate, momentum);

            trainBaseline(trainingSet, generalisationSet, validationSet);
            baseLRData[i][0] = learningRate;
            baseLRData[i][1] = pokemon.getValidationSetMeanSqError();
            pokemon.resetNetwork();
            i++;
            learningRate = learningRate + 0.03;
        }

        hiddenBaseline = baseHiddenData[0][1];
        momentumBaseline = baseMomData[0][1];
        learningBaseline = baseLRData[0][1];

        double hiddenBase = 1, learningBase = 0.01, momBase = 0.01;

        for (int x = 0; x < 30; x++) {
            if (baseHiddenData[x][1] < hiddenBaseline && baseHiddenData[x][1] > 0) {
                hiddenBaseline = baseHiddenData[x][1];
                hiddenBase = baseHiddenData[x][0];
            }
            if (baseMomData[x][1] < momentumBaseline && baseMomData[x][1] > 0) {
                momentumBaseline = baseMomData[x][1];
                momBase = baseMomData[x][0];
            }
            if (baseLRData[x][1] < learningBaseline && baseLRData[x][1] > 0) {
                learningBaseline = baseLRData[x][1];
                learningBase = baseLRData[x][0];
            }
        }
        double[] results = new double[3];

        results[0] = hiddenBase;
        results[1] = learningBase;
        results[2] = momBase;

        return results;
    }

    void trainNetworkFinal(ArrayList<DataRecord> trainingSet, ArrayList<DataRecord> generalisationSet, ArrayList<DataRecord> validationSet, int logNum, int experiment) throws IOException {
        String reportData;
        double averageMSE = 0;
        double stdDevMSE = 0;

        ArrayList<DataPoint> values = new ArrayList<>();
        ArrayList<Double> listDoublesMSE = new ArrayList<>();
        ArrayList<Double> trainingSetAverage = new ArrayList<>();
        ArrayList<Double> generalisationSetAverage = new ArrayList<>();

        File dataFile = new File("DataFile" + logNum + ".txt");

        String header;
        FileWriter fdw = new FileWriter(dataFile.getCanonicalFile());
        BufferedWriter brd = new BufferedWriter(fdw);

        header = "Test: " + logNum;
        dataFile.createNewFile();
        brd.write(header);
        brd.newLine();

        brd.write(String.format("%-6s %-22s %-27s", "Epoch", "Training Set Accuracy", "Generalisation Set Accuracy \n"));
        brd.newLine();
        System.out.println("NEURAL NETWORK TRAINING SESSION");
        System.out.println("==========================================================================");
        System.out.println("Network Paramaters");
        System.out.println("Learning Rate: " + pokemon.getLearningRate());
        System.out.println("Momentum: " + pokemon.getMomentum());
        System.out.println("Max Epochs: " + pokemon.getMaxEpochs());
        System.out.println("Input Neuron Count: " + pokemon.getInN());
        System.out.println("Hidden Neuron Count: " + pokemon.getHiddenN());
        System.out.println("Output Neuron Count: " + pokemon.getOutN());
        System.out.println("==========================================================================");

        pokemon.setEpoch(0);

        double priorTAcc = -1, priorGAcc = -1;
        int repetitions = 0;

        while ((repetitions < 500) && (pokemon.getSetMeanSqError(generalisationSet) > pokemon.getDesiredMSEAccuracy() || pokemon.getTrainingsetMeanSqError() > pokemon.getDesiredMSEAccuracy()) && (pokemon.getTrainingSetAccuracy() < pokemon.getDesiredAccuracy() || pokemon.getGeneralisationSetAccuracy() < pokemon.getDesiredAccuracy()) && pokemon.getEpoch() < pokemon.getMaxEpochs()) {

            if ((pokemon.getTrainingSetAccuracy() == priorTAcc) && (pokemon.getGeneralisationSetAccuracy() == priorGAcc)) {
                repetitions++;
            } else {
                repetitions = 0;
            }

            priorTAcc = pokemon.getTrainingSetAccuracy();
            priorGAcc = pokemon.getGeneralisationSetAccuracy();

            if ((pokemon.getSetMeanSqError(validationSet) > (averageMSE + stdDevMSE)) && (averageMSE + stdDevMSE != 0)) {
                break;
            } else {
                listDoublesMSE.add((pokemon.getSetMeanSqError(validationSet)));

                double tD = 0;

                for (int i = 0; i < listDoublesMSE.size(); i++) {
                    tD = tD + listDoublesMSE.get(i);
                }
                averageMSE = tD / listDoublesMSE.size();

                double stdTemp = 0;

                for (int i = 0; i < listDoublesMSE.size(); i++) {
                    stdTemp = stdTemp + Math.pow((listDoublesMSE.get(i) - averageMSE), 2);
                }
                stdTemp = stdTemp / listDoublesMSE.size();

                stdDevMSE = Math.sqrt(stdTemp);
            }
            values.add(new DataPoint(pokemon.getEpoch(), pokemon.getTrainingSetAccuracy()));

            double priorTrainingAcc = pokemon.getTrainingSetAccuracy();
            double priorGenAcc = pokemon.getGeneralisationSetAccuracy();

            trainingSetAverage.add(pokemon.getTrainingSetAccuracy());
            generalisationSetAverage.add(pokemon.getGeneralisationSetAccuracy());
            pokemon.runEpoch(trainingSet);

            pokemon.setGeneralisationSetAccuracy(pokemon.getSetAccuracy(generalisationSet));
            pokemon.setGeneralisationSetMeanSqError(pokemon.getSetMeanSqError(generalisationSet));

            reportData = Long.toString(pokemon.getEpoch()) + '\t' + Double.toString(pokemon.getTrainingSetAccuracy()) + '\t' + Double.toString(pokemon.getGeneralisationSetAccuracy());
            brd.write(String.format("%-6s %-22s %-27s", Long.toString(pokemon.getEpoch()), Double.toString(pokemon.getTrainingSetAccuracy()), Double.toString(pokemon.getGeneralisationSetAccuracy()) + " \n"));
            brd.newLine();

            pokemon.setEpoch(pokemon.getEpoch() + 1);

        }
        brd.close();
        pokemon.setValidationSetAccuracy(pokemon.getSetAccuracy(validationSet));
        pokemon.setValidationSetMeanSqError(pokemon.getSetMeanSqError(validationSet));
        double tmp = 0;
        for (int u = 0; u < trainingSetAverage.size(); u++) {
            tmp = tmp + trainingSetAverage.get(u);
        }
        pokemon.setAverageTrainingSetAccuracy(tmp / trainingSetAverage.size());
        tmp = 0;
        for (int u = 0; u < generalisationSetAverage.size(); u++) {
            tmp = tmp + generalisationSetAverage.get(u);
        }
        String[][] graph = new String[values.size()][100];
        System.out.println(" ");

        File learningProFile = new File("LearningProfile.txt");

        FileWriter lfd = new FileWriter(learningProFile.getCanonicalFile());
        BufferedWriter brl = new BufferedWriter(lfd);
        learningProFile.createNewFile();

        for (int u = 0; u < values.size(); u++) {
            brl.write(String.format("%s %s", String.valueOf(values.get(u).getE()), String.valueOf(values.get(u).getA())));
            brl.newLine();
        }

        brl.close();

        System.out.println("=======================================================================================================================================");
        for (int q = 0; q < values.size(); q++) {
            for (int u = 0; u < 100; u++) {
                graph[q][u] = "_";
            }
        }
        for (int y = 0; y < values.size(); y++) {
            graph[y][(int) values.get(y).getA()] = "#";
        }

        for (int i = 99; i >= 0; i--) {
            System.out.print(String.format("%-5s", String.valueOf(i) + " "));
            for (int e = 0; e < 100; e++) {
                System.out.print(String.format("%-5s", graph[e][i] + " "));
            }
            System.out.println("");
        }
        for (int e = 0; e < 100; e++) {
            System.out.print(String.format("%-5s", e + " "));
        }
        System.out.println(" ");

        System.out.println("=======================================================================================================================================");
        System.out.println(" ");

        pokemon.setAverageGeneralisationSetAccuracy(tmp / generalisationSetAverage.size());
        System.out.println("");
        System.out.println("");
        System.out.println("==========================================================================");
        System.out.println("Training Complete");
        System.out.println("Validation Set Accuracy:" + pokemon.getValidationSetAccuracy());
        System.out.println("Validation Set Mean Square Error:" + pokemon.getValidationSetMeanSqError());
    }

    void trainBaseline(ArrayList<DataRecord> trainingSet, ArrayList<DataRecord> generalisationSet, ArrayList<DataRecord> validationSet) throws IOException {
        double averageMSE = 0;
        double stdDevMSE = 0;

        ArrayList<Double> listDoublesMSE = new ArrayList<>();

        pokemon.setEpoch(0);

        double priorTAcc = -1, priorGAcc = -1;
        int repetitions = 0;

        while ((repetitions < 100) && (pokemon.getSetMeanSqError(validationSet) > pokemon.getDesiredMSEAccuracy() || pokemon.getTrainingsetMeanSqError() > pokemon.getDesiredMSEAccuracy()) && (pokemon.getTrainingSetAccuracy() < pokemon.getDesiredAccuracy() || pokemon.getGeneralisationSetAccuracy() < pokemon.getDesiredAccuracy()) && pokemon.getEpoch() < pokemon.getMaxEpochs()) {

            if ((pokemon.getTrainingSetAccuracy() == priorTAcc) && (pokemon.getGeneralisationSetAccuracy() == priorGAcc)) {
                repetitions++;
            } else {
                repetitions = 0;
            }

            priorTAcc = pokemon.getTrainingSetAccuracy();
            priorGAcc = pokemon.getGeneralisationSetAccuracy();

            if ((pokemon.getSetMeanSqError(validationSet) > (averageMSE + stdDevMSE)) && (averageMSE + stdDevMSE != 0)) {
                break;
            } else {
                listDoublesMSE.add((pokemon.getSetMeanSqError(validationSet)));

                double tD = 0;

                for (int i = 0; i < listDoublesMSE.size(); i++) {
                    tD = tD + listDoublesMSE.get(i);
                }
                averageMSE = tD / listDoublesMSE.size();

                double stdTemp = 0;

                for (int i = 0; i < listDoublesMSE.size(); i++) {
                    stdTemp = stdTemp + Math.pow((listDoublesMSE.get(i) - averageMSE), 2);
                }
                stdTemp = stdTemp / listDoublesMSE.size();

                stdDevMSE = Math.sqrt(stdTemp);
            }

            double priorTrainingAcc = pokemon.getTrainingSetAccuracy();
            double priorGenAcc = pokemon.getGeneralisationSetAccuracy();

            pokemon.runEpoch(trainingSet);

            pokemon.setGeneralisationSetAccuracy(pokemon.getSetAccuracy(generalisationSet));
            pokemon.setGeneralisationSetMeanSqError(pokemon.getSetMeanSqError(generalisationSet));

            pokemon.setEpoch(pokemon.getEpoch() + 1);
        }

        pokemon.setValidationSetAccuracy(pokemon.getSetAccuracy(validationSet));
        pokemon.setValidationSetMeanSqError(pokemon.getSetMeanSqError(validationSet));
    }

    void trainNetwork(ArrayList<DataRecord> trainingSet, ArrayList<DataRecord> generalisationSet, ArrayList<DataRecord> validationSet, int logNum, int experiment) throws IOException {
        String reportData;
        double averageMSE = 0;
        double stdDevMSE = 0;

        ArrayList<Double> listDoublesMSE = new ArrayList<>();
        ArrayList<Double> trainingSetAverage = new ArrayList<>();
        ArrayList<Double> generalisationSetAverage = new ArrayList<>();
//header = "Epoch" + '\t' + "Training Set Accuracy" + '\t' + "Generalisation Set Accuracy";
        
        System.out.println("NEURAL NETWORK TRAINING SESSION");
        System.out.println("==========================================================================");
        System.out.println("Network Paramaters");
        System.out.println("Learning Rate: " + pokemon.getLearningRate());
        System.out.println("Momentum: " + pokemon.getMomentum());
        System.out.println("Max Epochs: " + pokemon.getMaxEpochs());
        System.out.println("Input Neuron Count: " + pokemon.getInN());
        System.out.println("Hidden Neuron Count: " + pokemon.getHiddenN());
        System.out.println("Output Neuron Count: " + pokemon.getOutN());
        System.out.println("==========================================================================");

        pokemon.setEpoch(0);

        double priorTAcc = -1, priorGAcc = -1;
        int repetitions = 0;

        while ((repetitions < 500) && (pokemon.getSetMeanSqError(validationSet) > pokemon.getDesiredMSEAccuracy() || pokemon.getTrainingsetMeanSqError() > pokemon.getDesiredMSEAccuracy()) && (pokemon.getTrainingSetAccuracy() < pokemon.getDesiredAccuracy() || pokemon.getGeneralisationSetAccuracy() < pokemon.getDesiredAccuracy()) && pokemon.getEpoch() < pokemon.getMaxEpochs()) {

            if ((pokemon.getTrainingSetAccuracy() == priorTAcc) && (pokemon.getGeneralisationSetAccuracy() == priorGAcc)) {
                repetitions++;
            } else {
                repetitions = 0;
            }

            priorTAcc = pokemon.getTrainingSetAccuracy();
            priorGAcc = pokemon.getGeneralisationSetAccuracy();

            if ((pokemon.getSetMeanSqError(validationSet) > (averageMSE + stdDevMSE)) && (averageMSE + stdDevMSE != 0)) {
                break;
            } else {
                listDoublesMSE.add((pokemon.getSetMeanSqError(validationSet)));

                double tD = 0;

                for (int i = 0; i < listDoublesMSE.size(); i++) {
                    tD = tD + listDoublesMSE.get(i);
                }
                averageMSE = tD / listDoublesMSE.size();

                double stdTemp = 0;

                for (int i = 0; i < listDoublesMSE.size(); i++) {
                    stdTemp = stdTemp + Math.pow((listDoublesMSE.get(i) - averageMSE), 2);
                }
                stdTemp = stdTemp / listDoublesMSE.size();

                stdDevMSE = Math.sqrt(stdTemp);
            }

            String heading = "Epoch" + '\t' + "Training Set Accuracy" + '\t' + "Generalisation Set Accuracy";

            double priorTrainingAcc = pokemon.getTrainingSetAccuracy();
            double priorGenAcc = pokemon.getGeneralisationSetAccuracy();

            pokemon.runEpoch(trainingSet);

            
            pokemon.setGeneralisationSetAccuracy(pokemon.getSetAccuracy(generalisationSet));
            pokemon.setGeneralisationSetMeanSqError(pokemon.getSetMeanSqError(generalisationSet));

            trainingSetAverage.add(pokemon.getTrainingSetAccuracy());
            generalisationSetAverage.add(pokemon.getGeneralisationSetAccuracy());
            
            reportData = Long.toString(pokemon.getEpoch()) + '\t' + Double.toString(pokemon.getTrainingSetAccuracy()) + '\t' + Double.toString(pokemon.getGeneralisationSetAccuracy());
            if (Math.ceil(priorTrainingAcc) != Math.ceil(pokemon.getTrainingSetAccuracy()) || Math.ceil(priorGenAcc) != Math.ceil(pokemon.getGeneralisationSetAccuracy())) {
                System.out.println("Epoch: " + pokemon.getEpoch());
                System.out.println("Training Set Accuracy: " + pokemon.getTrainingSetAccuracy());
                System.out.println("Training Set Mean Square Error: " + pokemon.getTrainingsetMeanSqError());
                System.out.println("Generalisation Set Accuracy: " + pokemon.getGeneralisationSetAccuracy());
                System.out.println("Generalisation Set Mean Square Error: " + pokemon.getGeneralisationSetMeanSqError());
            }

            pokemon.setEpoch(pokemon.getEpoch() + 1);
            double tmp = 0;
            for (int u = 0; u < trainingSetAverage.size(); u++) {
                tmp = tmp + trainingSetAverage.get(u);
            }
            pokemon.setAverageTrainingSetAccuracy(tmp / trainingSetAverage.size());
        }

        double tmp = 0;
        for (int u = 0; u < generalisationSetAverage.size(); u++) {
            tmp = tmp + generalisationSetAverage.get(u);
        }
        pokemon.setAverageGeneralisationSetAccuracy(tmp / generalisationSetAverage.size());
        pokemon.setValidationSetAccuracy(pokemon.getSetAccuracy(validationSet));
        pokemon.setValidationSetMeanSqError(pokemon.getSetMeanSqError(validationSet));
        System.out.println("");
        System.out.println("");
        System.out.println("==========================================================================");
        System.out.println("Training Complete");
        System.out.println("Validation Set Accuracy:" + pokemon.getValidationSetAccuracy());
        System.out.println("Validation Set Mean Square Error:" + pokemon.getValidationSetMeanSqError());

    }

    void performNetworkTrainingAccuracySet(int inInput, int inHidden, int inOutput, String fn, int inputs, int targets, String search, int experiment, boolean batch, double learning, double mom) throws IOException {
        DataReader dataInput = new DataReader();

        int hiddenUnits = inHidden;
        int i = 0;
        int logNumber = 0;

        double learningRate = learning;
        double momentum = mom;

        dataInput.loadFileExperiment(fn, inputs, targets, "T", experiment);
        pokemon = null;
        System.out.println("Performing 30 Tests on Finalised Values");

        pokemon = new NeuralNetwork(8, (int) hiddenUnits, inOutput, batch, learningRate, momentum);

        dataInput.reshuffleAndGenerateSets();
        while (i < 1) {

            File dataFile = new File("DataFile" + i + ".txt");

            String header;
            FileWriter fdw = new FileWriter(dataFile.getCanonicalFile());
            BufferedWriter brd = new BufferedWriter(fdw);

            header = "Test: " + i;
            dataFile.createNewFile();
            brd.write(header);
            brd.newLine();

            dataInput.reshuffleAndGenerateSets();
            if (pokemon != null) {
                pokemon = null;
            }

            pokemon = new NeuralNetwork(8, (int) hiddenUnits, inOutput, batch, learningRate, momentum);

            trainNetwork(dataInput.trainingSet, dataInput.generalisationSet, dataInput.validationSet, i, experiment);
            brd.write(String.format("%s %s %s %s %s", pokemon.getTrainingSetAccuracy(), pokemon.getValidationSetAccuracy(), pokemon.getTrainingSetAverage(), pokemon.getGenSetAverage(), pokemon.getValidationSetMeanSqError()));
            brd.newLine();
            brd.close();
            pokemon.resetNetwork();
            i++;

        }
        System.out.println("Tests Complete");
    }
}
