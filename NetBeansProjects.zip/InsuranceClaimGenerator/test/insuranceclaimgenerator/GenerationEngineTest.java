/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package insuranceclaimgenerator;

import java.io.IOException;
import java.util.Date;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Warmaster
 */
public class GenerationEngineTest {
    
    public GenerationEngineTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }
    
    
    @Test
    public void testDataDirty() throws IOException {
        System.out.println("Dirty Data");
        InsuranceClaim test[]=new InsuranceClaim[100];

        for (int i=0;i<100;i++)
        {
            test[i]=randomClaimGenerator.generateInsuranceClaim();
            System.out.println();
            //DataCleaning.dirtyClaim(test[i]);
            System.out.println();
            DataCleaning.cleanupClaim(test[i]);
            System.out.println();
        }
        
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
    @Test
    public void testPurgeString() throws IOException {
        System.out.println("purge string");
        DataCleaning instance = new DataCleaning();
        
        String a="#af#sfa#";
        a=DataCleaning.purgeString(a, "#");
        System.out.println(a);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
    /**
     * Test of generateFullClaims method, of class GenerationEngine.
     * @throws java.io.IOException
     */
    @Test
    public void testGenerateFullClaims() throws IOException {
        System.out.println("generateFullClaims");
        GenerationEngine instance = new GenerationEngine();
        InsuranceClaim[] expResult = null;
        InsuranceClaim[] result = instance.generateFullClaims();
        assertNotEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of generateTrainingData method, of class GenerationEngine.
     */
    @Test
    public void testGenerateTrainingData() throws IOException {
        System.out.println("generateTrainingData");
        int numPositiveExamples = 20;
        int numNegExamples = 4;
        GenerationEngine instance = new GenerationEngine();
        InsuranceClaim[] expResult = null;
        InsuranceClaim[] result = instance.generateTrainingData(numPositiveExamples, numNegExamples);
        assertNotEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getMonthEndDay method, of class GenerationEngine.
     */
    @Test
    public void testGetMonthEndDay() {
        System.out.println("getMonthEndDay");
        int year = 2012;
        int month = 4;
        GenerationEngine instance = new GenerationEngine();
        int expResult = 30;
        int result = instance.getMonthEndDay( year, month);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
      //  fail("The test case is a prototype.");
    }
    
    @Test
    public void testPopulateNames() throws IOException {
        System.out.println("Populate Names");
        randomClaimGenerator instance = new randomClaimGenerator();
        int expResult = 30;
        InsuranceClaim a[];
        instance.populateNames();
        System.out.println("");
        // TODO review the generated test code and remove the default call to fail.
      //  fail("The test case is a prototype.");
    }
    @Test
    public void testDate() throws IOException {
        System.out.println("Date Check");
        randomClaimGenerator instance = new randomClaimGenerator();
        String test=instance.genDateOfBirth();
        for (int i=0;i<1000;i++)
        {
            
            test=instance.genDateOfBirth();
            System.out.println("===========================");
            System.out.println("Original Date: "+test);
            int y=Integer.parseInt(test.split("/")[2]);
            String tt=instance.genStartDate(y);
            String ty=instance.genEndDate(tt);
            String s=instance.genDateOfClaim(tt,ty);
            String g=instance.genDateOfLoss(s);
            System.out.println("Start Date: "+tt);
            System.out.println("End Date: "+ty);
            System.out.println("Claim Date: "+s);
            System.out.println("Loss Date: "+g);
            System.out.println("===========================");
            System.out.println(" ");
        }
        System.out.println("test");
        
      
        // TODO review the generated test code and remove the default call to fail.
      //  fail("The test case is a prototype.");
    }
    /**
     * Test of clearClaims method, of class GenerationEngine.
     */
    @Test
    public void testClearClaims() {
        System.out.println("clearClaims");
        GenerationEngine instance = new GenerationEngine();
        instance.clearClaims();
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
    @Test
    public void testClaimConstruction() throws IOException {
        System.out.println("Claim Construction");
        InsuranceClaim test[]=new InsuranceClaim[5];
        for (int i=0;i<5;i++)
        {
            test[i]=randomClaimGenerator.generateInsuranceClaim();
            System.out.println();
            randomClaimGenerator.generateFraudulentClaim(test[i]);
            System.out.println();
        }
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
    
    @Test
    public void testDateTransform() throws IOException {
        System.out.println("Date transformation");
        
        double a=PPDM.produceDateTransformation("26/01/1999");
        System.out.println(a);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
    
    @Test
    public void testTestFileProduction() throws IOException {
        System.out.println("PPDM");
        
        InsuranceClaim test[]=new InsuranceClaim[5];
        for (int i=0;i<5;i++)
        {
            test[i]=randomClaimGenerator.generateInsuranceClaim();
            System.out.println();
        }
        
        PPDM.produceFileForNN(test);
        PPDM.produceInputSetForNN();
        
        System.out.println();
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
}
