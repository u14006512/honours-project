/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pso.project;

/**
 *
 * @author Warmaster
 */
public class Katsuura extends ObjectiveFunction{

    @Override
    public double functionEvaluation(double[] inputs) {
    
        double result=1.0;
        
        double com1=0.0,com2=0.0;
        
        for (int i=0;i<20;i++)
        {

            com1=com1+1;
            com2=0.0;
            for(int j=0;j<32;j++)
            {
                com2=com2+(Math.abs(Math.pow(2, j) -Math.round(Math.pow(2, j)*inputs[i]))/Math.pow(2, j));
            }
            com2=com2*i;
            com1=com1+com2;
            com1=Math.pow(com1, (10/Math.pow(20, 1.2)));
            result=result*com1;
        }
        
        result=(10/(20*20))*result -(10/(20*20));
        
        return result;
    }

    @Override
    public double[] getRange() {
    double s[]={-100,100};
    return s;
    }
    
}
