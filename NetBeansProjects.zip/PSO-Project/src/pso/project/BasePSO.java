/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pso.project;

import java.security.SecureRandom;

/**
 *
 * @author Warmaster
 */
public class BasePSO {
    String nameOfExperiment;
    Swarm swarm;
    ObjectiveFunction objFun;
    int its;
    double inertiaWeight;
    double c1,c2;
    double r1[],r2[];
    boolean printMod=false;
    
    BasePSO(int is,String objFunc,String exp,double C1,double C2,boolean printMode)
    {
        this.printMod=printMode;
        SecureRandom s=new SecureRandom();
        nameOfExperiment=exp;
        its=is;
        inertiaWeight=0.7;
        r1=new double[20];
        r2=new double[20];
        //randomise for c1,c2
       // c1=s.nextDouble();
        //c2=s.nextDouble();
        c1=C1;
        c2=C2;
        switch (objFunc)
        {
            case "a":objFun=new SphericalFunction();
                break;
            case "b": objFun=new Ackley();
                break;
            case "c": objFun=new Michalewicz();
                break;
            case "d": objFun=new Katsuura();
                break;
            case "e":objFun=new Shubert(); 
                break;
            case "f": objFun=new Ackley();
                break;
            case "g": objFun=new Ackley();
                break;
            case "h": objFun=new Ackley();
                break;
            case "i":objFun=new Ackley();
                break;    
        }
        swarm=new Swarm(20,objFun.getRange());
        
        
    }
    public boolean checkIfInBounds(double [] position, double range[])
    {
        for(int i=0;i<position.length;i++)
        {
            if (position[i] > range[1] || position[i]<range[0])
                return false;
        }
        
        return true;
    }
    public void doRun()
    {
        
        //Do the full run & then save the data of the run
        
        double leftNeighbour=0.0,rightNeighbour=0.0;
        for(int q=0;q<20;q++)
        {
            swarm.setFitnessOfParticle(q, objFun.functionEvaluation(swarm.getPositionArrayOfParticle(q)));
        }
        
        
        for(int i=0;i<its;i++)
        {
            System.out.println("================================================");
            System.out.println("Iteration: "+(i+1));
           for (int j=0;j<swarm.swarmSize;j++)
           {
               //Setting Personal Best
               swarm.setFitnessOfParticle(j,objFun.functionEvaluation(swarm.getPositionArrayOfParticle(j)));
               if (swarm.getFitnessOfParticle(j)
                       <objFun.functionEvaluation(swarm.getPersonalBestPositionArrayOfParticle(j)))
               {
                   if (checkIfInBounds( swarm.getPositionArrayOfParticle(j), objFun.getRange())==true){
                    swarm.updateBestPositionOfParticle(j, swarm.getPositionArrayOfParticle(j));
                   }
                   
               }
               if (printMod==true)
                    {
                    System.out.println("Particle "+j+" Position: "+arrayToString(swarm.getPositionArrayOfParticle(j)));
                    }
               //Setting Neighbourhood Best Position
              
               leftNeighbour=objFun.functionEvaluation(swarm.getPositionArrayOfParticle(swarm.getNeighbourhood(j)[0]));
               rightNeighbour=objFun.functionEvaluation(swarm.getPositionArrayOfParticle(swarm.getNeighbourhood(j)[2]));
               
               if (leftNeighbour < swarm.getFitnessOfParticle(j) &&  leftNeighbour < rightNeighbour)
               {
                   if (checkIfInBounds(swarm.getPositionArrayOfParticle(swarm.getNeighbourhood(j)[0]), objFun.getRange())==true){
                   swarm.updateNeighbourhoodBestOfParticle(j,swarm.getPositionArrayOfParticle(swarm.getNeighbourhood(j)[0]));
                   }
               }
               
               if (leftNeighbour < rightNeighbour &&  leftNeighbour < swarm.getFitnessOfParticle(j))
               {
                   if (checkIfInBounds(swarm.getPositionArrayOfParticle(swarm.getNeighbourhood(j)[0]), objFun.getRange())==true){
                   swarm.updateNeighbourhoodBestOfParticle(j,swarm.getPositionArrayOfParticle(swarm.getNeighbourhood(j)[0]));
                   }
               }
               
               if (swarm.getFitnessOfParticle(j) <leftNeighbour && swarm.getFitnessOfParticle(j)<rightNeighbour)
               {
                   if (checkIfInBounds(swarm.getPositionArrayOfParticle(j), objFun.getRange())==true){
                   swarm.updateNeighbourhoodBestOfParticle(j,swarm.getPositionArrayOfParticle(j));
                   }
               }
               
               if (swarm.getFitnessOfParticle(j) <rightNeighbour && swarm.getFitnessOfParticle(j)<leftNeighbour)
               {
                   if (checkIfInBounds(swarm.getPositionArrayOfParticle(j), objFun.getRange())==true){
                   swarm.updateNeighbourhoodBestOfParticle(j,swarm.getPositionArrayOfParticle(j));
                   }
               }
               
               if (rightNeighbour<leftNeighbour && rightNeighbour <swarm.getFitnessOfParticle(j))
               {
                   if (checkIfInBounds(swarm.getPositionArrayOfParticle(swarm.getNeighbourhood(j)[2]), objFun.getRange())==true){
                   swarm.updateNeighbourhoodBestOfParticle(j,swarm.getPositionArrayOfParticle(swarm.getNeighbourhood(j)[2]));
                   }
               }
               if (rightNeighbour<swarm.getFitnessOfParticle(j)&& rightNeighbour <leftNeighbour)
               {
                   if (checkIfInBounds(swarm.getPositionArrayOfParticle(swarm.getNeighbourhood(j)[2]), objFun.getRange())==true){
                   
                   swarm.updateNeighbourhoodBestOfParticle(j,swarm.getPositionArrayOfParticle(swarm.getNeighbourhood(j)[2]));
                   
                   
                   }
               }
               
               System.out.println("Particle Fitness:"+swarm.getFitnessOfParticle(j));
           }
          
           ///Update everything now
           updateSwarmVelocities();
           System.out.println("================================================");
           
           
    //////////////////////////////////////////////////////////////////////////////           
        updateSwarmPosition();
   
    //////////////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////////////
               
           System.out.println("End of iteration");
        }
        
        //save results of run for later comparison {file name included for ease
        // of delineation}
    }
    
    public void updateSwarmVelocities()
    {
        SecureRandom s=new SecureRandom();
         double tmpVe,tmpCog,tmpSoc;
        for (int k=0;k<swarm.swarmSize;k++)
           {
               //Update velocity of Particle
    //////////////////////////////////////////////////////////////////////////////
               
               tmpSoc=0.0;
               tmpCog=0.0;
               
               for(int h=0;h<swarm.swarmSize;h++)
               {
                   tmpVe=inertiaWeight*swarm.getVelocity(k,h);
                   r1[h]=c1*s.nextDouble();
                   r2[h]=c2*s.nextDouble();
                   tmpCog=r1[h]*(swarm.getPersonalBestPositionArrayOfParticle(k)[h]
                           -swarm.getPositionArrayOfParticle(k)[h]);
                   tmpSoc=r2[h]*(swarm.getNeighbourhoodBestPositionArrayOfParticle(k)[h]
                           -swarm.getPositionArrayOfParticle(k)[h]);
                   swarm.setVelocity(k, h,tmpVe+tmpCog+tmpSoc);
                   
               }
               
           }    
    }
    public void updateSwarmPosition()
    {
         for(int r=0;r<swarm.swarmSize;r++){
            //Update Position of Particle
               for(int t=0;t<swarm.swarmSize;t++)
               {
                   swarm.setPositionArrayOfParticle(r,t,swarm.getPositionArrayOfParticle(r)[t]+swarm.getVelocity(r,t));
               }
            }
    }
    
    public String arrayToString(double [] a)
    {
        String t="";
        for(int i=0;i<a.length;i++)
        {
            t=t+"|"+a[i];
        }
        return t;
    }
    
}
