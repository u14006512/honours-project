/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pso.project;

/**
 *
 * @author Warmaster
 */
public class Shubert extends ObjectiveFunction {

    @Override
    public double functionEvaluation(double[] inputs) {
        double result=1.0;    
        double com1=0.0;
        
        for (int j=0;j<20;j++)
        {
            com1=0.0;
         for(int i=0;i<5;i++)
         {
             com1=com1+(i*Math.cos(inputs[j]*(i+1))+i);
         }   
         result=result*com1;   
        }
        return result;
    }

    @Override
    public double[] getRange() {
        double s[]={-10,10};
    return s;
    }
    
    
}
