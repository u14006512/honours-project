/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pso.project;

/**
 *
 * @author Warmaster
 */
public class Michalewicz extends ObjectiveFunction{
    double m=10;

    @Override
    public double functionEvaluation(double[] inputs) {
       double result=0.0;
       
       for (int i=0;i<inputs.length;i++)
       {
        result=result+Math.sin(inputs[i])*(Math.pow((Math.sin((i*Math.pow(inputs[i],2))/Math.PI)),2*m));
       }
       
       result=-1*result;
       
       return result;
    }

    @Override
    public double[] getRange() {
       double s[]={0,Math.PI};
       return s;
    }
    
    
    
}
