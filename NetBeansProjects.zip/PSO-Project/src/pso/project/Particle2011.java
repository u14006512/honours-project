/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pso.project;

import java.security.SecureRandom;
import java.util.Vector;

/**
 *
 * @author Warmaster
 */
public class Particle2011 extends Particle {
        int k;
        Vector <Integer> neighbourhood;
        
        Particle2011()
        {
            position=new double[20];
            bestPosition=new double[20];
            neighbourhoodBestPosition=new double[20];
            velocity=new double[20];
            fitness=0.0;
            neighbourhood=new Vector<>();
        }
        
        public void initialiseParticle(double range[],int index)
        {
            k=3;
            SecureRandom random=new SecureRandom();
            
            for(int i=0;i<20;i++)
            {   //Min + (int)(Math.random() * ((Max - Min) + 1))range[1]=max,range[0]=min
                ///double randomValue = rangeMin + (rangeMax - rangeMin) * r.nextDouble();
                position[i]=range[0]+(range[1]-range[0]) *kiss.API.random();
                bestPosition[i]=position[i];
            }
            
          
            
        }
        
        @Override
        public void updatePosition(double newPos[])
        {
            System.arraycopy(newPos, 0, position, 0, newPos.length);
        }
        
        @Override
        public void updateBestPosition(double newPos[])
        {
            System.arraycopy(newPos, 0, bestPosition, 0, newPos.length);
        }
        @Override
        public void neighbourhoodBestPosition(double newPos[])
        {
            for(int i=0;i<newPos.length;i++)
            {
                neighbourhoodBestPosition[i]=newPos[i];
            }
        }
        @Override
        public void updateVelocity(double newVel[])
        {
            System.arraycopy(newVel, 0, velocity, 0, newVel.length);
        }
        
        
}
