/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pso.project;

import java.security.SecureRandom;
import java.util.Vector;
import java.util.concurrent.ThreadLocalRandom;

/**
 *
 * @author Warmaster
 */
public class SPSO2011 extends BasePSO {
    Swarm2011 swarm2;
    double w=0.721;
    double c=1.193;
    public SPSO2011(int is, String objFunc, String exp, double C1, double C2, boolean printMode) {
        super(is, objFunc, exp, C1, C2, printMode);
        SecureRandom r=new SecureRandom();
        swarm2=new Swarm2011(20,objFun.getRange());
        reshuffleNeighbourhoods();
        
        for(int i=0;i<20;i++)
        {
            swarm2.swarm2011[i].fitness=objFun.functionEvaluation(swarm2.swarm2011[i].position);
        }
        
        for(int i=0;i<20;i++)
        {
            for(int j=0;j<20;j++){
            swarm2.swarm2011[i].velocity[j]=(objFun.getRange()[0]-(swarm2.swarm2011[i].position[j])) + (((objFun.getRange()[1]-(swarm2.swarm2011[i].position[j]))) - 
                    (objFun.getRange()[1]-(swarm2.swarm2011[i].position[j]))) * r.nextDouble();
            }
        }
        
        for(int i=0;i<20;i++)
        {
            swarm2.swarm2011[i].neighbourhoodBestPosition=getSmallestN(swarm2.swarm2011[i].neighbourhood);
        }
    }
    
    
    private double [] getSmallestN(Vector<Integer> ns)
    {
        int index=0;
        double lowest=Double.MAX_VALUE;
        for(int i=0;i<ns.size();i++)
        {
            if (swarm2.swarm2011[ns.get(i)].fitness <lowest)
            {
                lowest=swarm2.swarm2011[ns.get(i)].fitness;
                index=i;
            }
        }
        
        return swarm2.swarm2011[ns.get(index)].position;
    }
    private void reshuffleNeighbourhoods()
    {
        int randomP;
        int sizeN;
        double ranChance;
        SecureRandom s=new SecureRandom();
        for (int i=0;i<20;i++)
        {
            swarm2.swarm2011[i].k=10;
            swarm2.swarm2011[i].neighbourhood.clear();
            
        }
        
        for (int i=0;i<swarm2.swarmSize;i++)
        {
            ranChance=kiss.API.random();
            if (ranChance>0.95)
            {
                sizeN=kiss.API.random(12, 20);
            }else if (ranChance<0.95 && ranChance>0.9)
                {
                    sizeN=kiss.API.random(6, 11);
                    
                } else  
                    {
                        sizeN=kiss.API.random(1, 3);
                        
                    } 
            
            while (swarm2.swarm2011[i].neighbourhood.size()!=sizeN)
            {
                randomP=kiss.API.random(20);
                
                if (swarm2.swarm2011[randomP].k!=0)
                {
                    swarm2.swarm2011[i].neighbourhood.add(randomP);
                    swarm2.swarm2011[randomP].k=swarm2.swarm2011[randomP].k-1;
                }
            }
        }
        
        
        
    }

    @Override
    public void doRun() {
        
        //Do the full run & then save the data of the run
        
        Particle2011 bestParticle=swarm2.swarm2011[0];
        for(int q=0;q<20;q++)
        {
            swarm2.setFitnessOfParticle(q, objFun.functionEvaluation(swarm2.getPositionArrayOfParticle(q)));
        }
        
        
        for(int i=0;i<its;i++)
        {
            System.out.println("================================================");
            System.out.println("Iteration: "+(i+1));
           for (int j=0;j<swarm2.swarmSize;j++)
           {
               //Setting Personal Best
               swarm2.setFitnessOfParticle(j,objFun.functionEvaluation(swarm2.getPositionArrayOfParticle(j)));
               if (swarm2.getFitnessOfParticle(j)
                       <objFun.functionEvaluation(swarm2.getPersonalBestPositionArrayOfParticle(j)))
               {
                   if (checkIfInBounds( swarm2.getPositionArrayOfParticle(j), objFun.getRange())==true){
                    swarm2.updateBestPositionOfParticle(j, swarm2.getPositionArrayOfParticle(j));
                   }
                   
               }
               if (printMod==true)
                    {
                    System.out.println("Particle "+j+" Position: "+arrayToString(swarm2.getPositionArrayOfParticle(j)));
                    }
               //Setting Neighbourhood Best Position

               for(int k=0;k<swarm2.swarm2011[j].neighbourhood.size();k++)
               {
                   if (checkIfInBounds(getSmallestN(swarm2.swarm2011[j].neighbourhood), objFun.getRange())==true)
                           {
                           swarm2.swarm2011[j].neighbourhoodBestPosition=
                           getSmallestN(swarm2.swarm2011[j].neighbourhood);
                           }
                   
               }
               System.out.println("Particle Fitness:"+swarm2.swarm2011[j].fitness);
           }
          double lowest=Double.MAX_VALUE;
          int index=0; 
          for(int w=0;w<20;w++)
           {
               if (swarm2.swarm2011[w].fitness<lowest)
               {
                   
                   index=w;
                   lowest=swarm2.swarm2011[w].fitness;
               }
           }
           
           if (swarm2.swarm2011[index].fitness>=bestParticle.fitness)
           {
               reshuffleNeighbourhoods();
           } else 
            {
                bestParticle=swarm2.swarm2011[index];
            }
           ///Update everything now
           updateSwarmVelocities();
           System.out.println("================================================");
           
           
    //////////////////////////////////////////////////////////////////////////////           
   
    //////////////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////////////
               
           System.out.println("End of iteration");
        }
        
        //save results of run for later comparison {file name included for ease
        // of delineation}
    }

    

    @Override
    public void updateSwarmVelocities() {

        double []g=new double[20];
        double []radius=new double[20];
        double [] xDash=new double[20];
        boolean cornerCase=false;
        for (int i=0;i<20;i++)
        {
            if (swarm2.swarm2011[i].bestPosition==swarm2.swarm2011[i].neighbourhoodBestPosition)
            {
                cornerCase=true;
            }
            for(int j=0;j<20;j++)
            {
            if (cornerCase==false){    
            g[j]=swarm2.swarm2011[i].position[j]+c*((swarm2.swarm2011[i].bestPosition[j]+
                    swarm2.swarm2011[i].neighbourhoodBestPosition[j]-2*(swarm2.swarm2011[i].position[j]))/3.0);
            } else 
                {
                 g[j]=swarm2.swarm2011[i].position[j]+c*((swarm2.swarm2011[i].bestPosition[j]-(swarm2.swarm2011[i].position[j]))/2.0);
                }
            radius[j]=Math.abs(g[j]-swarm2.swarm2011[i].position[j]);
            }
            
            for(int k=0;k<20;k++)
            {
                 ///double randomValue = rangeMin + (rangeMax - rangeMin) * r.nextDouble();
                xDash[k]=(g[k]-radius[k]) + ((g[k]+radius[k]) - (g[k]-radius[k])) * kiss.API.random();
                swarm2.swarm2011[i].velocity[k]=w*swarm2.swarm2011[i].velocity[k] +xDash[k]-swarm2.swarm2011[i].position[k];
            }
            
            for(int l=0;l<20;l++)
            {
                swarm2.swarm2011[i].position[l]=w*swarm2.swarm2011[i].velocity[l]+xDash[l];
            }
        }
    }
    
    
}
