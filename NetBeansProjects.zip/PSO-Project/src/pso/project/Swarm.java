/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pso.project;

/**
 *
 * @author Warmaster
 */
public class Swarm {
    int swarmSize=20;
    Particle swarm[];
    Swarm()
    {
    }
     Swarm(int size,double range[],int v)
    {
        swarmSize=size;
        swarm=new Particle2011[20];
        for(int i=0;i<swarmSize;i++)
        {
            swarm[i]=new Particle2011();
            swarm[i].initialiseParticle(range, i);
        }
    }   
    
    Swarm(int size,double range[])
    {
        swarmSize=size;
        swarm=new Particle[20];
        for(int i=0;i<swarmSize;i++)
        {
            swarm[i]=new Particle();
            swarm[i].initialiseParticle(range, i);
        }
    }
    public Particle getParticle(int index)
    {
        return swarm[index];
    }
    
    public double getVelocity(int i,int dimension)
    {
        return swarm[i].velocity[dimension];
    }
    
     public void setVelocity(int i,int dimension,double v)
    {
        swarm[i].velocity[dimension]=v;
    }
     
    public void setFitnessOfParticle(int i,double f)
    {
        swarm[i].fitness=f;
    }
    public double getFitnessOfParticle(int i)
    {
        return swarm[i].fitness;
    }
    public int[] getNeighbourhood(int index)
    {
        return swarm[index].neighbourhood;
    }
    public double[] getPositionArrayOfParticle(int index)
    {
        return swarm[index].position;
    }
    
    public void setPositionArrayOfParticle(int index,int dimension,double value)
    {
        swarm[index].position[dimension]=value;
    }
    

    public double[] getPersonalBestPositionArrayOfParticle(int index)
    {
        return swarm[index].bestPosition;
    }
    
    public double[] getNeighbourhoodBestPositionArrayOfParticle(int index)
    {
        return swarm[index].neighbourhoodBestPosition;
    }
    
    public void updateVelocityOfParticle(int index,double [] newVel){
    
            ///receive new velocity for particle i
            for (int i=0;i<swarm[index].velocity.length;i++)
        {
         swarm[index].velocity[i]=newVel[i];   
        }
    }
    
    public void updatePositionOfParticle(int index,double [] newPos)
    {
    
        //receive new particle position for particle i
        for (int i=0;i<swarm[index].position.length;i++)
        {
         swarm[index].position[i]=newPos[i];   
        }
    }
    
    public void updateNeighbourhoodBestOfParticle(int index,double [] newPos)
    {
    
        //receive new particle position for particle i
        for (int i=0;i<swarm[index].neighbourhoodBestPosition.length;i++)
        {
         swarm[index].neighbourhoodBestPosition[i]=newPos[i];   
        }
    }
    
    public void updateBestPositionOfParticle(int index,double [] newPos)
    {
    
        //receive new particle position for particle i
        for (int i=0;i<swarm[index].bestPosition.length;i++)
        {
         swarm[index].bestPosition[i]=newPos[i];   
        }
    }
}
