/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pso.project;

import java.security.SecureRandom;

/**
 *
 * @author Warmaster
 */
public class Particle {
        
        double position[];
        double bestPosition[];
        double neighbourhoodBestPosition[];
        double velocity[];
        double fitness;
        int neighbourhood[];
        
        Particle()
        {
            position=new double[20];
            bestPosition=new double[20];
            neighbourhoodBestPosition=new double[20];
            velocity=new double[20];
            fitness=0.0;
            neighbourhood=new int[3];
        }
        
        public void initialiseParticle(double range[],int index)
        {
            
            SecureRandom random=new SecureRandom();
            fitness=Double.MAX_VALUE;
            for(int i=0;i<20;i++)
            {   //Min + (int)(Math.random() * ((Max - Min) + 1))range[1]=max,range[0]=min
                ///double randomValue = rangeMin + (rangeMax - rangeMin) * r.nextDouble();
                position[i]=range[0]+(range[1]-range[0]) *random.nextDouble();
                bestPosition[i]=position[i];
                neighbourhoodBestPosition[i]=position[i];
                velocity[i]=0.0;
            }
            
            if (index-1 ==-1){neighbourhood[0]=19;} else
            {neighbourhood[0]=index-(1%20);}
            
            neighbourhood[1]=index;
            
            if (index+1== 20){neighbourhood[2]=0;} else 
            {
            neighbourhood[2]=index+(1%20);
            }
        }
        
        public void updatePosition(double newPos[])
        {
            for(int i=0;i<newPos.length;i++)
            {
                position[i]=newPos[i];
            }
        }
        
        public void updateBestPosition(double newPos[])
        {
            for(int i=0;i<newPos.length;i++)
            {
                bestPosition[i]=newPos[i];
            }
        }
        public void neighbourhoodBestPosition(double newPos[])
        {
            for(int i=0;i<newPos.length;i++)
            {
                neighbourhoodBestPosition[i]=newPos[i];
            }
        }
        public void updateVelocity(double newVel[])
        {
            for(int i=0;i<newVel.length;i++)
            {
                velocity[i]=newVel[i];
            }
        }
}
