/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pso.project;

/**
 *
 * @author Warmaster
 */
public class ObjectiveFunction {
    public double[] getRange()
    {
        double s[]={-1,1};
        return s;
    }
    
    public double functionEvaluation(double [] inputs)
    {
        return 0.0;
    }
}
