/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pso.project;


/**
 *
 * @author Warmaster
 */
public class SphericalFunction extends ObjectiveFunction{
    double range[]={-5.12,5.12};
    @Override
    public double functionEvaluation(double[] inputs) {
       double tmp=0.0;
    for (int i=0;i<inputs.length;i++)
        {
            tmp=tmp+Math.pow(inputs[i],2.0);
        }
    return tmp;
    }

    @Override
    public double[] getRange() {
    return range;
    }
    
    
    
}
