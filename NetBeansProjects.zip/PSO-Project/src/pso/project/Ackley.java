/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pso.project;

/**
 *
 * @author Warmaster
 */
public class Ackley extends ObjectiveFunction {
    
    @Override
    public double functionEvaluation(double[] inputs) {
        double comp1=0.0,comp2=0.0;
        double result=0.0;
        
        
        //c1
        for(int i=0;i<20;i++)
        {
            comp1=comp1+Math.pow(inputs[i], 2.0);
        }
        comp1=(1/20.0)*comp1;
        comp1=-0.2*Math.sqrt(comp1);
        comp1=Math.pow(Math.E,comp1);
        comp1=-20*comp1;
        //c2
        for(int i=0;i<20;i++)
        {
            comp2=comp2+Math.cos(2*Math.PI*inputs[i]);
        }
        comp2=(1/20.0)*comp2;
        comp2=Math.pow(Math.E, comp2);
        comp2=-1*comp2;
        
        result=comp1+comp2+20+Math.E;
        return result;
    }

    @Override
    public double[] getRange() {
     double s[]={-32.768,32.768};
     return s;    
    }
    
}
