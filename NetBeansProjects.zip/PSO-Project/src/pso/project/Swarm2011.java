/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pso.project;

import java.util.Vector;

/**
 *
 * @author Warmaster
 */
public class Swarm2011 extends Swarm {
    Particle2011 swarm2011[];
    
    public Swarm2011(int size, double[] range){
        swarmSize=size;
        swarm2011=new Particle2011[20];
        for(int i=0;i<swarmSize;i++)
        {
            swarm2011[i]=new Particle2011();
            swarm2011[i].initialiseParticle(range, i);
        }
    }
    
     public Particle getParticle(int index)
    {
        return swarm2011[index];
    }
    
    public double getVelocity(int i,int dimension)
    {
        return swarm2011[i].velocity[dimension];
    }
    
     public void setVelocity(int i,int dimension,double v)
    {
        swarm2011[i].velocity[dimension]=v;
    }
     
    public void setFitnessOfParticle(int i,double f)
    {
        swarm2011[i].fitness=f;
    }
    public double getFitnessOfParticle(int i)
    {
        return swarm2011[i].fitness;
    }
    
    public Vector<Integer> getNeighbourhood2011(int index)
    {
        return swarm2011[index].neighbourhood;
    }
    
    public double[] getPositionArrayOfParticle(int index)
    {
        return swarm2011[index].position;
    }
    
    public void setPositionArrayOfParticle(int index,int dimension,double value)
    {
        swarm2011[index].position[dimension]=value;
    }
    

    public double[] getPersonalBestPositionArrayOfParticle(int index)
    {
        return swarm2011[index].bestPosition;
    }
    
    public double[] getNeighbourhoodBestPositionArrayOfParticle(int index)
    {
        return swarm2011[index].neighbourhoodBestPosition;
    }
    
    public void updateVelocityOfParticle(int index,double [] newVel){
    
            ///receive new velocity for particle i
            for (int i=0;i<swarm2011[index].velocity.length;i++)
        {
         swarm2011[index].velocity[i]=newVel[i];   
        }
    }
    
    public void updatePositionOfParticle(int index,double [] newPos)
    {
    
        //receive new particle position for particle i
        for (int i=0;i<swarm2011[index].position.length;i++)
        {
         swarm2011[index].position[i]=newPos[i];   
        }
    }
    
    public void updateNeighbourhoodBestOfParticle(int index,double [] newPos)
    {
    
        //receive new particle position for particle i
        for (int i=0;i<swarm2011[index].neighbourhoodBestPosition.length;i++)
        {
         swarm2011[index].neighbourhoodBestPosition[i]=newPos[i];   
        }
    }
    
    public void updateBestPositionOfParticle(int index,double [] newPos)
    {
    
        //receive new particle position for particle i
        for (int i=0;i<swarm2011[index].bestPosition.length;i++)
        {
         swarm2011[index].bestPosition[i]=newPos[i];   
        }
    }
}
