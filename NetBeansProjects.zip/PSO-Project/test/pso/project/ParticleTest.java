/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pso.project;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Warmaster
 */
public class ParticleTest {
    
    public ParticleTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of initialiseParticle method, of class Particle.
     */
    @Test
    public void testInitialiseParticle() {
        System.out.println("initialiseParticle");
        double[] range = {0,5};
        
        Particle instance[]= new Particle[20];
        for (int i=0;i<20;i++)
        {
            instance[i]=new Particle();
            instance[i].initialiseParticle(range, i);
        }
        
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of updatePosition method, of class Particle.
     */
    @Test
    public void testUpdatePosition() {
        System.out.println("updatePosition");
        double[] newPos = {-1.0,0,1.0};
        Particle instance = new Particle();
        instance.updatePosition(newPos);
        if( instance.position[0]== newPos[0])
       {
           
       } else {fail();}
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of updateBestPosition method, of class Particle.
     */
    @Test
    public void testUpdateBestPosition() {
        System.out.println("updateBestPosition");
        double[] newPos = {-1.0,0,1.0};
        Particle instance = new Particle();
        instance.updateBestPosition(newPos);
        if( instance.bestPosition[0]== newPos[0])
       {
           
       } else {fail();}
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of neighbourhoodBestPosition method, of class Particle.
     */
    @Test
    public void testNeighbourhoodBestPosition() {
        System.out.println("neighbourhoodBestPosition");
        double[] newPos = {-1.0,0,1.0};
        Particle instance = new Particle();
        instance.neighbourhoodBestPosition(newPos);
       if( instance.neighbourhoodBestPosition[0]== newPos[0])
       {
           
       } else {fail();}
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of updateVelocity method, of class Particle.
     */
    @Test
    public void testUpdateVelocity() {
        System.out.println("updateVelocity");
        double newVel = 1.0;
        Particle instance = new Particle();
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
    
}
