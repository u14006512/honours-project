/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pso.project;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Warmaster
 */
public class BasePSOTest {
    
    public BasePSOTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of doRun method, of class BasePSO.
     */
    @Test
    public void testDoRun() {
        System.out.println("doRun");
        BasePSO instance =new BasePSO(1000,"b","Spherical",0.4,0.5,true);
        instance.doRun();
        // TODO review the generated test code and remove the default call to fail.
    
    }
    
}
