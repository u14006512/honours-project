/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pso.project;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Warmaster
 */
public class SPSO2011Test {
    
    public SPSO2011Test() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    @Test
    public void testSomeMethod() {
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of reshuffleNeighbourhoods method, of class SPSO2011.
     */
    @Test
    public void testReshuffleNeighbourhoods() {
        System.out.println("reshuffleNeighbourhoods");
        SPSO2011 instance = new SPSO2011(20, "a", "2", 0.5, 0.5, true);
        System.out.println();
        // TODO review the generated test code and remove the default call to fail.
 
    }

    /**
     * Test of doRun method, of class SPSO2011.
     */
    @Test
    public void testDoRun() {
        System.out.println("doRun");
        SPSO2011 instance = new SPSO2011(1000, "b", "2", 0.5, 0.5, true);
        instance.doRun();
        // TODO review the generated test code and remove the default call to fail.

    }

    /**
     * Test of updateSwarmVelocities method, of class SPSO2011.
     */
    @Test
    public void testUpdateSwarmVelocities() {
        System.out.println("updateSwarmVelocities");
        SPSO2011 instance = null;
        instance.updateSwarmVelocities();
        // TODO review the generated test code and remove the default call to fail.

    }
    
}
