/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pso.project;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Warmaster
 */
public class Particle2011Test {
    
    public Particle2011Test() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of initialiseParticle method, of class Particle2011.
     */
    @Test
    public void testInitialiseParticle() {
        System.out.println("initialiseParticle");
        double[] range = null;
        int index = 0;
        int[] initN = null;
        Particle2011 instance = new Particle2011();
        instance.initialiseParticle(range, index);
        // TODO review the generated test code and remove the default call to fail.
   
    }

    /**
     * Test of updatePosition method, of class Particle2011.
     */
    @Test
    public void testUpdatePosition() {
        System.out.println("updatePosition");
        double[] newPos = null;
        Particle2011 instance = new Particle2011();
        instance.updatePosition(newPos);
        // TODO review the generated test code and remove the default call to fail.
   
    }

    /**
     * Test of updateBestPosition method, of class Particle2011.
     */
    @Test
    public void testUpdateBestPosition() {
        System.out.println("updateBestPosition");
        double[] newPos = null;
        Particle2011 instance = new Particle2011();
        instance.updateBestPosition(newPos);
        // TODO review the generated test code and remove the default call to fail.
   
    }

    /**
     * Test of neighbourhoodBestPosition method, of class Particle2011.
     */
    @Test
    public void testNeighbourhoodBestPosition() {
        System.out.println("neighbourhoodBestPosition");
        double[] newPos = null;
        Particle2011 instance = new Particle2011();
        instance.neighbourhoodBestPosition(newPos);
        // TODO review the generated test code and remove the default call to fail.
   
    }

    /**
     * Test of updateVelocity method, of class Particle2011.
     */
    @Test
    public void testUpdateVelocity() {
        System.out.println("updateVelocity");
        double[] newVel = null;
        Particle2011 instance = new Particle2011();
        instance.updateVelocity(newVel);
        // TODO review the generated test code and remove the default call to fail.
   
    }

   
}
