/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pso.project;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Warmaster
 */
public class SwarmTest {
    
    public SwarmTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of updateVelocityOfParticle method, of class Swarm.
     */
    @Test
    public void testUpdateVelocityOfParticle() {
        System.out.println("updateVelocityOfParticle");
        int index = 0;
        double ran[]={-10.0,10.0};
        double t[]={5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5};
        Swarm instance = new Swarm(20,ran);
        instance.updateVelocityOfParticle(index,t);
        // TODO review the generated test code and remove the default call to fail.
       //fail("The test case is a prototype.");
    }

    /**
     * Test of updatePositionOfParticle method, of class Swarm.
     */
    @Test
    public void testUpdatePositionOfParticle() {
        System.out.println("updatePositionOfParticle");
        int index = 0;
        
        double ran[]={-10.0,10.0};
        double t[]={5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5};
        Swarm instance = new Swarm(20,ran);
        instance.updatePositionOfParticle(index,t);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of updateNeighbourhoodBestOfParticle method, of class Swarm.
     */
    @Test
    public void testUpdateNeighbourhoodBestOfParticle() {
        System.out.println("updateNeighbourhoodBestOfParticle");
        int index = 0;
         double ran[]={-10.0,10.0};
         
        double t[]={5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5};
        Swarm instance = new Swarm(20,ran);
        instance.updateNeighbourhoodBestOfParticle(index,t);
    }

    /**
     * Test of updateBestPositionOfParticle method, of class Swarm.
     */
    @Test
    public void testUpdateBestPositionOfParticle() {
        System.out.println("updateBestPositionOfParticle");
        int index = 0; double ran[]={-10.0,10.0};
        double t[]={5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5};
        Swarm instance = new Swarm(20,ran);
        instance.updateBestPositionOfParticle(index,t);
    }
    
}
