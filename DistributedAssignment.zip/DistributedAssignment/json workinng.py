import json
strA=json.loads('{"status": "success", "message": "Argghh, the pirates have new clues to look for.", "data": [{"id": "1A7020FDED2549079C8DF06786105CF6", "data": [{"id": "0", "data": "1DF1"},{"id": "78139583CDD44EA59950B9BA3595A82A", "data": "1DF1E81E21DD1E61EF1E71E41DF1DC1DE1DE1E31E01DD1DE1D81E11E11E11E41E41F320B2042012012012002042042041FF20220220520220220520520520520520820820520520520720A20A20720720720720420520520220220520B20B20B20720420720D21020D20D21021421721D22022322322022022021D21A21A21721421120E21121421721A21D21D21D21D21A21721121121421721420E21421421421421421421421421721721721721721421421421A21721420F20F21121421421121121121121121120E20B20E2082112052171F3"}]},{"id": "0436E96A67DD43D9AEF34EBE22FC36E5", "data": [{"id": "4", "data": "1DF1"},{"id": "5", "data": "2DF2"}]}]}')
#print ("Length of entire object"+str(len(strA)))
#num pirates
#print ("Num Pirates: "+str(len(strA["data"])))
#print ("Pirate ID: "+str((strA["data"][0]["id"])))
#num clues
#print ("Num Clues Per Pirate: "+str(len(strA["data"][0]["data"])))
#print ("Num Clues Per Pirate: "+str(len(strA["data"][1]["data"])))

#print ("1st printed "+str((strA["data"][0]["data"][0]["data"])))
#print ("2nd printed "+str((strA["data"][0]["data"][1]["data"])))
#print ("3rd printed "+str((strA["data"][0]["data"][2]["data"])))

clueMatrix=[]
resultsMatrix=[]
pID=[]
cID=[]
#counts the number of pirates
numPirates=len((strA["data"]))
for i in range(numPirates):
    numClues=len(strA["data"][i]["data"])
    clueMatrix.append([])
    resultsMatrix.append([])
    for j in range(numClues):
        clueMatrix[i].append("#")
        resultsMatrix[i].append("$")

for i in range(numPirates):
    numClues=len(strA["data"][i]["data"])
    pID.append(strA["data"][i]["id"])
    for j in range(numClues):
        clueMatrix[i][j]=strA["data"][i]["data"][j]["data"]
        cID.append(strA["data"][i]["data"][j]["id"])
        
print("PID:")
print(pID)
print("CID:")
print(cID)
#print (clueMatrix)        
#print ("solving the matrix")

##This produces a json string for the verify process
resultStr=[]
for i in range(numPirates):
    resultStr.append({})
    resultStr[i]["id"]=pID[i]
    numClues=len(strA["data"][i]["data"])
    resultStr[i]["data"]=[]
    for j in range(numClues):
        resultStr[i]["data"].append({})
        resultStr[i]["data"][j]["id"]=cID[i]
        resultStr[i]["data"][j]["key"]=resultsMatrix[i][j]
        
json_result=json.dumps(resultStr)
print("'"+json_result+"'")