import Pyro4
import subprocess
import signal
import sys
import time
import psutil
import os
import json

def done(self,verifyMessage):
    return 1

@Pyro4.expose
@Pyro4.behavior(instance_mode="session")
class pirate(object):
    clueMatrix=[]
    resultsMatrix=[]
    quarterMaster=False
    listOfCrew=[]
    results=[]
    clues=[]
    asyncCrew=[]
    proxies=[]
    pids=[]
    def __init__(self):
        self.pID="pirate"+sys.argv[1]
        self.listOfCrew=[]
        self.asyncCrew=[]
    def getNewClues(self):
        return []

    def convertMatrixToFormat(self,cMatrix):
        return []
    def updateFailuresList(self,clueList):
        0
    def createAndFillCluesMatrix(self,cluesList):
        0
    def doWork(self):
        return 1
    def addCrew(self,listOfCrew):
        for i in listOfCrew:
            self.listOfCrew.append(i)
            self.pids.append(subprocess.Popen(["py", "pirate.py", str(i)], shell=True).pid)
            time.sleep(2)

        for i in listOfCrew:
            self.proxies.append(Pyro4.Proxy("PYRONAME:" + "pirate" + str(i)))
        count = 0
        for i in listOfCrew:
            self.asyncCrew.append(Pyro4.async(proxy=self.proxies[count]))
            count = count + 1
        print("Crew's ready to go")
        print(self.listOfCrew)
    def removeCrew(self,crewId):
        pos=self.listOfCrew.index(crewId)
        temp = self.pids[pos]

        if (pos>-1):
            self.asyncCrew.pop(pos)
            self.listOfCrew.pop(pos)
            self.proxies.pop(pos)
            self.pids.pop(pos)

            for (proc) in psutil.process_iter():
                if (proc.pid==temp):
                    #need to check process killing on linux
                    os.system("taskkill /f /PID "+ str(temp))
            print("Crewman removed")
            print("current crew: "+str(len(self.listOfCrew)))
        else:
                print("Couldn't find that crewman")
def main():
        p=pirate()
        print("Pirate:" + p.pID + " reporting for duty")

        if (p.pID=="pirate0"):
            print("I'm the Quartermaster")
            p.quarterMaster=True
            daemon=Pyro4.Daemon()
            uri=daemon.register(p)
            ns=Pyro4.locateNS(host="localhost",port=9090)
            ns.register("quartermaster",uri)
            time.sleep(2)
            print(" ")
            print("I'm awake-registering crew")
            #send rummy the prepare message
            #get pirate ids from rummy
            #ask for pirates

            #crew added
            print("crew working")
            #send rummy the prepare message
            # start the main loop
            controlStr=[] #this is what will be used to hold the statements that are verified by Rummy
            while ((done(controlStr))!=0):
                ctrl=done(controlStr)
                #ctrl==1 means the clues where all verified
                if (ctrl==1):
                    p.createAndFillCluesMatrix(p.getNewClues())
                #ctrl==2 means there were errors in the program
                else:
                    p.createAndFillCluesMatrix(controlStr)
                    p.updateFailuresList(controlStr)
                #clues should be made by this point ->time to process and solve
                numEls=0
                for givenProcessI in range(len(p.listOfCrew)):
                    for givenClueJ in range(len(p.clueMatrix[givenProcessI])):
                        p.resultsMatrix[givenProcessI][givenClueJ][1]=p.asyncCrew[givenProcessI].doWork()
                        numEls=numEls+1
                 #dispatched all of the clues to the owners -> now we wait for the lot of them to be done

                count=0

                doneWorking=False
                while (doneWorking==False):
                    count=0
                    for a in range(len(p.listOfCrew)):
                        for b in range(len(p.clueMatrix[b])):
                           if (p.resultsMatrix[a][b][1].ready==True):
                               count=count+1
                    if (count==numEls):
                        doneWorking=True

                controlStr=p.convertMatrixToFormat(p.clueMatrix)
                #results all ready for verification

            print("crew done -tresure found")
        else:

            print("I'm just a pirate")


            Pyro4.Daemon.serveSimple(
                    {
                        pirate:p.pID
                    }
                    ,ns=True
            )

main()
