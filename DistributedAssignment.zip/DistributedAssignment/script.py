import os
import subprocess
import time
count=0;
#p = subprocess.Popen(["py","-m","Pyro4.naming"], stdout=subprocess.PIPE, stderr=subprocess.STDOUT)

for count in range(0,1):
    print("ID:"+str(count))
    p = subprocess.Popen(["py", "pirate.py", str(count)], shell=True)
    time.sleep(2)

print("Pirates made")
#time.sleep(10)
#w=subprocess.check_output(["py","-m","Pyro4.nsc","list"],shell=True)
#print(str(w))
#time.sleep(10)
#a=subprocess.Popen(["py", "quarterMaster.py",str(w)])
#print ("crew assembled")