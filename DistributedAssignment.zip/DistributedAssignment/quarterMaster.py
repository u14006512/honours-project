import subprocess
import Pyro4
import sys
@Pyro4.behavior(instance_mode="single")
class QuarterMaster(object):
    def __init__(self):
        print("Quartermaster Ready for Work")

def main():
    Q=QuarterMaster()

    p0=Pyro4.Proxy("PYRONAME:pirate0")
    aPo=Pyro4.async(proxy=p0)
    a=aPo.doWork()

    p01 = Pyro4.Proxy("PYRONAME:pirate1")
    aPo1 = Pyro4.async(proxy=p01)
    a1 = aPo1.doWork()

    while (a1.ready==False) and (a.ready==False):
        0
    print("proxy got:" +str(a.value))
    print("proxy got:" + str(a1.value))


main()
