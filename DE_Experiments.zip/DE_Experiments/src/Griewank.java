
import java.math.BigDecimal;
import java.util.Vector;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Warmaster
 */
public class Griewank extends ObjectiveFunction{
    
    public BigDecimal functionEvaluation(Vector<Double> inputs) {
        double result1=0.0;    
        double result2=1.0;
        BigDecimal finalResult=new BigDecimal(0);
        
        for (int i=0;i<inputs.size();i++)
        {
            result1=result1+(inputs.get(i)*inputs.get(i));
        } 
        double x;
        for(int i=0;i<inputs.size();i++)
        {
            x=i;
            if (x==0)
            {
                x=1;
            }
            result2=result2*Math.cos(inputs.get(i)/Math.sqrt(x));
        }
        
        finalResult=finalResult.add(new BigDecimal(1+((1.0/4000.0)*(result1))-(result2)));
        
        return finalResult;
    }

    
    public double[] getRange() {
        double s[]={-600,600};
    return s;
    }
}
