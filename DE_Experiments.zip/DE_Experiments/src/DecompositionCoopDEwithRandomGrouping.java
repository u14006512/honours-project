
import java.io.FileNotFoundException;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.util.Vector;
import java.util.concurrent.ThreadLocalRandom;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Warmaster
 */
public class DecompositionCoopDEwithRandomGrouping {
    double B,pr;
    Vector<Population> populations;
    Vector<Double> contextVector;
    ObjectiveFunction obFun; ///initialised as different OBF over time
    int kVal;
    int t;
    
    int functionIndicator,dimensionIndicator,strategyIndicator;
    
    public DecompositionCoopDEwithRandomGrouping() {
    contextVector=new Vector<>();
    populations=new Vector<>();
    B=0.5;
    pr=0.5; ///will use adaptive strategy to change B and pr over time
    functionIndicator=-1;
    strategyIndicator=0;
    dimensionIndicator=-1;
    }
    public static double bFunction(int runCount)
    {
        return -Math.log((runCount/0.75)+10)+1.85;
    }
    
    public static double prFunction(int runCount)
    {
        return -Math.log((runCount/0.75)+10)+1.85;
    }
    
    public static double poFunction(int runCount)
    {
        return -Math.log((runCount/0.75)+10)+1.85;
    }
    
    void initialiseStrategyAtStart(int initialPopCount)
    {
        populations.add(new Population());
    }
    void switchFunction(int i)
    {
        switch (i)
            {
                case 0: obFun=null;
                        obFun=new Alpine();
                    break;
                case 1:obFun=null;
                        obFun=new EggHolder();
                    break;
                case 2:obFun=null;
                        obFun=new Griewank();
                    break;
                case 3:obFun=null;
                        obFun=new Salomon();
                    break;
                case 4:obFun=null;
                        obFun=new Rosenbrock();
                    break;
                case 5:obFun=null;
                        obFun=new Schaffer6();
                    break;
                case 6:obFun=null;
                        obFun=new Vincent();
                    break;
                case 7:obFun=null;
                        obFun=new Weierstrass();
                    break;    
                /*
                case 5:obFun=null;
                        obFun=new Salomon();
                    break;
                case 6:obFun=null;
                        obFun=new Schaffer6();
                    break;
                case 7:obFun=null;
                        obFun=new Schwefel2();
                    break;
                case 8:obFun=null;
                        obFun=new Shubert();
                    break;
                case 9:obFun=null;
                        obFun=new Vincent();
                    break;
                case 10:obFun=null;
                        obFun=new Weierstrass();
                    break;    
                */    
            }
    }
    
    double[] getDimensions(int of)
    {
        return obFun.getRange();
    }
    
    void performDE() throws FileNotFoundException, UnsupportedEncodingException
    {
                BigDecimal [] runData=new BigDecimal[30];
        strategyIndicator=5;
        //int []dimArry={50,100,150,200,250,300,350,400,450,500,600,700,800,900,1000};
        Vector<Population> tmpPop=new Vector<>();
        
        int []dimArry={50,1000,800,700,500,400,300,200,100,50};
        System.out.println("Running DE Experiment: Decomposition Co-OP DE with Random Grouping");
        t=1000;
        for (int i=0;i<8;i++)
        {
            BigDecimal s;
            switchFunction(i);
            functionIndicator=i;
            System.out.println("Current Function Indicator:" +DataGatherer.getFunctionName(i));
            System.out.println("Current Dimension Lower Bound:"+obFun.getRange()[0]);
            System.out.println("Current Dimension Upper Bound:"+obFun.getRange()[1]);
            System.out.println("======================================================================");
            for (int j=0;j<dimArry.length;j++)
            {
                dimensionIndicator=j;
                ///Initialise Parameters for Experiment
                System.out.println("Current Dimmension Indicator: "+DataGatherer.getDimension(j));
                for (int k=0;k<1;k++)
                {
                    System.out.println("Current Run Indicator: "+k);
                    ///Clear and initialise populations according to strategy
                    populations=null;
                    contextVector.clear();
                    populations=new Vector<>();
                    B=1;
                    pr=0.3;
                    
                    if (k>=0 && k<=4)
                    {
                        t=5000;
                    } else if (k>=5 && k<=9)
                        {
                            t=4000;
                        } else if (k>=10 && k<=14)
                            {
                                t=3000;
                            } else if (k>=15 && k<=19)
                                {
                                    t=2000;
                                } else if (k>=20 && k<=24)
                                    {
                                        t=1500;
                                    } else 
                                        {
                                            t=1000;
                                        }
                    
                    
                    Vector<Integer> tmpDCom=new Vector<>();
                    Vector<Integer> tmpDimensions=new Vector<>();

                    for (int yy=0;yy<dimArry[dimensionIndicator];yy++)
                    {
                        tmpDimensions.add(yy);
                    }
                    ///Logic Regarding changing parameters
                    /*
                    Changing parameters should be done on a per run basis.
                    */
                    
                    ///Do the initial prime for the populationsings for the dimension assignments
                    contextVector.clear();
                    
                    contextVector.setSize(dimArry[dimensionIndicator]);
                    for (int ee=0;ee<contextVector.size();ee++)
                    {
                        contextVector.set(ee, ThreadLocalRandom.current().nextDouble(obFun.getRange()[0]
                                ,obFun.getRange()[1]));
                    }
                    
                    //init part of the algorithm
                    int tD1 = 0,tD2 = 0;
                    populations.add(new Population());
                    populations.get(0).initialisePopulation(dimArry[dimensionIndicator], obFun.getRange(), B, pr, tmpDimensions);
                    
                    int tCount,tThres=50;
                    while (checkIfDone(populations)==false)
                    {
                        tCount=0;

                        while (tCount<tThres)
                        {
                            
                            doIteration(getDimensions(i));
                            contextVector.clear();
                            contextVector.setSize(dimArry[dimensionIndicator]);

                            for (int ww=0;ww<populations.size();ww++)
                            {
                                populations.get(ww).B=populations.get(ww).B-((1.0-0.7)/5000);
                                populations.get(ww).pr=populations.get(ww).pr+((0.5-0.3)/5000);


                                for (int gg=0;gg<populations.get(ww).dimensionComponents.size();gg++)
                                {
                                    contextVector.set(populations.get(ww).dimensionComponents.get(gg),
                                            populations.get(ww).individuals.get(populations.get(ww).currentBestPopBestIndividualIndex).getPositionFromVector(gg));

                                }
                                ///System.out.println("A");
                            }
                            tmpDimensions.clear();
                            int randomNumber; 
                            ///Reshuffle all dimension Components
                            for (int yy=0;yy<dimArry[dimensionIndicator];yy++)
                            {
                                tmpDimensions.add(yy);
                            }
                            for (int t=0;t<populations.size();t++)
                                {
                                    ///Do the random populationsing here
                                    tmpDCom.clear();
                                    for (int rr=0;rr<populations.get(t).sizeOfDimensionComponent;rr++)
                                    {
                                        randomNumber=ThreadLocalRandom.current().nextInt(tmpDimensions.size());
                                        tmpDCom.add(tmpDimensions.remove(randomNumber));
                                    }
                                    populations.get(t).setDimensionComponents(tmpDCom);
                                }
                            tCount++;
                        }
                        
                        tmpPop.clear();
                        
                        for (int kk=0;kk<populations.size();kk++)
                        {
                            if (populations.get(kk).sizeOfDimensionComponent==1)
                            {
                                tmpPop.add(new Population());
                                tmpPop.lastElement().copyPopulation(
                                        populations.get(kk).individuals
                                        , populations.get(kk).B,
                                        populations.get(kk).pr, 
                                        populations.get(kk).sizeOfDimensionComponent,
                                        populations.get(kk).currentBestPopBestIndividualIndex,
                                        populations.get(kk).dimensionComponents,
                                        0);
                            } else 
                                {
                                    if (populations.get(kk).sizeOfDimensionComponent%2 ==0 || populations.get(kk).sizeOfDimensionComponent==2)
                                    {
                                        tD1=populations.get(kk).sizeOfDimensionComponent/2;
                                        tD2=tD1;
                                    } else 
                                        {
                                            tD1=populations.get(kk).sizeOfDimensionComponent/2;
                                            tD2=populations.get(kk).sizeOfDimensionComponent-tD1;
                                        }
                                                                    tmpPop.add(new Population());
                                tmpPop.lastElement().copyPopulation(
                                        populations.get(kk).individuals
                                        , populations.get(kk).B,
                                        populations.get(kk).pr,tD1,
                                        populations.get(kk).currentBestPopBestIndividualIndex,
                                        populations.get(kk).dimensionComponents,
                                        -1);
                                tmpPop.add(new Population());
                                tmpPop.lastElement().copyPopulation(
                                        populations.get(kk).individuals
                                        , populations.get(kk).B,
                                        populations.get(kk).pr, 
                                        tD2,
                                        populations.get(kk).currentBestPopBestIndividualIndex,
                                        populations.get(kk).dimensionComponents,
                                        1);
                                }
                                

                        }
                        populations.clear();
                        
                         for (int sk=0;sk<tmpPop.size();sk++)
                        {
                            populations.add(new Population());
                            populations.lastElement().copyPopulation(
                                        tmpPop.get(sk).individuals
                                        , tmpPop.get(sk).B,
                                        tmpPop.get(sk).pr, 
                                        tmpPop.get(sk).sizeOfDimensionComponent,
                                        tmpPop.get(sk).currentBestPopBestIndividualIndex,
                                        tmpPop.get(sk).dimensionComponents,
                                        0);
                        }
                        int randomNumber; 
                        ///Reshuffle all dimension Components
                        for (int yy=0;yy<dimArry[dimensionIndicator];yy++)
                        {
                            tmpDimensions.add(yy);
                        }
                        for (int t=0;t<populations.size();t++)
                            {
                                ///Do the random populationsing here
                                tmpDCom.clear();
                                for (int rr=0;rr<populations.get(t).sizeOfDimensionComponent;rr++)
                                {
                                    randomNumber=ThreadLocalRandom.current().nextInt(tmpDimensions.size());
                                    tmpDCom.add(tmpDimensions.remove(randomNumber));
                                }
                                populations.get(t).setDimensionComponents(tmpDCom);
                            }
                        
                    }
                    //Get best from that run.
                    ////Add best to list
                    
                    
                    BigDecimal bestFit=populations.get(0).individuals.get(0).fitnessEvaluation;
                    int bestIndex=0;
                    for (int rr=0;rr<populations.size();rr++)
                    {
                        if (obFun.functionEvaluation(populations.get(rr).getPopulationBestVector()).compareTo(bestFit)<0)
                        {

                            bestFit=populations.get(rr).individuals.get(populations.get(rr).currentBestPopBestIndividualIndex).fitnessEvaluation;
                            bestIndex=rr;
                        }

                    }
                    
                    for (int sss=0;sss<populations.get(bestIndex).getPopulationBestVector().size();sss++)
                    {
                        System.out.println("Position "+sss+": "+populations.get(bestIndex).getPopulationBestVector().get(sss));
                    }
                    runData[k]=bestFit;
                }
                ///Data Reader creating a run file
                System.out.println("======================================================================");
                DataGatherer.createRunDataFile(functionIndicator, dimensionIndicator, strategyIndicator, runData);
            }
        }
    }
    
    /**
     Eval Fitness of current particle
     * Create Trail Vector
     * Create Offspring using Crossover
     * if better, replace parent
     */
    
    //Context Vector Maintained out this function
    void doIteration(double [] range)
    {
        BigDecimal bestPopFitness;
        int tmpIndex=0;
        ///Fitness Evaluations
        Vector<Double> conTmp=new Vector<>();
        for (int v=0;v<contextVector.size();v++)
        {
            conTmp.add(contextVector.get(v));
        }
        
        for (int z=0;z<populations.size();z++)
        {
            
            bestPopFitness=populations.get(z).individuals.get(0).fitnessEvaluation;
            tmpIndex=0;
            for(int i=0;i<populations.get(z).individuals.size();i++)
            {
                
                for(int w=0;w<populations.get(z).sizeOfDimensionComponent;w++)
                    
                conTmp.set(populations.get(z).dimensionComponents.get(w),
                        populations.get(z).individuals.get(i).positionVector.get(w));
                populations.get(z).individuals.get(i).fitnessEvaluation=
                        obFun.functionEvaluation(populations.get(z).individuals.get(i).positionVector);
                if (populations.get(z).individuals.get(i).fitnessEvaluation.compareTo(bestPopFitness)<0)
                {
                    bestPopFitness=populations.get(z).individuals.get(i).fitnessEvaluation;
                    tmpIndex=i;
                } 
                conTmp.clear();
                for (int v=0;v<contextVector.size();v++)
                {
                    conTmp.add(contextVector.get(v));
                }
            }
            populations.get(z).currentBestPopBestIndividualIndex=tmpIndex;
            
        }
        int x1,x2,x3;
        Vector<Double> trialVector=new Vector<>();
        Vector<Integer> crossovervector=new Vector<>();
        Vector<Double> offspring=new Vector<>();
        
        ///Actual Iteration Components X-Over, Mutation etc
        for (int z=0;z<populations.size();z++)
        {
            
            for(int i=0;i<populations.get(z).individuals.size();i++)
            {
                ///Mutation
                trialVector.clear();
                x1=i;
                x2=0;
                x3=0;
                
                while(x1==x2 || x2==x3 || x1==x3)
                {
                    x2=ThreadLocalRandom.current().nextInt(populations.get(z).individuals.size());
                    x3=ThreadLocalRandom.current().nextInt(populations.get(z).individuals.size());
                }
                
                for (int h=0;h<populations.get(z).individuals.get(i).dimensions;h++)
                {
                    trialVector.add(populations.get(z).individuals.get(x1).positionVector.get(h)
                            +B*((populations.get(z).individuals.get(x2).positionVector.get(h))
                            -populations.get(z).individuals.get(x3).positionVector.get(h)));
                }
                
                
                ///CrossOver
                ///0 equals parents, 1 equals trial vector
                crossovervector.clear();
                for (int x=0;x<populations.get(z).individuals.get(i).positionVector.size();x++)
                {
                    crossovervector.add(0);
                }
                int randS=ThreadLocalRandom.current().nextInt(populations.get(z).individuals.get(i).positionVector.size());
                crossovervector.set(randS,1);
                
                double tmpChance;
                
                for (int jj=0;jj<crossovervector.size();jj++)
                {
                    tmpChance=ThreadLocalRandom.current().nextDouble();
                    if (tmpChance<pr && jj!=randS)
                    {
                        crossovervector.set(jj, 1);
                    }
                    
                }
                offspring.clear();
                BigDecimal tmpFitness;
                
                for (int jj=0;jj<crossovervector.size();jj++)
                {
                    if (crossovervector.get(jj)==0)
                    {
                        offspring.add(populations.get(z).individuals.get(i).positionVector.get(jj));
                    } else 
                        {
                            offspring.add(trialVector.get(jj));
                        }
                }
                
                tmpFitness=obFun.functionEvaluation(offspring);
                
                
                if (tmpFitness.compareTo(populations.get(z).individuals.get(i).fitnessEvaluation)<0 &&
                        varsInRange(offspring,range)==true)
                {
                   
                   populations.get(z).individuals.get(i).setPositionVector(offspring);
                   populations.get(z).individuals.get(i).fitnessEvaluation=tmpFitness;
                }
            }
            
        }
        
        
    }
    
    boolean varsInRange(Vector<Double> vars,double [] range)
    {
        for(int i=0;i<vars.size();i++)
        {
            if (vars.get(i)<range[0] || vars.get(i)>range[1]) return false;
        }
        return true;
    
    }
    
    boolean checkIfDone(Vector<Population> population)
    {
        for (int i=0;i<population.size();i++)
        {
            if (population.get(i).sizeOfDimensionComponent!=1) 
                return false;
        }
        return true;
    }
    
    void performDEExperiment() throws FileNotFoundException, UnsupportedEncodingException
    {
                BigDecimal [] runData=new BigDecimal[30];
        strategyIndicator=5;
        //int []dimArry={50,100,150,200,250,300,350,400,450,500,600,700,800,900,1000};
        Vector<Population> populations=new Vector<>();
        Vector<Population> tmpPop=new Vector<>();
        
        int []dimArry={1000,800,700,500,400,300,200,100,50};
        System.out.println("Running DE Experiment: Decomposition Co-OP DE with Random Grouping");
        for (int i=0;i<8;i++)
        {
            BigDecimal s;
            switchFunction(i);
            functionIndicator=i;
            System.out.println("Current Function Indicator:" +DataGatherer.getFunctionName(i));
            System.out.println("Current Dimension Lower Bound:"+obFun.getRange()[0]);
            System.out.println("Current Dimension Upper Bound:"+obFun.getRange()[1]);
            System.out.println("======================================================================");
            for (int j=0;j<dimArry.length;j++)
            {
                dimensionIndicator=j;
                ///Initialise Parameters for Experiment
                System.out.println("Current Dimmension Indicator: "+DataGatherer.getDimension(j));
                for (int k=0;k<30;k++)
                {
                    System.out.println("Current Run Indicator: "+k);
                    ///Clear and initialise populations according to strategy
                    populations=null;
                    contextVector.clear();
                    populations=new Vector<>();
                    B=1;
                    pr=0.3;
                    
                    int numPop=dimArry[dimensionIndicator]/kVal;
                    
                    Vector<Integer> tmpDCom=new Vector<>();
                    Vector<Integer> tmpDimensions=new Vector<>();

                    for (int yy=0;yy<dimArry[dimensionIndicator];yy++)
                    {
                        tmpDimensions.add(yy);
                    }
                    ///Logic Regarding changing parameters
                    /*
                    Changing parameters should be done on a per run basis.
                    */
                    
                    ///Do the initial prime for the populationsings for the dimension assignments
                    contextVector.clear();
                    
                    contextVector.setSize(dimArry[dimensionIndicator]);
                    for (int ee=0;ee<contextVector.size();ee++)
                    {
                        contextVector.set(ee, ThreadLocalRandom.current().nextDouble(obFun.getRange()[0]
                                ,obFun.getRange()[1]));
                    }
                    
                    //init part of the algorithm
                    int tD1 = 0,tD2 = 0;
                    populations.add(new Population());
                    populations.get(0).initialisePopulation(dimArry[dimensionIndicator], obFun.getRange(), B, pr, tmpDimensions);
                    
                    int tCount,tThres=50;
                    while (checkIfDone(populations)==false)
                    {
                        tCount=0;

                        while (tCount<tThres)
                        {
                            doIteration(getDimensions(i));
                            contextVector.clear();
                            contextVector.setSize(dimArry[dimensionIndicator]);

                            for (int ww=0;ww<populations.size();ww++)
                            {
                                populations.get(ww).B=populations.get(ww).B-((1.0-0.7)/5000);
                                populations.get(ww).pr=populations.get(ww).pr+((0.5-0.3)/5000);


                                for (int gg=0;gg<populations.get(ww).dimensionComponents.size();gg++)
                                {
                                    contextVector.set(populations.get(ww).dimensionComponents.get(gg),
                                            populations.get(ww).individuals.get(populations.get(ww).currentBestPopBestIndividualIndex).getPositionFromVector(gg));

                                }
                                ///System.out.println("A");
                            }
                            tCount++;
                        }
                        
                        tmpPop.clear();
                        
                        for (int kk=0;kk<populations.size();kk++)
                        {
                            if (populations.get(kk).sizeOfDimensionComponent==1)
                            {
                                tmpPop.add(new Population());
                                tmpPop.lastElement().copyPopulation(
                                        populations.get(kk).individuals
                                        , populations.get(kk).B,
                                        populations.get(kk).pr, 
                                        populations.get(kk).sizeOfDimensionComponent,
                                        populations.get(kk).currentBestPopBestIndividualIndex,
                                        populations.get(kk).dimensionComponents
                                        ,0);
                            } else 
                                {
                                    if (populations.get(j).sizeOfDimensionComponent%2 ==0)
                                    {
                                        tD1=populations.get(j).sizeOfDimensionComponent/2;
                                        tD2=tD1;
                                    } else 
                                        {
                                            tD1=populations.get(j).sizeOfDimensionComponent/2;
                                            tD2=populations.get(j).sizeOfDimensionComponent-tD1;
                                        }
                                }
                                
                                tmpPop.add(new Population());
                                tmpPop.lastElement().copyPopulation(
                                        populations.get(kk).individuals
                                        , populations.get(kk).B,
                                        populations.get(kk).pr,tD1,
                                        populations.get(kk).currentBestPopBestIndividualIndex,
                                        populations.get(kk).dimensionComponents,
                                        -1);
                                tmpPop.add(new Population());
                                tmpPop.lastElement().copyPopulation(
                                        populations.get(kk).individuals
                                        , populations.get(kk).B,
                                        populations.get(kk).pr, 
                                        tD2,
                                        populations.get(kk).currentBestPopBestIndividualIndex,
                                        populations.get(kk).dimensionComponents,
                                        1);
                        }
                        populations.clear();
                        
                         for (int sk=0;sk<tmpPop.size();sk++)
                        {
                            populations.add(new Population());
                            populations.lastElement().copyPopulation(
                                        tmpPop.get(sk).individuals
                                        , tmpPop.get(sk).B,
                                        tmpPop.get(sk).pr, 
                                        tmpPop.get(sk).sizeOfDimensionComponent,
                                        tmpPop.get(sk).currentBestPopBestIndividualIndex,
                                        tmpPop.get(sk).dimensionComponents,
                                        0);
                        }
                        int randomNumber; 
                        ///Reshuffle all dimension Components
                        for (int yy=0;yy<dimArry[dimensionIndicator];yy++)
                        {
                            tmpDimensions.add(yy);
                        }
                        for (int t=0;t<numPop;t++)
                            {
                                ///Do the random populationsing here
                                tmpDCom.clear();
                                for (int rr=0;rr<populations.get(t).sizeOfDimensionComponent;rr++)
                                {
                                    randomNumber=ThreadLocalRandom.current().nextInt(tmpDimensions.size());
                                    tmpDCom.add(tmpDimensions.remove(randomNumber));
                                }
                                populations.get(t).setDimensionComponents(tmpDCom);
                            }
                        
                    }
                    //Get best from that run.
                    ////Add best to list
                    
                    
                    BigDecimal bestFit=populations.get(0).individuals.get(0).fitnessEvaluation;
                    int bestIndex=0;
                    for (int rr=0;rr<populations.size();rr++)
                    {
                        if (obFun.functionEvaluation(populations.get(rr).getPopulationBestVector()).compareTo(bestFit)<0)
                        {

                            bestFit=populations.get(rr).individuals.get(populations.get(rr).currentBestPopBestIndividualIndex).fitnessEvaluation;
                            bestIndex=rr;
                        }

                    }
                    
                    for (int sss=0;sss<populations.get(bestIndex).getPopulationBestVector().size();sss++)
                    {
                        System.out.println("Position "+sss+": "+populations.get(bestIndex).getPopulationBestVector().get(sss));
                    }
                    runData[k]=bestFit;
                }
                ///Data Reader creating a run file
                System.out.println("======================================================================");
                DataGatherer.createRunDataFile(functionIndicator, dimensionIndicator, strategyIndicator, runData);
            }
        }
    }
}
