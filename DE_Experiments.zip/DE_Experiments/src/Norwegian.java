
import java.math.BigDecimal;
import java.util.Vector;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Warmaster
 */
public class Norwegian extends ObjectiveFunction {
    public  BigDecimal functionEvaluation(Vector<Double> inputs) {
        BigDecimal result1=new BigDecimal(1);
        
        for (int i=0;i<inputs.size();i++)
        {
            result1=result1.multiply((new BigDecimal(Math.cos(Math.PI*Math.pow(inputs.get(i), 3.0))*((99+inputs.get(i)/100.0)))));
        }
        return result1;
    }

    
    public  double[] getRange() {
        double s[]={-1.1,1.1};
    return s;
    }
}
