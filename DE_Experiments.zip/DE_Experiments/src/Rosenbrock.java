
import java.math.BigDecimal;
import java.util.Vector;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Warmaster
 */
public class Rosenbrock extends ObjectiveFunction {
    
    public BigDecimal functionEvaluation(Vector<Double> inputs) {
        BigDecimal result=new BigDecimal(0);    
        
        for (int i=0;i<inputs.size()-1;i++)
        {
            result=result.add(new BigDecimal(100*Math.pow(inputs.get(i+1)-Math.pow(inputs.get(i),2),2)+Math.pow(inputs.get(i)-1,2)));
        }
        
        return result;
    }
    public double[] getRange() {
        double s[]={-30,30};
    return s;
    }
}
