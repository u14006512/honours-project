
import java.math.BigDecimal;
import java.util.Vector;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Warmaster
 */
public class Vincent extends ObjectiveFunction {
    
    public BigDecimal functionEvaluation(Vector<Double>inputs) {
        BigDecimal result=new BigDecimal(0);    
        double a=0;
        for(int i=0;i<inputs.size();i++)
        {
            a=a+Math.sin(10*Math.sqrt(inputs.get(i)));
        }
        
        result=result.add(new BigDecimal(-(1+a)));
        return result;
    }
    public  double[] getRange() {
        double s[]={0.25,10};
    return s;
    }
}
