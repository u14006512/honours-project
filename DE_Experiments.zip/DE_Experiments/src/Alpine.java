
import java.math.BigDecimal;
import java.util.Vector;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Warmaster
 */
public class Alpine extends ObjectiveFunction{
    
    public BigDecimal functionEvaluation(Vector<Double> inputs) {
        BigDecimal result1=new BigDecimal(0);    
        
        /*
        for (int i=0;i<inputs.size();i++)
        {
            result1=result1*Math.sin(inputs.get(i));
        }
        for (int i=0;i<inputs.size();i++)
        {
            result2=result2*inputs.get(i);
        }
        
        result2=Math.sqrt(result2);
        return result1*result2;
        */
        
        for (int i = 0; i <inputs.size(); ++i) {
            result1=result1.add(new BigDecimal(Math.abs(inputs.get(i)*Math.sin(inputs.get(i))+0.1*inputs.get(i))));
        }
        return result1;
    }

    
    public double[] getRange() {
        double s[]={-10,10};
    return s;
    }
}
