
import java.math.BigDecimal;
import java.util.Vector;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Warmaster
 */
public class Weierstrass extends ObjectiveFunction{
    
    public BigDecimal functionEvaluation(Vector<Double> inputs) {
    
        double a=0.5;
        double b=3.0;
    
        double result=0.0;
        double result2=0.0;
        double result3=0.0;
        BigDecimal finalResult=new BigDecimal(0);
        
        for (int i=0;i<inputs.size();i++)
        {
            result2=0.0;
            for (int j=0;j<20;j++)
            {
                result2=result2+(Math.pow(a,j)*Math.cos((2*Math.PI*Math.pow(b, j))*(inputs.get(i)+0.5)));
            }
            result3=0.0;
            for(int ii=0;ii<20;ii++)
            {
            result3=result3+(Math.pow(a, ii)*Math.cos(Math.PI*Math.pow(b, ii)));
            }
            result3=-inputs.size()*result3;
            result=result+(result2+result3);
        }
        
        finalResult=finalResult.add(new BigDecimal(result));
        return finalResult;
    }

    public  double[] getRange() {
        double s[]={-0.5,0.5};
    return s;
    }
}
