
import java.io.FileNotFoundException;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.util.Vector;
import java.util.concurrent.ThreadLocalRandom;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Warmaster
 */
public class CoopDEwithRandomGrouping {
    double B,pr;    
    int kVal;
    
    int [][] kMatrix=new int[3][9];
    
    Vector<Population> populations;
    Vector<Double> contextVector;
    ObjectiveFunction obFun; ///initialised as different OBF over time
    
    int functionIndicator,dimensionIndicator,strategyIndicator;
    
    public CoopDEwithRandomGrouping() {
    contextVector=new Vector<>();
    populations=new Vector<>();
    B=0.5;
    pr=0.5; ///will use adaptive strategy to change B and pr over time
    functionIndicator=-1;
    strategyIndicator=0;
    dimensionIndicator=-1;

    //Row 0
    kMatrix[0][0]=50;
    kMatrix[0][1]=80;
    kMatrix[0][2]=70;
    kMatrix[0][3]=50;
    kMatrix[0][4]=40;
    kMatrix[0][5]=60;
    kMatrix[0][6]=50;
    kMatrix[0][7]=50;
    kMatrix[0][8]=25;
    //Row 1
    kMatrix[1][0]=20;
    kMatrix[1][1]=40;
    kMatrix[1][2]=35;
    kMatrix[1][3]=50;
    kMatrix[1][4]=20;
    kMatrix[1][5]=30;
    kMatrix[1][6]=20;
    kMatrix[1][7]=25;
    kMatrix[1][8]=10;
    //Row 2
    kMatrix[2][0]=10;
    kMatrix[2][1]=10;
    kMatrix[2][2]=10;
    kMatrix[2][3]=10;
    kMatrix[2][4]=10;
    kMatrix[2][5]=10;
    kMatrix[2][6]=10;
    kMatrix[2][7]=10;
    kMatrix[2][8]=5;
    }
    public static double bFunction(int runCount)
    {
        return -Math.log((runCount/0.75)+10)+1.85;
    }
    
    public static double prFunction(int runCount)
    {
        return -Math.log((runCount/0.75)+10)+1.85;
    }
    
    public static double poFunctions(int runCount)
    {
        return -Math.log((runCount/0.75)+10)+1.85;
    }
    
    void initialiseStrategyAtStart(int initialPopCount)
    {
        
    }
    void switchFunction(int i)
    {
        switch (i)
            {
                case 0: obFun=null;
                        obFun=new Alpine();
                    break;
                case 1:obFun=null;
                        obFun=new EggHolder();
                    break;
                case 2:obFun=null;
                        obFun=new Griewank();
                    break;
                case 3:obFun=null;
                        obFun=new Salomon();
                    break;
                case 4:obFun=null;
                        obFun=new Rosenbrock();
                    break;
                case 5:obFun=null;
                        obFun=new Schaffer6();
                    break;
                case 6:obFun=null;
                        obFun=new Vincent();
                    break;
                case 7:obFun=null;
                        obFun=new Weierstrass();
                    break;    
                /*
                case 5:obFun=null;
                        obFun=new Salomon();
                    break;
                case 6:obFun=null;
                        obFun=new Schaffer6();
                    break;
                case 7:obFun=null;
                        obFun=new Schwefel2();
                    break;
                case 8:obFun=null;
                        obFun=new Shubert();
                    break;
                case 9:obFun=null;
                        obFun=new Vincent();
                    break;
                case 10:obFun=null;
                        obFun=new Weierstrass();
                    break;    
                */    
            }
    }
    
    double[] getDimensions(int of)
    {
        return obFun.getRange();
    }
    
    void performDE() throws FileNotFoundException, UnsupportedEncodingException
    {
            BigDecimal [] runData=new BigDecimal[30];
        strategyIndicator=2;
        //int []dimArry={50,100,150,200,250,300,350,400,450,500,600,700,800,900,1000};
        
        int []dimArry={1000,800,700,500,400,300,200,100,50};
        System.out.println("Running DE Experiment: Random Group CO-OP DE");
        for (int i=0;i<8;i++)
        {
            BigDecimal s;
            switchFunction(i);
            functionIndicator=i;
            System.out.println("Current Function Indicator:" +DataGatherer.getFunctionName(i));
            System.out.println("Current Dimension Lower Bound:"+obFun.getRange()[0]);
            System.out.println("Current Dimension Upper Bound:"+obFun.getRange()[1]);
            System.out.println("======================================================================");
            for (int j=0;j<dimArry.length;j++)
            {
                dimensionIndicator=j;
                ///Initialise Parameters for Experiment
                System.out.println("Current Dimmension Indicator: "+DataGatherer.getDimension(j));
                for (int k=0;k<5;k++)
                {
                    System.out.println("Current Run Indicator: "+k);
                    ///Clear and initialise populations according to strategy
                    populations=null;
                    contextVector.clear();
                    populations=new Vector<>();
                    B=1;
                    pr=0.3;
                    kVal=kMatrix[0][dimensionIndicator];
                    
                    if (k==10)
                    {
                        //Init Population for medium k
                        //remake context vector
                        kVal=kMatrix[1][dimensionIndicator];
   
                    }
                    if (k==20)
                    {
                        //Init Population for small k
                        //Remake context vector
                        kVal=kMatrix[2][dimensionIndicator];   
                    }
                    int numPop=dimArry[dimensionIndicator]/kVal;
                    
                    Vector<Integer> tmpDCom=new Vector<>();
                    Vector<Integer> tmpDimensions=new Vector<>();

                    for (int yy=0;yy<dimArry[dimensionIndicator];yy++)
                    {
                        tmpDimensions.add(yy);
                    }
                    int randomNumber;
                    for (int t=0;t<numPop;t++)
                    {
                        ///Do the random grouping here
                        tmpDCom.clear();
                        for (int rr=0;rr<kVal;rr++)
                        {
                            randomNumber=ThreadLocalRandom.current().nextInt(tmpDimensions.size());
                            tmpDCom.add(tmpDimensions.remove(randomNumber));
                        }
                        populations.add(new Population());
                        populations.lastElement().initialisePopulation(kVal, obFun.getRange(), B, pr,tmpDCom);
                    }
                    ///Logic Regarding changing parameters
                    /*
                    Changing parameters should be done on a per run basis.
                    */
                    
                    ///Do the initial prime for the groupings for the dimension assignments
                    contextVector.clear();
                    
                    contextVector.setSize(dimArry[dimensionIndicator]);
                    for (int ee=0;ee<contextVector.size();ee++)
                    {
                        contextVector.set(ee, ThreadLocalRandom.current().nextDouble(obFun.getRange()[0]
                                ,obFun.getRange()[1]));
                    }
                    for (int it=0;it<5000;it++)
                    {
                        ///Strategy logic regarding changing parameters
                        ///Strategy logic regarding new populations
                        doIteration(getDimensions(i));
                        contextVector.clear();
                        contextVector.setSize(dimArry[dimensionIndicator]);
        
                        for (int ww=0;ww<populations.size();ww++)
                        {
                            populations.get(ww).B=populations.get(ww).B-((1.0-0.7)/5000);
                            populations.get(ww).pr=populations.get(ww).pr+((0.5-0.3)/5000);
                            
                            
                            for (int gg=0;gg<populations.get(ww).dimensionComponents.size();gg++)
                            {
                                contextVector.set(populations.get(ww).dimensionComponents.get(gg),
                                        populations.get(ww).individuals.get(populations.get(ww).currentBestPopBestIndividualIndex).getPositionFromVector(gg));
                                
                            }
                            ///System.out.println("A");
                        }

                        //Random Grouping Here
                        for (int yy=0;yy<dimArry[dimensionIndicator];yy++)
                        {
                            tmpDimensions.add(yy);
                        }
                        for (int t=0;t<numPop;t++)
                            {
                                ///Do the random grouping here
                                tmpDCom.clear();
                                for (int rr=0;rr<kVal;rr++)
                                {
                                    randomNumber=ThreadLocalRandom.current().nextInt(tmpDimensions.size());
                                    tmpDCom.add(tmpDimensions.remove(randomNumber));
                                }
                                populations.get(t).setDimensionComponents(tmpDCom);
                            }
                        //System.out.println("Current Iteration: "+it);
                    }
                    //Get best from that run.
                    ////Add best to list
                    
                    BigDecimal bestFit=populations.get(0).individuals.get(0).fitnessEvaluation;
                   
                    int bestIndex=0;
                    for (int rr=0;rr<populations.size();rr++)
                    {
                        if (obFun.functionEvaluation(populations.get(rr).getPopulationBestVector()).compareTo(bestFit)<0)
                        {

                            bestFit=populations.get(rr).individuals.get(populations.get(rr).currentBestPopBestIndividualIndex).fitnessEvaluation;
                            bestIndex=rr;
                        }

                    }
                    
                    for (int sss=0;sss<populations.get(bestIndex).getPopulationBestVector().size();sss++)
                    {
                        System.out.println("Position "+sss+": "+populations.get(bestIndex).getPopulationBestVector().get(sss));
                    }
                    
                    runData[k]=bestFit;
                }
                ///Data Reader creating a run file
                System.out.println("======================================================================");
                DataGatherer.createRunDataFile(functionIndicator, dimensionIndicator, strategyIndicator, runData);
            }
        }
    }
    
    /**
     Eval Fitness of current particle
     * Create Trail Vector
     * Create Offspring using Crossover
     * if better, replace parent
     */
    
    //Context Vector Maintained out this function
    void doIteration(double [] range)
    {
        BigDecimal bestPopFitness;
        int tmpIndex=0;
        ///Fitness Evaluations
        Vector<Double> conTmp=new Vector<>();
        for (int v=0;v<contextVector.size();v++)
        {
            conTmp.add(contextVector.get(v));
        }
        
        for (int z=0;z<populations.size();z++)
        {
            
            bestPopFitness=populations.get(0).individuals.get(0).fitnessEvaluation;
            tmpIndex=0;
            for(int i=0;i<populations.get(z).individuals.size();i++)
            {
                for(int w=0;w<populations.get(z).sizeOfDimensionComponent;w++)
                {
                conTmp.set(populations.get(z).dimensionComponents.get(w),
                        populations.get(z).individuals.get(i).positionVector.get(w));
                
                }
                populations.get(z).individuals.get(i).fitnessEvaluation=
                        obFun.functionEvaluation(populations.get(z).individuals.get(i).positionVector);
                if (populations.get(z).individuals.get(i).fitnessEvaluation.compareTo(bestPopFitness)<0)
                {
                    bestPopFitness=populations.get(z).individuals.get(i).fitnessEvaluation;
                    tmpIndex=i;
                } 
                conTmp.clear();
                for (int v=0;v<contextVector.size();v++)
                {
                    conTmp.add(contextVector.get(v));
                }
            }
            populations.get(z).currentBestPopBestIndividualIndex=tmpIndex;
            
        }
        int x1,x2,x3;
        Vector<Double> trialVector=new Vector<>();
        Vector<Integer> crossovervector=new Vector<>();
        Vector<Double> offspring=new Vector<>();
        
        ///Actual Iteration Components X-Over, Mutation etc
        for (int z=0;z<populations.size();z++)
        {
            for(int i=0;i<populations.get(z).individuals.size();i++)
            {
                ///Mutation
                trialVector.clear();
                x1=i;
                x2=0;
                x3=0;
                
                while(x1==x2 || x2==x3 || x1==x3)
                {
                    x2=ThreadLocalRandom.current().nextInt(populations.get(z).individuals.size());
                    x3=ThreadLocalRandom.current().nextInt(populations.get(z).individuals.size());
                }
                
                for (int h=0;h<populations.get(z).individuals.get(i).dimensions;h++)
                {
                    trialVector.add(populations.get(z).individuals.get(x1).positionVector.get(h)
                            +B*((populations.get(z).individuals.get(x2).positionVector.get(h))
                            -populations.get(z).individuals.get(x3).positionVector.get(h)));
                }
                
                
                ///CrossOver
                ///0 equals parents, 1 equals trial vector
                crossovervector.clear();
                for (int x=0;x<populations.get(z).individuals.get(i).positionVector.size();x++)
                {
                    crossovervector.add(0);
                }
                int randS=ThreadLocalRandom.current().nextInt(populations.get(z).individuals.get(i).positionVector.size());
                crossovervector.set(randS,1);
                
                double tmpChance;
                
                for (int jj=0;jj<crossovervector.size();jj++)
                {
                    tmpChance=ThreadLocalRandom.current().nextDouble();
                    if (tmpChance<pr && jj!=randS)
                    {
                        crossovervector.set(jj, 1);
                    }
                    
                }
                offspring.clear();
                BigDecimal tmpFitness;
                
                for (int jj=0;jj<crossovervector.size();jj++)
                {
                    if (crossovervector.get(jj)==0)
                    {
                        offspring.add(populations.get(z).individuals.get(i).positionVector.get(jj));
                    } else 
                        {
                            offspring.add(trialVector.get(jj));
                        }
                }
                
                tmpFitness=obFun.functionEvaluation(offspring);
                
                
                if (tmpFitness.compareTo(populations.get(z).individuals.get(i).fitnessEvaluation)<0 &&
                        varsInRange(offspring,range)==true)
                {
                   
                   populations.get(z).individuals.get(i).setPositionVector(offspring);
                   populations.get(z).individuals.get(i).fitnessEvaluation=tmpFitness;
                }
            }
        }
        
        
    }
    
    boolean varsInRange(Vector<Double> vars,double [] range)
    {
        for(int i=0;i<vars.size();i++)
        {
            if (vars.get(i)<range[0] || vars.get(i)>range[1]) return false;
        }
        return true;
    }
    void performDEExperiment() throws FileNotFoundException, UnsupportedEncodingException
    {
            BigDecimal [] runData=new BigDecimal[30];
        strategyIndicator=2;
        //int []dimArry={50,100,150,200,250,300,350,400,450,500,600,700,800,900,1000};
        
        int []dimArry={1000,800,700,500,400,300,200,100,50};
        System.out.println("Running DE Experiment: Random Group CO-OP DE");
        for (int i=0;i<8;i++)
        {
            BigDecimal s;
            switchFunction(i);
            functionIndicator=i;
            System.out.println("Current Function Indicator:" +DataGatherer.getFunctionName(i));
            System.out.println("Current Dimension Lower Bound:"+obFun.getRange()[0]);
            System.out.println("Current Dimension Upper Bound:"+obFun.getRange()[1]);
            System.out.println("======================================================================");
            for (int j=0;j<dimArry.length;j++)
            {
                dimensionIndicator=j;
                ///Initialise Parameters for Experiment
                System.out.println("Current Dimmension Indicator: "+DataGatherer.getDimension(j));
                for (int k=0;k<5;k++)
                {
                    System.out.println("Current Run Indicator: "+k);
                    ///Clear and initialise populations according to strategy
                    populations=null;
                    contextVector.clear();
                    populations=new Vector<>();
                    
                    ///Put found values here: replace B,Pr, and KVal
                    B=1;
                    pr=0.3;
                    kVal=kMatrix[0][dimensionIndicator];
                    
                    if (k==10)
                    {
                        //Init Population for medium k
                        //remake context vector
                        kVal=kMatrix[1][dimensionIndicator];
   
                    }
                    if (k==20)
                    {
                        //Init Population for small k
                        //Remake context vector
                        kVal=kMatrix[2][dimensionIndicator];   
                    }
                    int numPop=dimArry[dimensionIndicator]/kVal;
                    
                    Vector<Integer> tmpDCom=new Vector<>();
                    Vector<Integer> tmpDimensions=new Vector<>();

                    for (int yy=0;yy<dimArry[dimensionIndicator];yy++)
                    {
                        tmpDimensions.add(yy);
                    }
                    int randomNumber;
                    for (int t=0;t<numPop;t++)
                    {
                        ///Do the random grouping here
                        tmpDCom.clear();
                        for (int rr=0;rr<kVal;rr++)
                        {
                            randomNumber=ThreadLocalRandom.current().nextInt(tmpDimensions.size());
                            tmpDCom.add(tmpDimensions.remove(randomNumber));
                        }
                        populations.add(new Population());
                        populations.lastElement().initialisePopulation(kVal, obFun.getRange(), B, pr,tmpDCom);
                    }
                    ///Logic Regarding changing parameters
                    /*
                    Changing parameters should be done on a per run basis.
                    */
                    
                    ///Do the initial prime for the groupings for the dimension assignments
                    contextVector.clear();
                    
                    contextVector.setSize(dimArry[dimensionIndicator]);
                    for (int ee=0;ee<contextVector.size();ee++)
                    {
                        contextVector.set(ee, ThreadLocalRandom.current().nextDouble(obFun.getRange()[0]
                                ,obFun.getRange()[1]));
                    }
                    for (int it=0;it<5000;it++)
                    {
                        ///Strategy logic regarding changing parameters
                        ///Strategy logic regarding new populations
                        doIteration(getDimensions(i));
                        contextVector.clear();
                        contextVector.setSize(dimArry[dimensionIndicator]);
        
                        for (int ww=0;ww<populations.size();ww++)
                        {
                            populations.get(ww).B=populations.get(ww).B-((1.0-0.7)/5000);
                            populations.get(ww).pr=populations.get(ww).pr+((0.5-0.3)/5000);
                            
                            
                            for (int gg=0;gg<populations.get(ww).dimensionComponents.size();gg++)
                            {
                                contextVector.set(populations.get(ww).dimensionComponents.get(gg),
                                        populations.get(ww).individuals.get(populations.get(ww).currentBestPopBestIndividualIndex).getPositionFromVector(gg));
                                
                            }
                            ///System.out.println("A");
                            
                            //Do the random grouping here
                            for (int t=0;t<numPop;t++)
                            {
                                ///Do the random grouping here
                                tmpDCom.clear();
                                for (int rr=0;rr<kVal;rr++)
                                {
                                    randomNumber=ThreadLocalRandom.current().nextInt(tmpDimensions.size());
                                    tmpDCom.add(tmpDimensions.remove(randomNumber));
                                }
                                populations.get(t).setDimensionComponents(tmpDCom);
                            }
                        }
                        //System.outi.println("Current Iteration: "+it);
                    }
                    //Get best from that run.
                    ////Add best to list
                    
                    Vector<Double> conTemp=new Vector<>();
                    for (int v=0;v<contextVector.size();v++)
                    {
                        conTemp.add(contextVector.get(v));
                    }
                    BigDecimal bestFit=populations.get(0).individuals.get(0).fitnessEvaluation;
                    int bestIndex=0;
                    for (int rr=0;rr<populations.size();rr++)
                    {
                        if (obFun.functionEvaluation(populations.get(rr).getPopulationBestVector()).compareTo(bestFit)<0)
                        {

                            bestFit=populations.get(rr).individuals.get(populations.get(rr).currentBestPopBestIndividualIndex).fitnessEvaluation;
                            bestIndex=rr;
                        }

                    }
                    
                    for (int sss=0;sss<populations.get(bestIndex).getPopulationBestVector().size();sss++)
                    {
                        System.out.println("Position "+sss+": "+populations.get(bestIndex).getPopulationBestVector().get(sss));
                    }
                    runData[k]=bestFit;
                }
                ///Data Reader creating a run file
                System.out.println("======================================================================");
                DataGatherer.createRunDataFile(functionIndicator, dimensionIndicator, strategyIndicator, runData);
            }
        }
    }    
}
