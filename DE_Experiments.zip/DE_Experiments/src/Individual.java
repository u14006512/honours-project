
import static java.lang.Math.max;
import java.math.BigDecimal;
import java.util.Random;
import java.util.Vector;
import java.util.concurrent.ThreadLocalRandom;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Warmaster
 */
public class Individual {
    int dimensions;
    BigDecimal fitnessEvaluation;
    Vector<Double> positionVector;
    
    void setDimensions(int d)
    {
        dimensions=d;
    }
    public Individual()
    {
        positionVector=new Vector<>();
    }
    public void copyIndividual(int dd, BigDecimal f, Vector<Double> pos)
    {
        dimensions=dd;
        fitnessEvaluation=f;
        
        positionVector.clear();
        
        for (int i=0;i<pos.size();i++)
        {
            positionVector.add(pos.get(i));
        }
    }
    
    public Individual(int d,double []range) {
        dimensions=d;
        fitnessEvaluation=new BigDecimal(0);
        positionVector=new Vector<Double>();
        
        for (int i=0;i<d;i++)
        {
            positionVector.add(ThreadLocalRandom.current().nextDouble(range[0], range[1]));
        }
        
        
    }
    
    int getDimensions()
    {
        return dimensions;
    }
    
    void resetPositions()
    {
        positionVector.clear();
    }
    
    void setPositionVector(Vector<Double> in)
    {
        positionVector.clear();
        for (int i=0;i<in.size();i++)
        {
            positionVector.add(in.get(i));
        }
    }
    double getPositionFromVector(int i)
    {
        return positionVector.get(i);
    }
    
    Vector<Double> getVector()
    {
        return positionVector;
    }
    
    void setPos(int in,double val)
    {
        positionVector.set(in, val);
    }
    
}
