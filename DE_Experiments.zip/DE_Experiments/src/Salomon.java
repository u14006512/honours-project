
import java.math.BigDecimal;
import java.util.Vector;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Warmaster
 */
public class Salomon extends ObjectiveFunction {
    
    public BigDecimal functionEvaluation(Vector<Double>inputs) {
        double result1=0.0;    
        double result2=0.0;
        BigDecimal finalResult=new BigDecimal(0);
        
        for(int i=0;i<inputs.size();i++)
        {
            result1=result1+(inputs.get(i)*inputs.get(i));
        }
        
        for(int i=0;i<inputs.size();i++)
        {
            result2=result2+(inputs.get(i)*inputs.get(i));
        }
        
        finalResult=finalResult.add(new BigDecimal(-1.0*(Math.cos(2*Math.PI*result1))+0.1*Math.sqrt(result2)+1));
        
        return finalResult;
    }

    
    public double[] getRange() {
        double s[]={-100,100};
    return s;
    }
}
