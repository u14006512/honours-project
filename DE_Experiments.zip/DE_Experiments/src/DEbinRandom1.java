
import java.io.FileNotFoundException;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.util.Iterator;
import java.util.Vector;
import java.util.concurrent.ThreadLocalRandom;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Warmaster
 */
public class DEbinRandom1 {
    double B,pr;
    Vector<Population> populations;
    Vector<Double> contextVector;
    ObjectiveFunction obFun; ///initialised as different OBF over time
    
    int functionIndicator,dimensionIndicator,strategyIndicator;
    
    public DEbinRandom1() {
    contextVector=new Vector<>();
    populations=new Vector<>();
    B=0.5;
    pr=0.5; ///will use adaptive strategy to change B and pr over time
    functionIndicator=-1;
    strategyIndicator=0;
    dimensionIndicator=-1;
    }
    public static double bFunction(int runCount)
    {
        return -Math.log((runCount/0.75)+10)+1.85;
    }
    
    public static double prFunction(int runCount)
    {
        return -Math.log((runCount/0.75)+10)+1.85;
    }
    
    public static double poFunction(int runCount)
    {
        return -Math.log((runCount/0.75)+10)+1.85;
    }
    
    void initialiseStrategyAtStart(int initialPopCount)
    {
        populations.add(new Population());
    }
    void switchFunction(int i)
    {
        switch (i)
            {
                case 0: obFun=null;
                        obFun=new Alpine();
                    break;
                case 1:obFun=null;
                        obFun=new EggHolder();
                    break;
                case 2:obFun=null;
                        obFun=new Griewank();
                    break;
                case 3:obFun=null;
                        obFun=new Salomon();
                    break;
                case 4:obFun=null;
                        obFun=new Rosenbrock();
                    break;
                case 5:obFun=null;
                        obFun=new Schaffer6();
                    break;
                case 6:obFun=null;
                        obFun=new Vincent();
                    break;
                case 7:obFun=null;
                        obFun=new Weierstrass();
                    break;    
                /*
                case 5:obFun=null;
                        obFun=new Salomon();
                    break;
                case 6:obFun=null;
                        obFun=new Schaffer6();
                    break;
                case 7:obFun=null;
                        obFun=new Schwefel2();
                    break;
                case 8:obFun=null;
                        obFun=new Shubert();
                    break;
                case 9:obFun=null;
                        obFun=new Vincent();
                    break;
                case 10:obFun=null;
                        obFun=new Weierstrass();
                    break;    
                */    
            }
    }
    
    double[] getDimensions(int of)
    {
        return obFun.getRange();
    }
    
    void performDE() throws FileNotFoundException, UnsupportedEncodingException
    {
        BigDecimal [] runData=new BigDecimal[30];
        strategyIndicator=0;
        //int []dimArry={50,100,150,200,250,300,350,400,450,500,600,700,800,900,1000};
        
        int []dimArry={1000,800,700,500,400,300,200,100,50};
        System.out.println("Running DE Experiment: DE/bin/rand/1");
        for (int i=0;i<8;i++)
        {
            BigDecimal s;
            switchFunction(i);
            functionIndicator=i;
            System.out.println("Current Function Indicator:" +DataGatherer.getFunctionName(i));
            System.out.println("Current Dimension Lower Bound:"+obFun.getRange()[0]);
            System.out.println("Current Dimension Upper Bound:"+obFun.getRange()[1]);
            System.out.println("======================================================================");
            for (int j=0;j<dimArry.length;j++)
            {
                dimensionIndicator=j;
                ///Initialise Parameters for Experiment
                System.out.println("Current Dimmension Indicator: "+DataGatherer.getDimension(j));
                for (int k=0;k<30;k++)
                {
                    System.out.println("Current Run Indicator: "+k);
                    ///Clear and initialise populations according to strategy
                    populations=null;
                    contextVector.clear();
                    populations=new Vector<>();
                    populations.add(new Population());
                    contextVector.setSize(dimArry[dimensionIndicator]);
                    populations.get(0).B=1;
                    populations.get(0).pr=0.3;
                    ///Logic Regarding changing parameters
                    /*
                    Changing parameters should be done on a per run basis.
                    */
                    
                    ///Do the initial prime for the groupings for the dimension assignments
                    Vector<Integer> dimTmp=new Vector<>();
                    for (int hh=0;hh<contextVector.size();hh++)
                    {
                        contextVector.set(hh,0.0);
                        dimTmp.add(hh);
                    }
                    populations.get(0).initialisePopulation(dimArry[dimensionIndicator],
                            getDimensions(i), B, pr,dimTmp);
                    

                    
                    
                    for (int it=0;it<5000;it++)
                    {
                        ///Strategy logic regarding changing parameters
                        ///Strategy logic regarding new populations
                        doIteration(getDimensions(i));
                        populations.get(0).B=populations.get(0).B-((1.0-0.7)/5000);
                        populations.get(0).pr=populations.get(0).pr+((0.5-0.3)/5000);;
                    }
                    //Get best from that run.
                    ////Add best to list
                    
                    BigDecimal bestFit=populations.get(0).individuals.get(0).fitnessEvaluation;
                   
                    for (int y=0;y<30;y++)
                    {
                        if (obFun.functionEvaluation(populations.get(0).individuals.get(y).getVector()).compareTo(bestFit)<0)
                        {
                           
                            bestFit=obFun.functionEvaluation(populations.get(0).individuals.get(y).getVector());
                        }
                    }
                    
                    runData[k]=bestFit;
                }
                ///Data Reader creating a run file
                System.out.println("======================================================================");
                DataGatherer.createRunDataFile(functionIndicator, dimensionIndicator, strategyIndicator, runData);
            }
        }
        
    }
    
    /**
     Eval Fitness of current particle
     * Create Trail Vector
     * Create Offspring using Crossover
     * if better, replace parent
     */
    
    //Context Vector Maintained out this function
    void doIteration(double [] range)
    {
        BigDecimal bestPopFitness;
        int tmpIndex=0;
        ///Fitness Evaluations
        Vector<Double> conTmp=new Vector<>();
        for (int v=0;v<contextVector.size();v++)
        {
            conTmp.add(contextVector.get(v));
        }
        
        for (int z=0;z<populations.size();z++)
        {
            
            bestPopFitness=populations.get(z).individuals.get(0).fitnessEvaluation;
            tmpIndex=0;
            for(int i=0;i<populations.get(z).individuals.size();i++)
            {
                for(int w=0;w<populations.get(z).sizeOfDimensionComponent;w++)
                {
                conTmp.set(populations.get(z).dimensionComponents.get(w),
                        populations.get(z).individuals.get(i).positionVector.get(w));
                
                }
                populations.get(z).individuals.get(i).fitnessEvaluation=
                        obFun.functionEvaluation(populations.get(z).individuals.get(i).positionVector);
                if (populations.get(z).individuals.get(i).fitnessEvaluation.compareTo(bestPopFitness)<0)
                {
                    bestPopFitness=populations.get(z).individuals.get(i).fitnessEvaluation;
                    tmpIndex=i;
                } 
                conTmp.clear();
                for (int v=0;v<contextVector.size();v++)
                {
                    conTmp.add(contextVector.get(v));
                }
            }
            populations.get(z).currentBestPopBestIndividualIndex=tmpIndex;
            
        }
        int x1,x2,x3;
        Vector<Double> trialVector=new Vector<>();
        Vector<Integer> crossovervector=new Vector<>();
        Vector<Double> offspring=new Vector<>();
        
        ///Actual Iteration Components X-Over, Mutation etc
        for (int z=0;z<populations.size();z++)
        {
            for(int i=0;i<populations.get(z).individuals.size();i++)
            {
                ///Mutation
                trialVector.clear();
                x1=i;
                x2=0;
                x3=0;
                
                while(x1==x2 || x2==x3 || x1==x3)
                {
                    x2=ThreadLocalRandom.current().nextInt(populations.get(z).individuals.size());
                    x3=ThreadLocalRandom.current().nextInt(populations.get(z).individuals.size());
                }
                
                for (int h=0;h<populations.get(z).individuals.get(i).dimensions;h++)
                {
                    trialVector.add(populations.get(z).individuals.get(x1).positionVector.get(h)
                            +B*((populations.get(z).individuals.get(x2).positionVector.get(h))
                            -populations.get(z).individuals.get(x3).positionVector.get(h)));
                }
                
                
                ///CrossOver
                ///0 equals parents, 1 equals trial vector
                crossovervector.clear();
                for (int x=0;x<populations.get(z).individuals.get(i).positionVector.size();x++)
                {
                    crossovervector.add(0);
                }
                int randS=ThreadLocalRandom.current().nextInt(populations.get(z).individuals.get(i).positionVector.size());
                crossovervector.set(randS,1);
                
                double tmpChance;
                
                for (int jj=0;jj<crossovervector.size();jj++)
                {
                    tmpChance=ThreadLocalRandom.current().nextDouble();
                    if (tmpChance<pr && jj!=randS)
                    {
                        crossovervector.set(jj, 1);
                    }
                    
                }
                offspring.clear();
                BigDecimal tmpFitness;
                
                for (int jj=0;jj<crossovervector.size();jj++)
                {
                    if (crossovervector.get(jj)==0)
                    {
                        offspring.add(populations.get(z).individuals.get(i).positionVector.get(jj));
                    } else 
                        {
                            offspring.add(trialVector.get(jj));
                        }
                }
                
                tmpFitness=obFun.functionEvaluation(offspring);
                
                
                if (tmpFitness.compareTo(populations.get(z).individuals.get(i).fitnessEvaluation)<0 &&
                        varsInRange(offspring,range)==true)
                {
                   
                   populations.get(z).individuals.get(i).setPositionVector(offspring);
                   populations.get(z).individuals.get(i).fitnessEvaluation=tmpFitness;
                }
            }
        }
        
        
    }
    
    boolean varsInRange(Vector<Double> vars,double [] range)
    {
        for(int i=0;i<vars.size();i++)
        {
            if (vars.get(i)<range[0] || vars.get(i)>range[1]) return false;
        }
        return true;
    
    }
    
    
    void performDEExperiment() throws FileNotFoundException, UnsupportedEncodingException
    {
        BigDecimal [] runData=new BigDecimal[30];
        strategyIndicator=0;
        //int []dimArry={50,100,150,200,250,300,350,400,450,500,600,700,800,900,1000};
        
        int []dimArry={1000,800,700,500,400,300,200,100,50};
        System.out.println("Running DE Experiment: DE/bin/rand/1");
        for (int i=0;i<8;i++)
        {
            BigDecimal s;
            switchFunction(i);
            functionIndicator=i;
            System.out.println("Current Function Indicator:" +DataGatherer.getFunctionName(i));
            System.out.println("Current Dimension Lower Bound:"+obFun.getRange()[0]);
            System.out.println("Current Dimension Upper Bound:"+obFun.getRange()[1]);
            System.out.println("======================================================================");
            for (int j=0;j<dimArry.length;j++)
            {
                dimensionIndicator=j;
                ///Initialise Parameters for Experiment
                System.out.println("Current Dimmension Indicator: "+DataGatherer.getDimension(j));
                for (int k=0;k<30;k++)
                {
                    System.out.println("Current Run Indicator: "+k);
                    ///Clear and initialise populations according to strategy
                    populations=null;
                    contextVector.clear();
                    populations=new Vector<>();
                    populations.add(new Population());
                    contextVector.setSize(dimArry[dimensionIndicator]);
                    populations.get(0).B=1;
                    populations.get(0).pr=0.3;
                    
                    //Put values found here
                    ///Logic Regarding changing parameters
                    /*
                    Changing parameters should be done on a per run basis.
                    */
                    
                    ///Do the initial prime for the groupings for the dimension assignments
                    Vector<Integer> dimTmp=new Vector<>();
                    for (int hh=0;hh<contextVector.size();hh++)
                    {
                        contextVector.set(hh,0.0);
                        dimTmp.add(hh);
                    }
                    populations.get(0).initialisePopulation(dimArry[dimensionIndicator],
                            getDimensions(i), B, pr,dimTmp);
                    

                    
                    
                    for (int it=0;it<5000;it++)
                    {
                        ///Strategy logic regarding changing parameters
                        ///Strategy logic regarding new populations
                        doIteration(getDimensions(i));
                        //populations.get(0).B=populations.get(0).B-((1.0-0.7)/5000);
                        //populations.get(0).pr=populations.get(0).pr+((0.5-0.3)/5000);;
                    }
                    //Get best from that run.
                    ////Add best to list
                    
                    BigDecimal bestFit=populations.get(0).individuals.get(0).fitnessEvaluation;;
                   
                    for (int y=0;y<30;y++)
                    {
                        if (obFun.functionEvaluation(populations.get(0).individuals.get(y).getVector()).compareTo(bestFit)<0)
                        {
                           
                            bestFit=obFun.functionEvaluation(populations.get(0).individuals.get(y).getVector());
                        }
                    }
                    
                    runData[k]=bestFit;
                }
                ///Data Reader creating a run file
                System.out.println("======================================================================");
                DataGatherer.createRunDataFile(functionIndicator, dimensionIndicator, strategyIndicator, runData);
            }
        }
        
    }
}
