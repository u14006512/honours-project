
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Warmaster
 */
public class DataGatherer {
 public static void createRunDataFile(int funInd,int dimsInd,int stratInd,BigDecimal [] runs30BestValues) throws FileNotFoundException, UnsupportedEncodingException
 {
    String filename=getStrategyName(stratInd)+"_"+getFunctionName(funInd)+"_"+getDimension(dimsInd)+".txt";
    
    
    PrintWriter writer = new PrintWriter(filename, "UTF-8");

    for (int i=0;i<runs30BestValues.length;i++)
    {
    writer.println(String.valueOf(runs30BestValues[i]));
    }
    writer.close();
 }   
 public static String getFunctionName(int f)
 {
     String s = null;
     switch (f)
     {
        case 0: s="Alpine";
            break;
        case 1:s="EggHolder";
            break;
        case 2:s="Griewank";
            break;
        case 3:s="Salomon";
            break;
        case 4:s="Rosenbrock";
            break;
        case 5:s="Schaffer6";
            break;
        case 6:s="Vincent";
            break;
        case 7:s="Weierstrass";
            break;    
     }
     return s;
 }
 public static String getStrategyName(int f)
 {
     
     String s = null;
     switch (f)
     {
        case 0: s="DE_Rand_bin_1";
            break;
        case 1:s="Basic_Cooperative_DE";
            break;
        case 2:s="Random_Group_CO_DE";
            break;
        case 3:s="Random_Group_CO_DE_Overlap";
            break;
        case 4:s="Decomp_CO_DE";
            break;
        case 5:s="Decomp_CO_DE_Random_Group";
            break;
        case 6:s="Merge_CO_DE";
            break;
        case 7:s="Merge_CO_DE_Random_Group";
            break;
        case 8:s="Other_Strategy";
            break;
     }
     return s;
 }
 public static String getDimension(int f)
 {
     String s = null;
     switch (f)
     {
        case 0: s="1000";
            break;
        case 1:s="800";
            break;
        case 2:s="700";
            break;
        case 3:s="500";
            break;
        case 4:s="400";
            break;
        case 5:s="300";
            break;
        case 6:s="200";
            break;    
        case 7:s="100";
            break;    
        case 8:s="50";
            break;    
     }
     return s;
 }
}
