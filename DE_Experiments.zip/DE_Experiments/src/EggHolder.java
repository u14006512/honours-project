
import java.math.BigDecimal;
import java.util.Vector;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Warmaster
 */
public class EggHolder extends ObjectiveFunction {
    
    public  BigDecimal functionEvaluation(Vector<Double> inputs) {
        BigDecimal result=new BigDecimal(0);    
        BigDecimal t;
        for(int i=0;i<inputs.size()-1;i++)
        {
            t=new BigDecimal((-(inputs.get(i+1)+47)*
                    Math.sin(Math.sqrt(Math.abs(inputs.get(i+1)+inputs.get(i)/2.0+47))))
                    +((Math.sin(Math.sqrt(Math.abs(inputs.get(i)-(inputs.get(i+1)+47)))))*(-inputs.get(i))));
            result=result.add(t);
        }
        
        return result;
    }

    
    public  double[] getRange() {
        double s[]={-512,512};
    return s;
    }
}
