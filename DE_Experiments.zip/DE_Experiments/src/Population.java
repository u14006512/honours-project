
import java.math.BigDecimal;
import java.util.Vector;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Warmaster
 */
public class Population {
    int currentBestPopBestIndividualIndex;
    Vector<Individual> individuals;
    int currentObjectiveFunction;
    
    int sizeOfDimensionComponent;
    double B,pr;
    
    
    Vector<Integer> dimensionComponents;

    public Population() {
        currentObjectiveFunction=0;
        currentBestPopBestIndividualIndex=-1;
        sizeOfDimensionComponent=0;
        
        individuals=new Vector<>();
        dimensionComponents=new Vector<>();
        B=0;
        pr=0;
    }
    
    void setObjectiveFunction(int o)
    {
        currentObjectiveFunction=o;
    }
    
    void setPr(double p)
    {
        pr=p;
    }
    
    void setB(double b)
    {
       B=b; 
    }
    
    double getB()
    {
        return B;
    }
    
    double getPr()
    {
        return pr;
    }
    void initialisePopulation(int dimensions,double [] dimensionBounds,double b,double pR,Vector<Integer> dimensionComp)
    {
        for (int i=0;i<30;i++)
        {
            individuals.add(new Individual(dimensions,dimensionBounds));
        }
        sizeOfDimensionComponent=dimensions;
        B=b;
        pr=pR;
        for (int i=0;i<dimensionComp.size();i++)
        {
            dimensionComponents.add(dimensionComp.get(i));
        }
    }
    
    ///side is as follows -1=Left,0=Full Copy, 1=Right
    void copyPopulation(Vector<Individual> p,double b,double pR, int dims, int crBest,Vector<Integer> dimComps, int side)
    {
        B=b;
        pr=pR;
        sizeOfDimensionComponent=dims;
        currentBestPopBestIndividualIndex=crBest;
        
        dimensionComponents.clear();
        
        for (int i=0;i<dimComps.size();i++)
        {
            dimensionComponents.add(dimComps.get(i));
        }
        Vector<Double> tmpPos=new Vector<>();
        individuals.clear();
        for(int i=0;i<p.size();i++)
        {
            individuals.add(new Individual());
            tmpPos.clear();
            switch (side) {
                case -1:
                    for (int j=0;j<p.get(i).positionVector.size()/2;j++)
                    {
                        tmpPos.add(p.get(i).positionVector.get(j));
                    }
                    break;
                case 0:
                    for (int j=0;j<p.get(i).positionVector.size();j++)
                    {
                        tmpPos.add(p.get(i).positionVector.get(j));
                    }
                    break;
                case 1:
                    for (int j=p.get(i).positionVector.size()/2;j<p.get(i).positionVector.size();j++)
                    {
                        tmpPos.add(p.get(i).positionVector.get(j));
                    }
                    break;
            
            }
            individuals.get(i).copyIndividual(dims, 
                    p.get(i).fitnessEvaluation, tmpPos);
            tmpPos.clear();
        }
    }    
    
    void updateContextVector(Vector<Double> contextVector)
    {
        for (int i=0;i<sizeOfDimensionComponent;i++)
        {
            contextVector.set(dimensionComponents.get(i), 
                    individuals.get(currentBestPopBestIndividualIndex).positionVector.get(i));
        }
    }
    Vector<Double> getPopulationBestVector()
    {
        return individuals.get(currentBestPopBestIndividualIndex).positionVector;
    }
    
    void setDimensionComponents(Vector<Integer> dimComps)
    {
        dimensionComponents.clear();
        
        for (int i=0;i<dimComps.size();i++)
        {
            dimensionComponents.add(dimComps.get(i));
        }
    }
    
}
