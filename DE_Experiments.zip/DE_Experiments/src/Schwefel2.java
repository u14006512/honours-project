
import java.math.BigDecimal;
import java.util.Vector;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Warmaster
 */
public class Schwefel2 extends ObjectiveFunction{
    
    public BigDecimal functionEvaluation(Vector<Double>inputs) {
        BigDecimal result=new BigDecimal(0);    
        BigDecimal result2=new BigDecimal(1);
        BigDecimal finalResult=new BigDecimal(0);
        
        for(int i=0;i<inputs.size();i++)
        {
            result=result.add(new BigDecimal(Math.abs(inputs.get(i))));
        }
        
        for(int i=0;i<inputs.size();i++)
        {
            result2=result2.multiply(new BigDecimal(Math.abs(inputs.get(i))));
        }
        
        finalResult=finalResult.add(result.add(result2));
        
        return finalResult;
    }

    
    public double[] getRange() {
        double s[]={-10,10};
    return s;
    }
}
