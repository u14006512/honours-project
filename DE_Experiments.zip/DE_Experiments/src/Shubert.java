
import java.math.BigDecimal;
import java.util.Vector;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Warmaster
 */
public class Shubert extends ObjectiveFunction {
    public BigDecimal functionEvaluation(Vector<Double>inputs) {
        BigDecimal result=new BigDecimal(1.0);    
        double com1=0.0;
        
        for (int j=0;j<inputs.size();j++)
        {
            com1=0.0;
         for(int i=1;i<=5;i++)
         {
             com1=com1+(i*Math.cos((i+1)*inputs.get(j)+i));
         }   
         result=result.multiply(new BigDecimal(com1));   
        }
        return result;
    }
    public double[] getRange() {
        double s[]={-10,10};
    return s;
    }
    
    
}
