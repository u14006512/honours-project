/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.Vector;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Warmaster
 */
public class IndividualTest {
    
    public IndividualTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of setDimensions method, of class Individual.
     */
    @Test
    public void testSetDimensions() {
        System.out.println("setDimensions");
        int d = 0;
        double [] dd={-5,5};
        Individual instance = new Individual(5,dd);
        instance.setDimensions(10);
        // TODO review the generated test code and remove the default call to fail.
        assertEquals(instance.dimensions, 10);
    }

    /**
     * Test of getDimensions method, of class Individual.
     */
    @Test
    public void testGetDimensions() {
        System.out.println("getDimensions");
        double [] dd={-5,5};
        Individual instance = new Individual(5,dd);
        int expResult = 5;
        int result = instance.getDimensions();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        
    }

    /**
     * Test of resetPositions method, of class Individual.
     */
    @Test
    public void testResetPositions() {
        System.out.println("resetPositions");
        double [] dd={-5,5};
        Individual instance = new Individual(5,dd);
        instance.resetPositions();
        assertEquals(instance.positionVector.size(), 0);
        // TODO review the generated test code and remove the default call to fail.
        
    }

    /**
     * Test of setPositionVector method, of class Individual.
     */
    @Test
    public void testSetPositionVector() {
        System.out.println("setPositionVector");
        Vector<Double> in=new Vector<>();
        in.add(3.0);
        in.add(7.0);
        double [] dd={-5,5};
        Individual instance = new Individual(5,dd);
        instance.setPositionVector(in);
        assertEquals(instance.positionVector, in);
        // TODO review the generated test code and remove the default call to fail.
        
    }

    /**
     * Test of getPositionFromVector method, of class Individual.
     */
    @Test
    public void testGetPositionFromVector() {
        System.out.println("getPositionFromVector");
        int i = 0;
        double [] dd={-10,-5};
        Individual instance = new Individual(5,dd);
        double expResult = 0.0;
        double result = instance.getPositionFromVector(i);
        assertNotEquals(expResult, result, 0.0);
        // TODO review the generated test code and remove the default call to fail.
        
    }

    /**
     * Test of getVector method, of class Individual.
     */
    @Test
    public void testGetVector() {
        System.out.println("getVector");
        double [] dd={-5,5};
        Individual instance = new Individual(5,dd);
        Vector<Double> expResult =null;
        Vector<Double> result = instance.getVector();
        assertNotEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        
    }

    /**
     * Test of setPos method, of class Individual.
     */
    @Test
    public void testSetPos() {
        System.out.println("setPos");
        int in = 0;
        double val = 0.0;
        double [] dd={-5,5};
        Individual instance = new Individual(5,dd);
        instance.setPos(in, val);
        
        // TODO review the generated test code and remove the default call to fail.
        
    }
    
}
