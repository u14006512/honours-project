/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.math.BigDecimal;
import java.util.Vector;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Warmaster
 */
public class NorwegianTest {
    
    public NorwegianTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of functionEvaluation method, of class Norwegian.
     */
    @Test
    public void testFunctionEvaluation() {
        System.out.println("functionEvaluation");
     
        Vector<Double> inputs=new Vector<>();
        for (int i=0;i<100;i++)
        {
            inputs.add(0.50);
        }
        Norwegian instance = new Norwegian();
        double expResult = 0.0;
       BigDecimal result = instance.functionEvaluation(inputs);
      System.out.println("Norwegian: "+result);
    }

    /**
     * Test of getRange method, of class Norwegian.
     */
    @Test
    public void testGetRange() {
        System.out.println("getRange");
        Norwegian instance = new Norwegian();
        double[] expResult = null;
        double[] result = instance.getRange();
        
        
    }
    
}
