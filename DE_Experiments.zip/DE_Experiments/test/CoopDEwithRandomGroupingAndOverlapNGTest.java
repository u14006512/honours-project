/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.Vector;
import static org.testng.Assert.*;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

/**
 *
 * @author Warmaster
 */
public class CoopDEwithRandomGroupingAndOverlapNGTest {
    
    public CoopDEwithRandomGroupingAndOverlapNGTest() {
    }

    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }

    @BeforeMethod
    public void setUpMethod() throws Exception {
    }

    @AfterMethod
    public void tearDownMethod() throws Exception {
    }

    /**
     * Test of performDEExperiment method, of class CoopDEwithRandomGroupingAndOverlap.
     */
    @Test
    public void testPerformDE() throws Exception {
        System.out.println("performDEExperiment");
        CoopDEwithRandomGroupingAndOverlap instance = new CoopDEwithRandomGroupingAndOverlap();
        instance.performDE();
        // TODO review the generated test code and remove the default call to fail.
    }
    
    @Test
    public void testPO() throws Exception {
        System.out.println("performDEExperiment");
        CoopDEwithRandomGroupingAndOverlap instance = new CoopDEwithRandomGroupingAndOverlap();
        int k=0;
        
        double res=CoopDEwithRandomGroupingAndOverlap.poFunctions(k);
        
        System.out.println(res);
        // TODO review the generated test code and remove the default call to fail.
    }
    
}
