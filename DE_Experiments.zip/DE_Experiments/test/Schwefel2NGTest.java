/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.math.BigDecimal;
import java.util.Vector;
import static org.testng.Assert.*;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

/**
 *
 * @author Warmaster
 */
public class Schwefel2NGTest {
    
    public Schwefel2NGTest() {
    }

    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }

    @BeforeMethod
    public void setUpMethod() throws Exception {
    }

    @AfterMethod
    public void tearDownMethod() throws Exception {
    }

    /**
     * Test of functionEvaluation method, of class Schwefel2.
     */
    @Test
    public void testFunctionEvaluation() {
        System.out.println("functionEvaluation");
        Vector<Double> inputs=new Vector<>();
        for (int i=0;i<1000;i++)
        {
            inputs.add(10.0);
        }
        Schwefel2 instance = new Schwefel2();
        BigDecimal expResult = null;
        BigDecimal result = instance.functionEvaluation(inputs);
        System.out.println("Schwefel: "+result);
    }

    
}
