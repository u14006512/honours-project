/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Warmaster
 */
public class WeierstrassTest {
    
    public WeierstrassTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of functionEvaluation method, of class Weierstrass.
     */
    @Test
    public void testFunctionEvaluation() {
        System.out.println("functionEvaluation");
        double[] inputs = {0,0};
        Weierstrass instance = new Weierstrass();
        double expResult = 0.1;
     //   double result = instance.functionEvaluation(inputs);
    //    System.out.println("Weierstrass: "+result);
    }

    /**
     * Test of getRange method, of class Weierstrass.
     */
    @Test
    public void testGetRange() {
        System.out.println("getRange");
        Weierstrass instance = new Weierstrass();
        double[] expResult = null;
        double[] result = instance.getRange();
               
    }
    
}
