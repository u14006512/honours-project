/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.math.BigDecimal;
import java.util.Vector;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Warmaster
 */
public class VincentTest {
    
    public VincentTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of functionEvaluation method, of class Vincent.
     */
    @Test
    public void testFunctionEvaluation() {
        System.out.println("functionEvaluation");
        Vector<Double> inputs=new Vector<>();
        for (int i=0;i<1000;i++)
        {
            inputs.add(10.0);
        }
        Vincent instance = new Vincent();
        double expResult = 0.0;
        BigDecimal result = instance.functionEvaluation(inputs);
       System.out.println("Vincent: "+result);
    }

    /**
     * Test of getRange method, of class Vincent.
     */
    @Test
    public void testGetRange() {
        System.out.println("getRange");
        Vincent instance = new Vincent();
        double[] expResult = null;
        double[] result = instance.getRange();
       
    }
    
}
