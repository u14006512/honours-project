/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.Vector;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Warmaster
 */
public class PopulationTest {
    
    public PopulationTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of setObjectiveFunction method, of class Population.
     */
    @Test
    public void testSetObjectiveFunction() {
        System.out.println("setObjectiveFunction");
        int o = 0;
        Population instance = new Population();
        instance.setObjectiveFunction(o);
        // TODO review the generated test code and remove the default call to fail.
        
    }

    /**
     * Test of setPr method, of class Population.
     */
    @Test
    public void testSetPr() {
        System.out.println("setPr");
        double p = 0.0;
        Population instance = new Population();
        instance.setPr(p);
        // TODO review the generated test code and remove the default call to fail.
        
    }

    /**
     * Test of setB method, of class Population.
     */
    @Test
    public void testSetB() {
        System.out.println("setB");
        double b = 0.0;
        Population instance = new Population();
        instance.setB(b);
        // TODO review the generated test code and remove the default call to fail.
        
    }

    /**
     * Test of getB method, of class Population.
     */
    @Test
    public void testGetB() {
        System.out.println("getB");
        Population instance = new Population();
        double expResult = 0.0;
        double result = instance.getB();
        assertEquals(expResult, result, 0.0);
        // TODO review the generated test code and remove the default call to fail.
        
    }

    /**
     * Test of getPr method, of class Population.
     */
    @Test
    public void testGetPr() {
        System.out.println("getPr");
        Population instance = new Population();
        double expResult = 0.0;
        double result = instance.getPr();
        assertEquals(expResult, result, 0.0);
        // TODO review the generated test code and remove the default call to fail.
        
    }

    /**
     * Test of initialisePopulation method, of class Population.
     */
    @Test
    public void testInitialisePopulation() {
        System.out.println("initialisePopulation");
        int dimensions = 0;
        double[] dimensionBounds = null;
        double b = 0.0;
        double pR = 0.0;
        Population instance = new Population();
       // instance.initialisePopulation(dimensions, dimensionBounds, b, pR);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of produceTrialVector method, of class Population.
     */
    
}
