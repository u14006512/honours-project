import Pyro4
import subprocess
import sys
import time
import psutil
import os
import json
import hashlib


@Pyro4.expose
@Pyro4.behavior(instance_mode="session")
class pirate(object):
    listOfCrew = []
    results = []
    asyncCrew = []
    personalID = ""
    quarterMaster = False
    clues=[]
    mapData={}
    def __init__(self):
        self.personalID = sys.argv[1]
        self.listOfCrew = []
        self.asyncCrew = []

    # solve the clue
    def doWork(self, clue):
        m = hashlib.md5()
        clueC = ""
        clueA = self.digInTheSand(clue)
        clueB = self.searchTheRiver(clueA)
        clueC = self.crawlIntoCave(clueB)
        m.update(clueC.encode())
        clueD = str(m.hexdigest())

        clueE = clueD.upper()
        return str(clueE)

    """
    my_str = "hello world"
    bytes = str.encode(my_str)
    type(bytes) # ensure it is byte representation
    my_decoded_str = str.decode(bytes)
    type(my_decoded_str) # ensure it is string representation
    """

    # crawl into the cave
    def crawlIntoCave(self, clue):
        for i in range(200):
            clue = self.rope(clue)
        for i in range(100):
            clue = self.torch(clue)
        return str(clue)

    # search the river
    def searchTheRiver(self, clue):
        for i in range(200):
            clue = self.bucket(clue)
        return str(clue)

    # dig in the sand
    def digInTheSand(self, clue):
        for i in range(100):
            clue = self.shovel(clue)
        for i in range(200):
            clue = self.bucket(clue)
        for i in range(100):
            clue = self.shovel(clue)
        return str(clue)

    # bucket

    def bucket(self, clue):
        lm = list(clue)
        for i, c in enumerate(lm):
            if (str(lm[i]).isdigit() == True):
                if (int(lm[i]) > 5):
                    lm[i] = str(int(lm[i]) - 2)
                elif (int(lm[i]) <= 5):
                    lm[i] = str(int(lm[i]) * 2)
        return str("".join(lm))

    # torch
    def torch(self, clue):
        # lm=list(clue)
        x = 0
        for i, c in enumerate(clue):
            if (str(clue[i]).isdigit() == True):
                x = x + int(clue[i])

        if (x < 100):
            x = x * x
        c = str(x)
        if (len(c) < 10):
            c = c[1:]
            c = "F9E8D7" + c
        else:
            c = c[6:]
            c = c + "A1B2C3"
        return str(c)

    # rope
    def rope(self, clue):
        lm = list(clue)
        for i, c in enumerate(lm):
            if (str(lm[i]).isdigit() == True):
                if (int(lm[i]) % 3 == 0):
                    lm[i] = "5"
                elif (int(lm[i]) % 3 == 1):
                    lm[i] = "A"
                elif (int(lm[i]) % 3 == 2):
                    lm[i] = "B"
            else:
                tm = 0
                if lm[i] == "A":
                    tm = "0"
                if lm[i] == "B":
                    tm = "1"
                if lm[i] == "C":
                    tm = "2"
                if lm[i] == "D":
                    tm = "3"
                if lm[i] == "E":
                    t = "4"
                if lm[i] == "F":
                    tm = "5"

                if (int(tm) % 5 == 0):
                    lm[i] = "C"
                elif (int(tm) % 5 == 1):
                    lm[i] = "1"
                elif (int(tm) % 5 == 2):
                    lm[i] = "2"
                else:
                    lm[i] = str(lm[i])
        return str("".join(lm))

    # shovel
    def shovel(self, clue):
        clue = ''.join(sorted(clue))
        t = clue[1]
        if (t.isdigit() == True):
            clue = clue + "0A2B3C"
        else:
            clue = clue + "1B2C3D"
        clue = clue[1:]
        return clue

    def addCrew(self, listOfCrew):
        for i in listOfCrew:
            subprocess.Popen(["py", "pirate-AsynchronousBatch.py", str(i)], shell=True)
            time.sleep(10)

        for i in listOfCrew:
            self.asyncCrew.append(Pyro4.batch(proxy=Pyro4.Proxy("PYRONAME:" + str(i))))

        print("Crew's ready to go")
        print(self.listOfCrew)

    def removeCrew(self, crewId):
        pos = self.listOfCrew.index(crewId)
        temp = self.pids[pos]

        if (pos > -1):
            self.asyncCrew.pop(pos)
            self.listOfCrew.pop(pos)

            for (proc) in psutil.process_iter():
                if (proc.personalID == temp):
                    # need to check process killing on linux
                    os.system("taskkill /f /PID " + str(temp))
            print("Crewman removed")
            print("current crew: " + str(len(self.listOfCrew)))
            # TELL RUMMY THE CREW MEMBER IS REMOVED
        else:
            print("Couldn't find that crewman")


def main():
    p = pirate()

    print("Pirate:" + p.personalID + " reporting for duty")
    Pyro4.config.NS_AUTOCLEAN = 60.0
    Pyro4.config.THREADPOOL_SIZE = 1000
    Pyro4.config.MAX_RETRIES = 1

    if (p.quarterMaster == False and p.personalID == "pirate0"):

        print("Quartermaster reporting for duty")
        p.quarterMaster=True
        #subprocess.call(["py", "-m", "Pyro4.naming"], shell=True)

        daemon=Pyro4.Daemon()
        uri=daemon.register(p)
        ns=Pyro4.locateNS(host="localhost",port=9090)
        ns.register("quartermaster",uri)
        numProc=psutil.cpu_count()
        numPiratesToMake=(numProc)
        #numPiratesToMake = (numProc * 5)
        numPiratesToMake=20
        print(subprocess.check_output(["py", "rummy.pyc", "-w"], shell=True))
        print(subprocess.check_output(["py", "rummy.pyc", "-u"], shell=True))
        print(subprocess.check_output(["py", "rummy.pyc", "-p"], shell=True))
        print("We're ready to get crew")

        stopProcess=False
        strA = json.loads(subprocess.check_output(["py", "rummy.pyc", "-a", str(numPiratesToMake)]))
        for count in range(numPiratesToMake):
            print("ID:" + str((strA["data"][count])))
            p.listOfCrew.append(strA["data"][count])
        p.addCrew(p.listOfCrew)
        print("Crew Asssembled ")
        print("Gathering Clues")

        subprocess.check_output(["py", "rummy.pyc", "-s"])
        p.mapData=json.loads(subprocess.check_output(["py", "rummy.pyc", "-c"]))
        print("Length of entire object" + str(len(p.mapData)))

        for i in range(numPiratesToMake):
            nC=len(p.mapData["data"][i]["data"])

            for j in range(nC):
                p.clues.append(str(p.mapData["data"][i]["data"][j]["data"]))

        print("Number of clues:"+str(len(p.clues)))
        numClues=len(p.clues)
        #clues loaded
        file=open("clues.txt","w")
        for i in range(len(p.clues)):
            file.write("\n")
            file.write(str(i)+":"+p.clues[i])
            file.write("\n")

        file.close()
        numJobs=[]
        clueIDs=[]
        pCluesArr=[]
        listOfWorkers=[]
        numFailures=[]
        p.results=[]
        failedList=[]
        tmpID=""
        useAsync=True
        runFailedClues=False
        #Next map is unlocked when verify string has no clues || 4 attributes
        print("Starting Solving")
        while (stopProcess==False):
            #while we have clues
            p.results=[]
            numJobs=[]
            print("Solving Clues")
            piratesWorking=0
            currP = 0
            clueIDs=[]
            pCluesArr=[]
            while (len(p.clues)!=0):
                print("Starting Clue Solving")
                numJobs=[]
                piratesWorking=0
                numClues=len(p.clues)
                print("Current Cluework Load:" +str(numClues))
                if (useAsync==False or numClues<numPiratesToMake):
                    numJobs.append(numClues)
                    piratesWorking=1
                else:
                    if (numClues % numPiratesToMake == 0):
                        for h in range(len(p.asyncCrew)):
                            numJobs.append(int(numClues /numPiratesToMake))
                    else:
                        for h in range(len(p.asyncCrew) - 1):
                            numJobs.append(int(numClues / numPiratesToMake))
                        totalV=int(numClues / numPiratesToMake) * (numPiratesToMake-1)
                        totalV=numClues-totalV
                        numJobs.append(totalV)
                    piratesWorking=numPiratesToMake
                count=0

                if useAsync==True:
                    tmp = []
                    p.results=[]
                    for i in range(piratesWorking):
                        for j in range(numJobs[i]):
                            p.asyncCrew[i].doWork(p.clues[count])
                            count += 1
                        tmp.append(p.asyncCrew[i](async =True))

                    for i in range(len(tmp)):
                        tmp[i].wait()
                    p.results=[]
                    for i in range(len(tmp)):
                        for r in tmp[i].value:
                            p.results.append(str(r))
                    p.asyncCrew=[]
                    for i in p.listOfCrew:
                        p.asyncCrew.append(Pyro4.batch(proxy=Pyro4.Proxy("PYRONAME:" + str(i))))
                    print("Number of Results Async:"+str(len(p.results)))
                else:
                    count=0
                    min=1000
                    index=0
                    p.results=[]
                    for i in range(len(listOfWorkers)):
                        if numFailures[i]<min:
                            min=numFailures[i]
                            index=i
                    numFailures=[]
                    tmpQQ=[]
                    print("Number of No-Async Clues to process:"+str(len(p.clues)))
                    for t in range(len(pCluesArr)):
                        for q in range(pCluesArr[t]):
                            p.asyncCrew[listOfWorkers[index]].doWork(p.clues[count])
                            count += 1
                    tmpQQ.append(p.asyncCrew[listOfWorkers[index]]())
                    for w in tmpQQ[0]:
                        p.results.append(w)
                    listOfWorkers=[]
                    print("Number of Results No-Async:" + str(len(p.results)))
                    p.clues=[]
                    useAsync=False
                print("Number of pirates working:"+str(piratesWorking))
                print("Waiting for Pirates to finish work")


                tmpClues=[]
                count=0
                failedList=[]
                numFailures=[]

                print("Now to prep for rummy")
                if runFailedClues==False:
                    itVal=len(p.asyncCrew)
                else:
                    itVal=1
                print("Number of Clues to verify"+str(len(p.results)))

                for i in range(itVal):
                    if runFailedClues==False:
                        resultStr = {}
                        resultStr["id"] = p.mapData["data"][i]["id"]
                        numClues = len(p.mapData["data"][i]["data"])
                        resultStr["data"] = []
                        for j in range(numClues):
                            resultStr["data"].append({})
                            resultStr["data"][j]["id"] = p.mapData["data"][i]["data"][j]["id"]
                            resultStr["data"][j]["key"] = str(p.results[count])
                            count += 1
                    else:
                        resultStr = {}
                        resultStr["id"] = tmpID
                        numClues = pCluesArr[i]
                        resultStr["data"] = []
                        for j in range(numClues):
                            resultStr["data"].append({})
                            resultStr["data"][j]["id"] = clueIDs[count]
                            resultStr["data"][j]["key"] = str(p.results[count])
                            count += 1

                    print("Clues loaded and ready for Pirate: "+str(i))
                    resultStr=repr(resultStr)
                    #resultStr = json.dumps(resultStr))
                    str1 = subprocess.check_output(["py", "rummy.pyc", "-v", resultStr], shell=True)
                    res = json.loads(str1)
                    print("Checking Result")
                    if (len(res) == 3 and  str(res["status"])=="success"):
                        stopProcess=True
                        runFailedClues=False
                        print(str(res))
                        p.clues=[]
                    if len(res) == 2 and str(res["status"])=="success":
                        print(str(res))
                        1
                    if len(res) == 3 and str(res["status"])=="error":
                        #recycle old clues
                        print(str(res))
                        failedList.append(res)
                        listOfWorkers.append(i)
                        nC = len(res["data"][0]["data"])
                        print("Number of Failures Reported by a Pirate:"+str(len(res["data"][0]["data"])))
                        numFailures.append(len(res["data"][0]["data"]))
                        for j in range(nC):
                            tmpClues.append(str(res["data"][0]["data"][j]["data"]))
                # Get new clues from rummy
                if (stopProcess==False and len(failedList)==0 and len(tmpClues)==0):
                    p.results=[]
                    runFailedClues=False
                    p.clues = []
                    p.mapData = {}
                    p.mapData = json.loads(subprocess.check_output(["py", "rummy.pyc", "-c"]))
                    print(p.mapData)
                    print("Length of entire object" + str(len(p.mapData)))
                    for i in range(numPiratesToMake):
                        nC = len(p.mapData["data"][i]["data"])

                        for j in range(nC):
                            p.clues.append(str(p.mapData["data"][i]["data"][j]["data"]))

                    print("New Clues:" + str(len(p.clues)))
                    numClues = len(p.clues)

                    useAsync=True
                    runFailedClues=False
                if stopProcess==False and len(tmpClues)!=0 and len(failedList)!=0:

                    p.results=[]
                    runFailedClues=True
                    p.clues=[]
                    iC=0
                    clueIDs=[]
                    pCluesArr=[]
                    useAsync=False
                    tmpID=failedList[0]["data"][0]["id"]
                    for i in range(len(tmpClues)):
                        p.clues.append(tmpClues[iC])
                        iC=iC+1

                    for i in range(len(failedList)):
                        w=len(failedList[i]["data"][0]["data"])
                        pCluesArr.append(len(failedList[i]["data"][0]["data"]))
                        for j in range(w):
                            clueIDs.append(failedList[i]["data"][0]["data"][j]["id"])
                            #p.clues.append(failedList[i]["data"][0]["data"][j]["data"])
                    print("Total Number of Failed Clues:" + str(len(p.clues)))
                currP = currP + 1
        print("Done Searching for clues Matey")
        stopProcess=True
        for i in range(len(p.asyncCrew)):
            p.asyncCrew[i]._pyroRelease()
        daemon.shutdown()
    else:
        print("I'm just a pirate:"+p.personalID)
        Pyro4.Daemon.serveSimple(
            {
                pirate: p.personalID
            }
            , ns=True
        )
main()
