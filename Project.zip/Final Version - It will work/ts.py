import subprocess
import json
stra=subprocess.check_output(["py", "-m", "Pyro4.nsc","list"], shell=True)

stra.split(" ")
print(stra)