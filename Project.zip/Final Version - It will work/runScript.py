import subprocess
import psutil
import json
import time
prCount=psutil.cpu_count()
pirates=(prCount*5) +1
a=subprocess.Popen(["py", "-m", "Pyro4.naming"], shell=True)
strA = json.loads(subprocess.check_output(["py", "rummy.pyc", "-a", str(pirates)]))
listOfPirates=[]
listOfPids=[]
pirateIDS=[]
for i in range(pirates-1):
    pirateIDS.append(str(strA["data"][i]))
for i in range(pirates-1):
        listOfPirates.append(subprocess.Popen(["py", "pirate-AsynchronousBatch.py", str((strA["data"][i])),"",""], shell=True))
        time.sleep(5)
for i in range(pirates-1):
    listOfPids.append(listOfPirates[i].pid)
strg=""
strH=""
for i in range(len(listOfPids)):
    strg=strg+str(listOfPids[i])+";"
for i in range((pirates)-1):
    strH=strH+str(pirateIDS[i])+"#"
strg=strg+str(a.pid)
subprocess.call(["py", "pirate-AsynchronousBatch.py","pirate0",strg,strH], shell=True)

