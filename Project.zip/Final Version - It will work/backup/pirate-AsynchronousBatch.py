import Pyro4
import subprocess
import sys
import time
import signal
import psutil
import os
import json
import hashlib

def kill(proc_pid):
    process = psutil.Process(proc_pid)
    for proc in process.children(recursive=True):
        proc.kill()
    process.kill()

@Pyro4.expose
@Pyro4.behavior(instance_mode="session")
class pirate(object):
    localResults=[]
    listOfCrew = []
    results = []
    asyncCrew = []
    personalID = ""
    quarterMaster = False
    clues=[]
    mapData={}
    pIDs=[]
    cluesCleared=0
    def __init__(self):
        self.personalID = sys.argv[1]
        self.listOfCrew = []
        self.asyncCrew = []

    def addLocalClue(self,clue):
        self.localResults.append(clue)
    def getProgress(self):
        return self.cluesCleared
    def getLocalRes(self):
        return self.localResults
    def clearLocalRes(self):
        self.cluesCleared=0
        self.localResults=[]
    # solve the clue
    def doWorkNoSync(self,clue):
        m = hashlib.md5()
        clueA = self.digInTheSand(clue)
        clueB = self.searchTheRiver(clueA)
        clueC = self.crawlIntoCave(clueB)
        m.update(clueC.encode())
        clueD = str(m.hexdigest())
        clueE = clueD.upper()
        return str(clueE)
    def doWork(self):
        self.cluesCleared=0
        for i in range(len(self.localResults)):
            m = hashlib.md5()
            clue = self.localResults[i]
            clueA = self.digInTheSand(clue)
            clueB = self.searchTheRiver(clueA)
            clueC = self.crawlIntoCave(clueB)
            m.update(clueC.encode())
            clueD = str(m.hexdigest())

            clueE = clueD.upper()
            self.localResults[i]=clueE
            self.cluesCleared+=1
    """
    my_str = "hello world"
    bytes = str.encode(my_str)
    type(bytes) # ensure it is byte representation
    my_decoded_str = str.decode(bytes)
    type(my_decoded_str) # ensure it is string representation
    """

    # crawl into the cave
    def crawlIntoCave(self, clue):
        for i in range(200):
            clue = self.rope(clue)
        for i in range(100):
            clue = self.torch(clue)
        return str(clue)

    # search the river
    def searchTheRiver(self, clue):
        for i in range(200):
            clue = self.bucket(clue)
        return str(clue)

    # dig in the sand
    def digInTheSand(self, clue):
        for i in range(100):
            clue = self.shovel(clue)
        for i in range(200):
            clue = self.bucket(clue)
        for i in range(100):
            clue = self.shovel(clue)
        return str(clue)

    # bucket

    def bucket(self, clue):
        lm = list(clue)
        for i, c in enumerate(lm):
            if (str(lm[i]).isdigit() == True):
                if (int(lm[i]) > 5):
                    lm[i] = str(int(lm[i]) - 2)
                elif (int(lm[i]) <= 5):
                    lm[i] = str(int(lm[i]) * 2)
        return str("".join(lm))

    # torch
    def torch(self, clue):
        # lm=list(clue)
        x = 0
        for i, c in enumerate(clue):
            if (str(clue[i]).isdigit() == True):
                x = x + int(clue[i])

        if (x < 100):
            x = x * x
        c = str(x)
        if (len(c) < 10):
            c = c[1:]
            c = "F9E8D7" + c
        else:
            c = c[6:]
            c = c + "A1B2C3"
        return str(c)

    # rope
    def rope(self, clue):
        lm = list(clue)
        for i, c in enumerate(lm):
            if (str(lm[i]).isdigit() == True):
                if (int(lm[i]) % 3 == 0):
                    lm[i] = "5"
                elif (int(lm[i]) % 3 == 1):
                    lm[i] = "A"
                elif (int(lm[i]) % 3 == 2):
                    lm[i] = "B"
            else:
                tm = 0
                if lm[i] == "A":
                    tm = "0"
                if lm[i] == "B":
                    tm = "1"
                if lm[i] == "C":
                    tm = "2"
                if lm[i] == "D":
                    tm = "3"
                if lm[i] == "E":
                    t = "4"
                if lm[i] == "F":
                    tm = "5"

                if (int(tm) % 5 == 0):
                    lm[i] = "C"
                elif (int(tm) % 5 == 1):
                    lm[i] = "1"
                elif (int(tm) % 5 == 2):
                    lm[i] = "2"
                else:
                    lm[i] = str(lm[i])
        return str("".join(lm))

    # shovel
    def shovel(self, clue):
        clue = ''.join(sorted(clue))
        t = clue[1]
        if (t.isdigit() == True):
            clue = clue + "0A2B3C"
        else:
            clue = clue + "1B2C3D"
        clue = clue[1:]
        return clue
    def jumpOverBoard(self):
        sys.exit(0)

    def addCrew(self, listOfCrew):
        for i in listOfCrew:
            self.pIDs.append(subprocess.Popen(["py", "pirate-AsynchronousBatch.py", str(i)], shell=True))
            time.sleep(10)

        for i in listOfCrew:
            self.asyncCrew.append(Pyro4.batch(proxy=Pyro4.Proxy("PYRONAME:" + str(i))))

        print("Crew's ready to go")
        print(self.listOfCrew)

    def removeCrew(self, crewId):
        pos = self.listOfCrew.index(crewId)
        temp = self.pids[pos]

        if (pos > -1):
            self.asyncCrew.pop(pos)
            self.listOfCrew.pop(pos)

            for (proc) in psutil.process_iter():
                if (proc.personalID == temp):
                    # need to check process killing on linux
                    os.system("taskkill /f /PID " + str(temp))
            print("Crewman removed")
            print("current crew: " + str(len(self.listOfCrew)))
            # TELL RUMMY THE CREW MEMBER IS REMOVED
        else:
            print("Couldn't find that crewman")


def main():
    p = pirate()

    print("Pirate:" + p.personalID + " reporting for duty")
    Pyro4.config.NS_AUTOCLEAN = 60.0
    Pyro4.config.THREADPOOL_SIZE = 1000
    Pyro4.config.MAX_RETRIES = 1
    Pyro4.config.SERVERTYPE = "multiplex"
    Pyro4.config.ONEWAY_THREADED=False
    if (p.quarterMaster == False and p.personalID == "pirate0"):

        print("Quartermaster reporting for duty")
        p.quarterMaster=True
        #subprocess.call(["py", "-m", "Pyro4.naming"], shell=True)

        daemon=Pyro4.Daemon()
        uri=daemon.register(p)
        ns=Pyro4.locateNS(host="localhost",port=9090)
        ns.register("quartermaster",uri)
        numProc=psutil.cpu_count()
        numPiratesToMake=(numProc)
        #numPiratesToMake = (numProc * 5)
        numPiratesToMake=20
        print(subprocess.check_output(["py", "rummy.pyc", "-w"], shell=True))
        print(subprocess.check_output(["py", "rummy.pyc", "-u"], shell=True))
        print(subprocess.check_output(["py", "rummy.pyc", "-p"], shell=True))
        print("We're ready to get crew")

        stopProcess=False
        strA = json.loads(subprocess.check_output(["py", "rummy.pyc", "-a", str(numPiratesToMake)]))
        for count in range(numPiratesToMake):
            print("ID:" + str((strA["data"][count])))
            p.listOfCrew.append(strA["data"][count])
        p.addCrew(p.listOfCrew)
        print("Crew Asssembled ")
        print("Gathering Clues")

        subprocess.check_output(["py", "rummy.pyc", "-s"])
        p.mapData=json.loads(subprocess.check_output(["py", "rummy.pyc", "-c"]))
        print("Length of entire object" + str(len(p.mapData)))

        for i in range(numPiratesToMake):
            nC=len(p.mapData["data"][i]["data"])

            for j in range(nC):
                p.clues.append(str(p.mapData["data"][i]["data"][j]["data"]))

        print("Number of clues:"+str(len(p.clues)))
        numClues=len(p.clues)
        #clues loaded
        file=open("clues.txt","w")
        for i in range(len(p.clues)):
            file.write("\n")
            file.write(str(i)+":"+p.clues[i])
            file.write("\n")

        file.close()
        numJobs=[]
        clueIDs=[]
        pCluesArr=[]
        listOfWorkers=[]
        numFailures=[]
        p.results=[]
        failedList=[]
        tmpID=""
        useAsync=True
        runFailedClues=False
        #Next map is unlocked when verify string has no clues || 4 attributes


        print("Starting Solving")
        while (stopProcess==False):
            #while we have clues
            p.results=[]
            numJobs=[]
            print("Solving Clues")
            piratesWorking=0
            currP = 0
            clueIDs=[]
            pCluesArr=[]
            while (len(p.clues)!=0):
                print("Starting Clue Solving")
                numJobs=[]
                piratesWorking=0
                numClues=len(p.clues)
                print("Current Cluework Load:" +str(numClues))
                if (useAsync==False or numClues<numPiratesToMake):
                    numJobs.append(numClues)
                    piratesWorking=1
                else:
                    if (numClues % numPiratesToMake == 0):
                        for h in range(len(p.asyncCrew)):
                            numJobs.append(int(numClues /numPiratesToMake))
                    else:
                        for h in range(len(p.asyncCrew) - 1):
                            numJobs.append(int(numClues / numPiratesToMake))
                        totalV=int(numClues / numPiratesToMake) * (numPiratesToMake-1)
                        totalV=numClues-totalV
                        numJobs.append(totalV)
                    piratesWorking=numPiratesToMake
                count=0

                tmp = []
                p.results=[]
                if useAsync == False:
                    index = 0
                    p.results = []
                    min=1000
                    for i in range(len(listOfWorkers)):
                        if numFailures[i] < min:
                            min = numFailures[i]
                            index = i
                    numFailures = []
                    count=0
                    tmpQQ=[]
                    for j in range(numClues):
                        p.asyncCrew[listOfWorkers[index]].doWorkNoSync(p.clues[count])
                        count=count+1
                    tmpQQ.append(p.asyncCrew[listOfWorkers[index]]())
                    for w in tmpQQ[0]:
                        p.results.append(w)

                if useAsync==True:
                    #Reset all of the pirates with their lists and clueCounts
                    p.results=[]
                    for i in range(piratesWorking):
                        p.asyncCrew[i].clearLocalRes()
                        p.asyncCrew[i](oneway=True)
                    #Now we add all of the clues to the pirates' local lists and then add the work order
                    for i in range(piratesWorking):
                        for j in range(numJobs[i]):
                            p.asyncCrew[i].addLocalClue(p.clues[count])
                            count += 1
                        p.asyncCrew[i](oneway=True)
                    for i in range(piratesWorking):
                        p.asyncCrew[i].doWork()
                        p.asyncCrew[i](oneway=True)
                    time.sleep(600)
                    doneWaiting=False
                    waitCount=0
                    print("Done assigning Work- Pirates are Working")
                    while doneWaiting==False:
                        prog=0
                        waitCount=0
                        for i in range(piratesWorking):
                            prog=0
                            pCE=0
                            p.asyncCrew[i].getProgress()
                            prog=p.asyncCrew[i]()
                            for ree in prog:
                                pCE=ree
                            if pCE==numJobs[i]:
                                waitCount+=1
                        if waitCount==piratesWorking:
                            doneWaiting=True
                    print("Pirates are done Working - Get their Clues")
                    #Now we ask for the pirate's clues
                    localList=[]
                    for i in range(piratesWorking):
                        localList=[]
                        p.asyncCrew[i].getLocalRes()
                        localList.append(p.asyncCrew[i]())
                        for u in localList[0]:
                            p.results.append(str(u))
                    p.asyncCrew=[]
                    for i in p.listOfCrew:
                        p.asyncCrew.append(Pyro4.batch(proxy=Pyro4.Proxy("PYRONAME:" + str(i))))
                    print("Number of Results Async:"+str(len(p.results)))

                    print("Number of pirates working:"+str(piratesWorking))
                print("Waiting for Pirates to finish work")

                tmpClues=[]
                count=0
                failedList=[]
                numFailures=[]
                listOfWorkers=[]

                print("Now to prep for rummy")
                if runFailedClues==False:
                    itVal=len(p.asyncCrew)
                else:
                    itVal=1
                print("Number of Clues to verify"+str(len(p.results)))

                for i in range(itVal):
                    if useAsync==True and runFailedClues==False:
                        resultStr = {}
                        resultStr["id"] = p.mapData["data"][i]["id"]
                        numClues = len(p.mapData["data"][i]["data"])
                        resultStr["data"] = []
                        for j in range(numClues):
                            resultStr["data"].append({})
                            resultStr["data"][j]["id"] = p.mapData["data"][i]["data"][j]["id"]
                            resultStr["data"][j]["key"] = str(p.results[count])
                            count += 1
                    else:
                        count=0
                        resultStr = {}
                        resultStr["id"] = tmpID
                        numCluesX =numClues
                        resultStr["data"] = []
                        for j in range(numCluesX):
                            resultStr["data"].append({})
                            resultStr["data"][j]["id"] = clueIDs[count]
                            resultStr["data"][j]["key"] = str(p.results[count])
                            count += 1

                    print("Clues loaded and ready for Pirate: "+str(i))
                    resultStr=repr(resultStr)
                    #resultStr = json.dumps(resultStr))
                    str1 = subprocess.check_output(["py", "rummy.pyc", "-v", resultStr], shell=True)
                    res = json.loads(str1)
                    print("Checking Result")
                    if (len(res) == 3 and  str(res["status"])=="success"):
                        stopProcess=True
                        runFailedClues=False
                        print(str(res))
                        p.clues=[]
                    if len(res) == 2 and str(res["status"])=="success":
                        print(str(res))

                    if len(res) == 3 and str(res["status"])=="error":
                        #recycle old clues
                        print(str(res))
                        failedList.append(res)
                        listOfWorkers.append(i)
                        nC = len(res["data"][0]["data"])
                        print("Number of Failures Reported by a Pirate:"+str(len(res["data"][0]["data"])))
                        numFailures.append(len(res["data"][0]["data"]))
                        for j in range(nC):
                            tmpClues.append(str(res["data"][0]["data"][j]["data"]))
                # Get new clues from rummy
                if (stopProcess==False and len(failedList)==0 and len(tmpClues)==0):
                    p.results=[]
                    runFailedClues=False
                    p.clues = []
                    p.mapData = {}
                    p.mapData = json.loads(subprocess.check_output(["py", "rummy.pyc", "-c"]))
                    print(p.mapData)
                    print("Length of entire object" + str(len(p.mapData)))
                    for i in range(numPiratesToMake):
                        nC = len(p.mapData["data"][i]["data"])

                        for j in range(nC):
                            p.clues.append(str(p.mapData["data"][i]["data"][j]["data"]))

                    print("New Clues:" + str(len(p.clues)))
                    numClues = len(p.clues)

                    useAsync=True
                    runFailedClues=False
                if stopProcess==False and len(tmpClues)!=0 and len(failedList)!=0:

                    p.results=[]
                    runFailedClues=True
                    p.clues=[]
                    iC=0
                    clueIDs=[]
                    useAsync=False
                    tmpID=failedList[0]["data"][0]["id"]
                    for i in range(len(tmpClues)):
                        p.clues.append(tmpClues[iC])
                        iC=iC+1

                    for i in range(len(failedList)):
                        w=len(failedList[i]["data"][0]["data"])
                        for j in range(w):
                            clueIDs.append(failedList[i]["data"][0]["data"][j]["id"])

                    print("Total Number of Failed Clues:" + str(len(p.clues)))
                currP = currP + 1
        print("Done Searching for clues Matey")
        for i in range(len(p.asyncCrew)):
            p.asyncCrew[i]._pyroRelease()

        for i in range(len(p.asyncCrew)):
            kill(p.pIDs[i].pid)

        sys.exit(0)
    else:
        print("I'm just a pirate:"+p.personalID)
        Pyro4.Daemon.serveSimple(
            {
                pirate: p.personalID
            }
            , ns=True
        )

main()
