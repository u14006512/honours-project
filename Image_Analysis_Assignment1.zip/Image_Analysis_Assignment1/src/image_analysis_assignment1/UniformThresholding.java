/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package image_analysis_assignment1;

import java.awt.BorderLayout;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferByte;
import java.awt.image.Raster;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.WindowConstants;

/**
 *
 * @author Warmaster
 */
public class UniformThresholding {

    String fn;
    int thresholdValue;
    int[][] pixelMatrix;
    int[][] transformedMatrix;

    double mean = 0;
    double stdDev = 0;

    BufferedImage imageOriginal;
    BufferedImage transformedImage;

    public UniformThresholding() {
    }

    public UniformThresholding(String fn, int t) throws IOException {
        this.fn = fn;
        this.thresholdValue = t;
        imageOriginal = ImageIO.read(new File(fn));
        displayOriginalImage();
        this.fn = fn.substring(0, fn.indexOf("."));

        pixelMatrix = producePixelMatrix(imageOriginal);
       
        getMean();
        getStandardDeviation();
        System.out.println("MEAN: "+this.mean);
        System.out.println("STD DEVIATION: "+this.stdDev);
        System.out.println("Finished Init");
        //printPixelArray();
    }

    private void getMean() {
        
        for(int i=0;i<imageOriginal.getHeight();i++)
        {
            for(int j=0;j<imageOriginal.getWidth();j++)
            {
                mean=mean+pixelMatrix[i][j];
            }
        }
        
        this.mean=mean/(imageOriginal.getWidth()*imageOriginal.getHeight());
    }

    private void getStandardDeviation() {
     
        double c=0;
        
        for(int i=0;i<imageOriginal.getHeight();i++)
        {
            for(int j=0;j<imageOriginal.getWidth();j++)
            {
                c=c+Math.pow(pixelMatrix[i][j]-mean,2);
            }
        }
        c=c/((imageOriginal.getWidth()*imageOriginal.getHeight())-1);
        c=Math.sqrt(c);
        
        this.stdDev=c;
    }

    private void printPixelArray() {
        for (int i = 0; i < pixelMatrix.length; i++) {
            for (int j = 0; j < pixelMatrix[i].length - 1; j++) {
                System.out.print(pixelMatrix[i][j] + ",");
            }
            System.out.print(pixelMatrix[i][pixelMatrix[i].length - 1]);
            System.out.println("");
        }
    }

    private void printTransformPixelArray() {
        for (int i = 0; i < transformedMatrix.length; i++) {
            for (int j = 0; j < transformedMatrix[i].length - 1; j++) {
                System.out.print(transformedMatrix[i][j] + ",");
            }
            System.out.print(transformedMatrix[i][transformedMatrix[i].length - 1]);
            System.out.println("");
        }
    }

    private int[][] producePixelMatrix(BufferedImage image) {
        int h = image.getHeight();
        int w = image.getWidth();
        transformedMatrix = new int[h][w];
        int[][] result = new int[h][w];
        Raster r = image.getData();

        for (int i = 0; i < h; i++) {
            for (int j = 0; j < w; j++) {
                result[i][j] = r.getSample(i, j, 0);
            }
        }
       
        return result;
    }

    public void uniformThresholdTransformImage() throws IOException {
        for (int i = 0; i < pixelMatrix.length; i++) {
            for (int j = 0; j < pixelMatrix[i].length; j++) {
                transformedMatrix[i][j] = pixelMatrix[i][j];
            }
        }
        ///Black =0
        ///White =255
        for (int i = 0; i < pixelMatrix.length; i++) {
            for (int j = 0; j < pixelMatrix[i].length; j++) {
                if (transformedMatrix[i][j] < thresholdValue) {
                    transformedMatrix[i][j] = 0;
                } else {
                    transformedMatrix[i][j] = 255;
                }
            }
        }
        //printTransformPixelArray();
        saveTransformedImageToFile();
        displayTransformedImage();
    }

    public void saveTransformedImageToFile() throws IOException {
        transformedImage = new BufferedImage(imageOriginal.getWidth(), imageOriginal.getHeight(), BufferedImage.TYPE_BYTE_BINARY);

        for (int i = 0; i < imageOriginal.getHeight(); i++) {
            for (int j = 0; j < imageOriginal.getWidth(); j++) {
                //int value = transformedMatrix[i][j] << 16 | transformedMatrix[i][j] << 8 | transformedMatrix[i][j];
                transformedImage.setRGB(i, j, (byte) transformedMatrix[i][j]);
            }
        }
        File myfile = new File("binary_" + fn + ".png");
        ImageIO.write(transformedImage, "png", myfile);
    }

    public void displayTransformedImage() {
        JFrame editorFrame = new JFrame("Uniform Thresholding- Binary Image");
        editorFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        ImageIcon imageIcon = new ImageIcon(this.transformedImage);
        JLabel jLabel = new JLabel();
        jLabel.setIcon(imageIcon);
        editorFrame.getContentPane().add(jLabel, BorderLayout.EAST);

        editorFrame.pack();
        editorFrame.setLocationRelativeTo(null);
        editorFrame.setVisible(true);
    }

    public void displayOriginalImage() {
        JFrame editorFrame = new JFrame("Uniform Thresholding- Original Image");
        editorFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        ImageIcon imageIcon = new ImageIcon(this.imageOriginal);
        JLabel jLabel = new JLabel();
        jLabel.setIcon(imageIcon);
        editorFrame.getContentPane().add(jLabel, BorderLayout.WEST);

        editorFrame.pack();
        editorFrame.setLocationRelativeTo(null);
        editorFrame.setVisible(true);
    }

}
