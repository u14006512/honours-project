/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package image_analysis_assignment1;

import java.awt.BorderLayout;
import java.awt.image.BufferedImage;
import java.awt.image.Raster;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.WindowConstants;

/**
 *
 * @author Warmaster
 */
public class MathematicalMorphology {
    int [][] pixelMap;
    
    int [][] erodedMatrix;
    int [][] dilatedMatrix;
    
    int [][] mesh;
    int shiftSize;
    
    BufferedImage imageOriginal;
    BufferedImage erodedImage;
    BufferedImage dilatedImage;
    
    String fn;
    
    int structuralElement[][];
    int rowsEnmesh;
    int colsEnmesh;

    int row;
    int col;
    /*
    Pass in the structural element as 2D array plus the name of  the image.
    */
    public MathematicalMorphology(String fn,int [][] se) throws IOException {
        this.fn=fn;
        
        
        imageOriginal = ImageIO.read(new File(fn));
        this.fn = fn.substring(0, fn.indexOf("."));

        pixelMap = producePixelMatrix(imageOriginal);
    
        shiftSize=(int) Math.floor(se.length/2);
        rowsEnmesh=pixelMap.length+(int) Math.floor(se.length/2)+1*shiftSize;
        colsEnmesh=pixelMap.length+(int) Math.floor(se.length/2)+1*shiftSize;
        
        structuralElement=new int[se.length][se[0].length];
        
        for(int i=0;i<se.length;i++)
        {
            for(int j=0;j<se[i].length;j++)
            {
                structuralElement[i][j]=se[i][j];
            }
        }
        
        mesh=new int[rowsEnmesh][colsEnmesh];
        System.out.println("Finished Init");
        
    }
    private void clearMesh()
    {
        for(int i=0;i<rowsEnmesh;i++)
        {
            for(int j=0;j<colsEnmesh;j++)
            {
                mesh[i][j]=-1;
            }
        }
    }
    private void produceMesh()
    {
        clearMesh();
        
        int iR=0;
        int iC=0;
        
        //Initialise the interior of the mesh
        
        for(int i=shiftSize;i<(shiftSize+row);i++)
        {
            iC=0;
            for(int j=shiftSize;j<(shiftSize+col);j++)
            {
            mesh[i][j]=pixelMap[iR][iC];
            iC++;
            }
            iR++;
        }
        //Initialise the 4 edges
        //Top
        for(int j=1;j<colsEnmesh-1;j++)
        {
         mesh[0][j]=mesh[shiftSize][j];
            
        }
        //Bottom
        for(int j=1;j<colsEnmesh-1;j++)
        {
            mesh[rowsEnmesh-1][j]=mesh[shiftSize+row-1][j];
            
        }
        //Left 
        for(int i=1;i<rowsEnmesh-1;i++)
        {
            mesh[i][0]=mesh[i][shiftSize];
            
        }
        //Right
        for(int i=1;i<rowsEnmesh-1;i++)
        {
            mesh[i][colsEnmesh-1]=mesh[i][shiftSize+col-1];
        }
        
        //Initialise the corners
        ///Take majority value from the 3 neighbouring pixels
        //Top Left
        if (mesh[0][1]+mesh[1][0]+mesh[1][1]>1)
        {
            mesh[0][0]=1;
        } else mesh[0][0]=0;
        
        //Top Right
        if (mesh[0][colsEnmesh-2]+mesh[1][colsEnmesh-2]+mesh[1][colsEnmesh-1]>1)
        {
            mesh[0][colsEnmesh-1]=1;
        } else mesh[0][colsEnmesh-1]=0;
        //Bottom Left
        if (mesh[rowsEnmesh-2][0]+mesh[rowsEnmesh-2][1]+mesh[rowsEnmesh-1][1]>1)
        {
            mesh[rowsEnmesh-1][0]=1;
        } else mesh[rowsEnmesh-1][0]=0;
        //Bottom Right
        if (mesh[rowsEnmesh-1][colsEnmesh-2]+mesh[rowsEnmesh-2][colsEnmesh-2]+mesh[rowsEnmesh-2][colsEnmesh-1]>1)
        {
            mesh[rowsEnmesh-1][colsEnmesh-1]=1;
        } else mesh[rowsEnmesh-1][colsEnmesh-1]=0;
        
        
        //printMesh();
        System.out.println("Finished Mesh");
    }
    private void printOriginalArray() {
        for (int i = 0; i < pixelMap.length; i++) {
            for (int j = 0; j < pixelMap[i].length - 1; j++) {
                System.out.print(pixelMap[i][j] + ",");
            }
            System.out.print(pixelMap[i][pixelMap[i].length - 1]);
            System.out.println("");
        }
    }
    private void printMesh() {
        for (int i = 0; i < mesh.length; i++) {
            for (int j = 0; j < mesh[i].length - 1; j++) {
                System.out.print(mesh[i][j] + ",");
            }
            System.out.print(mesh[i][mesh[i].length - 1]);
            System.out.println("");
        }
    }
    
    private void printDil() {
        for (int i = 0; i < dilatedMatrix.length; i++) {
            for (int j = 0; j < dilatedMatrix[i].length - 1; j++) {
                System.out.print(dilatedMatrix[i][j] + ",");
            }
            System.out.print(dilatedMatrix[i][dilatedMatrix[i].length - 1]);
            System.out.println("");
        }
    }
    
    private void printErosionrray() {
        for (int i = 0; i < erodedMatrix.length; i++) {
            for (int j = 0; j < erodedMatrix[i].length - 1; j++) {
                System.out.print(erodedMatrix[i][j] + ",");
            }
            System.out.print(erodedMatrix[i][erodedMatrix[i].length - 1]);
            System.out.println("");
        }
    }
    
    private int[][] producePixelMatrix(BufferedImage image) throws IOException {
        int h = image.getHeight();
        int w = image.getWidth();

        row=h;
        col=w;
        
        erodedMatrix=new int[h][w];
        dilatedMatrix=new int[h][w];
        
        displayOriginalImage();
        
        Raster r = image.getData();
        int[][] result = new int[h][w];
        int d;
        for (int i = 0; i < h; i++) {
            for (int j = 0; j < w; j++) {
              
                d=r.getSample(i, j, 0);
                result[i][j] = d;
            }
        }
       
        return result;
    }
    public void displayOriginalImage() {
        JFrame editorFrame = new JFrame("Mathematical Morphology- Original Image");
        editorFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        ImageIcon imageIcon = new ImageIcon(this.imageOriginal);
        JLabel jLabel = new JLabel();
        jLabel.setIcon(imageIcon);
        editorFrame.getContentPane().add(jLabel, BorderLayout.CENTER);

        editorFrame.pack();
        editorFrame.setLocationRelativeTo(null);
        editorFrame.setVisible(true);
    }
    public void saveErodedmageToFile() throws IOException {
        erodedImage = new BufferedImage(imageOriginal.getWidth(), imageOriginal.getHeight(), BufferedImage.TYPE_BYTE_BINARY);
        int d;
        for (int i = 0; i < imageOriginal.getHeight(); i++) {
            for (int j = 0; j < imageOriginal.getWidth(); j++) {
               d=erodedMatrix[i][j];
               
               if (d==1)
               {
                   erodedMatrix[i][j]=255;
               }
                //int value = transformedMatrix[i][j] << 16 | transformedMatrix[i][j] << 8 | transformedMatrix[i][j];
                erodedImage.setRGB(i, j, (byte) erodedMatrix[i][j]);
            }
        }
        File myfile = new File("erosion_" + fn + ".png");
        ImageIO.write(erodedImage, "png", myfile);
    }
    public void saveDilatedImageToFile() throws IOException {
        dilatedImage= new BufferedImage(imageOriginal.getWidth(), imageOriginal.getHeight(), BufferedImage.TYPE_BYTE_BINARY);
        int d;
        
        for (int i = 0; i < imageOriginal.getHeight(); i++) {
            for (int j = 0; j < imageOriginal.getWidth(); j++) {
                //int value = transformedMatrix[i][j] << 16 | transformedMatrix[i][j] << 8 | transformedMatrix[i][j];
                d=dilatedMatrix[i][j];
               
               if (d==1)
               {
                   dilatedMatrix[i][j]=255;
               }
                
                dilatedImage.setRGB(i, j, (byte) dilatedMatrix[i][j]);
            }
        }
        File myfile = new File("dilation_" + fn + ".png");
        ImageIO.write(dilatedImage, "png", myfile);
    }
    
    public void displayTransformedImageErosion() {
        JFrame editorFrame = new JFrame("Mathematical Morphology- Eroded Image");
        editorFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        ImageIcon imageIcon = new ImageIcon(this.erodedImage);
        JLabel jLabel = new JLabel();
        jLabel.setIcon(imageIcon);
        editorFrame.getContentPane().add(jLabel, BorderLayout.EAST);

        editorFrame.pack();
        editorFrame.setLocationRelativeTo(null);
        editorFrame.setVisible(true);
    }
    public void displayTransformedImageDilation() {
        JFrame editorFrame = new JFrame("Mathematical Morphology- Dilated Image");
        editorFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        ImageIcon imageIcon = new ImageIcon(this.dilatedImage);
        JLabel jLabel = new JLabel();
        jLabel.setIcon(imageIcon);
        editorFrame.getContentPane().add(jLabel, BorderLayout.WEST);

        editorFrame.pack();
        editorFrame.setLocationRelativeTo(null);
        editorFrame.setVisible(true);
    }
    
    
    
    
    public void produceErosionImage() throws IOException
    {
        clearMesh();
        produceMesh();
        int r=0;
        int c=0;
        for(int i=shiftSize;i<(shiftSize+row);i++)
        {
            c=0;
            for(int j=shiftSize;j<(shiftSize+col);j++)
            {
                if (mesh[i][j]==1)
                {
                    if (mesh[i-1][j-1]==structuralElement[0][0]&
                        mesh[i-1][j]==structuralElement[0][1] &&
                        mesh[i-1][j+1]==structuralElement[0][2] &&
                        mesh[i][j-1]==structuralElement[1][0]&&   
                        mesh[i][j+1]==structuralElement[1][2] &&
                        mesh[i+1][j-1]==structuralElement[2][0] &&
                        mesh[i+1][j]==structuralElement[2][1] &&
                        mesh[i+1][j+1]==structuralElement[2][2])
                    {
                        erodedMatrix[r][c]=1;
                    } else 
                        {
                            erodedMatrix[r][c]=0;
                        }
                } else 
                    {
                        erodedMatrix[r][c]=0;
                    }
                c++;
            }
            r++;
        }
        
        saveErodedmageToFile();
        displayTransformedImageErosion();
        System.out.println("Finished Erosion");
    }
    
    public void produceDilationImage() throws IOException
    {
        clearMesh();
        produceMesh();
        int r=0;
        int c=0;
        for(int i=shiftSize;i<(shiftSize+row);i++)
        {
            c=0;
            for(int j=shiftSize;j<(shiftSize+col);j++)
            {
                if (mesh[i][j]==0)
                {
                    if (mesh[i-1][j-1]==structuralElement[0][0] &&
                        mesh[i-1][j]==structuralElement[0][1] &&
                        mesh[i-1][j+1]==structuralElement[0][2]&&
                        mesh[i][j-1]==structuralElement[1][0]&&
                        mesh[i][j+1]==structuralElement[1][2] &&
                        mesh[i+1][j-1]==structuralElement[2][0]&&
                        mesh[i+1][j]==structuralElement[2][1] &&
                        mesh[i+1][j+1]==structuralElement[2][2])
                    {
                        dilatedMatrix[r][c]=0;
                    } else 
                        {
                            dilatedMatrix[r][c]=1;
                        }                 
                    
                } else 
                    {
                        dilatedMatrix[r][c]=1;
                    }
               c++; 
            }
            r++;
        }
        saveDilatedImageToFile();
        displayTransformedImageDilation();
        System.out.println("Finished Dilation");
    }
    public void updateSE(int [][] se)
    {
        for(int i=0;i<se.length;i++)
        {
            for(int j=0;j<se[i].length;j++)
            {
                this.structuralElement[i][j]=se[i][j];
            }
        }
    }
}
