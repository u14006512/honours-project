/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package image_analysis_assignment1;

import java.io.IOException;

/**
 *
 * @author Warmaster
 */
public class Image_Analysis_Assignment1_Mathematical_Morphology {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here

        String fn = "binary_anna.png";

        int r = 3;
        int c = 3;
        int[][] se = new int[r][c];

        se[0][0] = 1;
        se[0][1] = 1;
        se[0][2] = 1;
        se[1][0] = 1;
        se[1][1] = 1;
        se[1][2] = 1;
        se[2][0] = 1;
        se[2][1] = 1;
        se[2][2] = 1;

        MathematicalMorphology m = new MathematicalMorphology(fn, se);
        m.produceErosionImage();
        
        
        se[0][0] = 0;
        se[0][1] = 0;
        se[0][2] = 0;
        se[1][0] = 0;
        se[1][1] = 0;
        se[1][2] = 0;
        se[2][0] = 0;
        se[2][1] = 0;
        se[2][2] = 0;

        m.updateSE(se);
        m.produceDilationImage();
    }

}
